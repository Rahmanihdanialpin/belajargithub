@extends('layouts.public')

@section('title', 'Tentang Kami - Sazaliha Dessert')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-16">
    
    <div class="text-center max-w-3xl mx-auto mb-10 md:mb-16">
        <span class="text-3xl sm:text-4xl mb-3 block">🧁</span>
        <h1 class="text-2xl sm:text-4xl font-black bg-gradient-to-r from-pink-500 to-rose-600 bg-clip-text text-transparent mb-3.5">
            Kisah Sazaliha Dessert
        </h1>
        <p class="text-gray-600 text-base sm:text-lg leading-relaxed px-2 sm:px-0">
            Menghadirkan kebahagiaan di setiap sendokan melalui hidangan penutup premium yang dibuat dengan penuh cinta dan bahan-bahan berkualitas terbaik.
        </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
        
        <div class="space-y-4 md:space-y-6">
            <h2 class="text-xl sm:text-2xl font-bold text-gray-800 flex items-center gap-2">
                <span class="text-pink-500">✨</span> Awal Mula Kami
            </h2>
            <p class="text-gray-600 leading-relaxed text-sm sm:text-base">
                Sazaliha Dessert bermula dari sebuah dapur rumahan dengan misi sederhana: menciptakan hidangan penutup yang tidak hanya manis, tetapi juga berkesan bagi siapa saja yang menikmatinya. Kami percaya bahwa setiap momen spesial layak dirayakan dengan sesuatu yang manis.
            </p>
            <p class="text-gray-600 leading-relaxed text-sm sm:text-base">
                Setiap produk yang kami sajikan, mulai dari dessert box hingga kue premium, diproduksi secara higienis menggunakan resep pilihan yang terus kami sempurnakan demi menjaga cita rasa khas Sazaliha.
            </p>
        </div>

        <div class="bg-white/80 backdrop-blur-sm p-6 md:p-8 rounded-2xl border border-pink-100 shadow-sm space-y-5 md:space-y-6">
            <h2 class="text-xl sm:text-2xl font-bold text-gray-800 mb-2 md:mb-4">Mengapa Memilih Kami?</h2>
            
            <div class="flex gap-3.5 sm:gap-4">
                <div class="w-10 h-10 shrink-0 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center font-bold">🍓</div>
                <div>
                    <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Bahan Premium</h3>
                    <p class="text-gray-500 text-xs sm:text-sm mt-0.5">Kami hanya menggunakan bahan baku segar, berkualitas, dan tanpa bahan pengawet buatan.</p>
                </div>
            </div>

            <div class="flex gap-3.5 sm:gap-4">
                <div class="w-10 h-10 shrink-0 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center font-bold">👩‍🍳</div>
                <div>
                    <h3 class="font-semibold text-gray-800 text-sm sm:text-base">Dibuat Fresh Setiap Hari</h3>
                    <p class="text-gray-500 text-xs sm:text-sm mt-0.5">Semua hidangan diproduksi secara berkala untuk memastikan kesegaran tekstur dan rasa hingga ke tangan Anda.</p>
                </div>
            </div>

            <div class="flex gap-3.5 sm:gap-4">
                <div class="w-10 h-10 shrink-0 bg-green-100 text-green-600 rounded-xl flex items-center justify-center font-bold">✅</div>
                <div>
                    <h3 class="font-semibold text-gray-800 text-sm sm:text-base">100% Halal & Higienis</h3>
                    <p class="text-gray-500 text-xs sm:text-sm mt-0.5">Proses pembuatan yang bersih dan mengutamakan standar kehalalan produk.</p>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection