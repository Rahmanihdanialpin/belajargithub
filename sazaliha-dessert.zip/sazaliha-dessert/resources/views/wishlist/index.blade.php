@extends('layouts.public')

@section('title', 'Wishlist - Sazaliha')

@section('content')
<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="mb-6">
        <a href="{{ route('dashboard') }}" class="text-sm text-pink-500 hover:text-pink-600 flex items-center gap-1">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Kembali ke Dashboard
        </a>
    </div>

    <h1 class="text-2xl font-bold text-gray-800 mb-6">Wishlist Saya ❤️</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($wishlists as $wishlist)
        <div class="bg-white rounded-xl shadow-sm border border-pink-50 overflow-hidden hover:shadow-md transition">
            <a href="{{ route('products.show', $wishlist->product->slug) }}">
                <div class="aspect-square bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center relative">
                    @if($wishlist->product->image)
                        <img src="{{ asset('storage/' . $wishlist->product->image) }}" alt="{{ $wishlist->product->name }}" class="w-full h-full object-cover">
                    @else
                        <span class="text-6xl">{{ ['🍰','🧁','🍪','🍮','🍫','🍩'][$loop->index % 6] }}</span>
                    @endif
                    <span class="absolute top-3 left-3 px-2 py-1 bg-white/80 backdrop-blur text-xs rounded-full font-medium text-gray-600">
                        {{ $wishlist->product->category->name }}
                    </span>
                </div>
            </a>
            <div class="p-4">
                <h3 class="font-bold text-gray-800 truncate">{{ $wishlist->product->name }}</h3>
                <div class="flex items-center justify-between mt-2">
                    <span class="text-rose-600 font-bold">Rp {{ number_format($wishlist->product->price, 0, ',', '.') }}</span>
                    <span class="text-xs text-gray-400">Stok: {{ $wishlist->product->stock }}</span>
                </div>
                <div class="flex items-center gap-2 mt-3">
                    <form action="{{ route('cart.add') }}" method="POST" class="flex-1">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $wishlist->product->id }}">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="w-full py-2 bg-pink-500 text-white rounded-lg text-sm font-medium hover:bg-pink-600 transition">
                            + Keranjang
                        </button>
                    </form>
                    <form action="{{ route('wishlist.destroy', $wishlist) }}" method="POST" onsubmit="return confirm('Hapus dari wishlist?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="p-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100 transition">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                        </button>
                    </form>
                </div>
        </div>
        @empty
        <div class="col-span-full bg-white rounded-xl shadow-sm border border-pink-50 p-12 text-center">
            <div class="text-5xl mb-3">💝</div>
            <p class="text-gray-500">Wishlist masih kosong</p>
            <p class="text-sm text-gray-400 mt-1">Simpan produk favorit Anda di sini</p>
            <a href="{{ route('products.index') }}" class="inline-block mt-4 px-6 py-2.5 bg-pink-500 text-white rounded-lg font-medium hover:bg-pink-600 transition">Jelajahi Menu</a>
        </div>
        @endforelse
    </div>
@endsection
