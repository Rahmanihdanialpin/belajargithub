@extends('layouts.public')

@section('title', 'Sazaliha Dessert - Manisnya Setiap Momen')

@section('content')
<section class="relative overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
            <div class="text-center lg:text-left">
                <div class="inline-block px-4 py-1.5 bg-pink-100 text-pink-600 rounded-full text-sm font-semibold mb-4">
                    🍰 Handmade with Love
                </div>
                <h1 class="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight mb-4">
                    Manisnya Setiap <br>
                    <span class="bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">Momen Spesialmu</span>
                </h1>
                <p class="text-lg text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0">
                    Kue artisan homemade dengan bahan premium. Pesan online dan nikmati kelezatan dessert terbaik untuk keluarga tercinta.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                    <a href="{{ route('products.index') }}" class="inline-flex items-center justify-center px-8 py-3.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-full font-semibold text-lg hover:shadow-lg hover:shadow-pink-200 transition transform hover:-translate-y-0.5">
                        Lihat Menu
                        <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                    </a>
                    <a href="{{ route('cart.index') }}" class="inline-flex items-center justify-center px-8 py-3.5 bg-white text-pink-500 border-2 border-pink-200 rounded-full font-semibold text-lg hover:bg-pink-50 transition">
                        Keranjang
                    </a>
                </div>
            </div>
            <div class="relative">
                <div class="absolute inset-0 bg-gradient-to-tr from-pink-200 to-rose-200 rounded-full opacity-30 blur-3xl"></div>
                <div class="relative grid grid-cols-2 gap-4">
                    <div class="space-y-4 mt-8">
                        <div class="bg-white rounded-2xl p-4 shadow-lg shadow-pink-100/50 transform hover:scale-105 transition">
                            <div class="aspect-square bg-gradient-to-br from-pink-100 to-rose-100 rounded-xl flex items-center justify-center text-5xl">🍰</div>
                            <p class="mt-2 text-center font-semibold text-gray-700 text-sm">Strawberry Cake</p>
                        </div>
                        <div class="bg-white rounded-2xl p-4 shadow-lg shadow-pink-100/50 transform hover:scale-105 transition">
                            <div class="aspect-square bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl flex items-center justify-center text-5xl">🍪</div>
                            <p class="mt-2 text-center font-semibold text-gray-700 text-sm">Choco Cookies</p>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <div class="bg-white rounded-2xl p-4 shadow-lg shadow-pink-100/50 transform hover:scale-105 transition">
                            <div class="aspect-square bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl flex items-center justify-center text-5xl">🧁</div>
                            <p class="mt-2 text-center font-semibold text-gray-700 text-sm">Cupcake</p>
                        </div>
                        <div class="bg-white rounded-2xl p-4 shadow-lg shadow-pink-100/50 transform hover:scale-105 transition">
                            <div class="aspect-square bg-gradient-to-br from-green-100 to-teal-100 rounded-xl flex items-center justify-center text-5xl">🍮</div>
                            <p class="mt-2 text-center font-semibold text-gray-700 text-sm">Pudding</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-12 bg-white/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-8">Kategori Produk</h2>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            @foreach($categories as $category)
            <a href="{{ route('products.index', ['category' => $category->id]) }}" class="bg-white rounded-xl p-4 text-center shadow-sm hover:shadow-md transition border border-pink-50 group">
                <div class="w-14 h-14 mx-auto bg-pink-50 rounded-full flex items-center justify-center text-3xl mb-2 group-hover:bg-pink-100 transition">
                    {{ ['🍰','🍪','🍮','🍫','🧁','🍩'][$loop->index % 6] }}
                </div>
                <p class="font-semibold text-gray-700 text-sm">{{ $category->name }}</p>
                <p class="text-xs text-gray-400 mt-1">{{ $category->products_count ?? 0 }} items</p>
            </a>
            @endforeach
        </div>
    </div>
</section>

<section class="py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4 mb-8">
            <div class="space-y-1">
                <h2 class="text-xl sm:text-2xl font-black text-gray-800 tracking-tight">
                    Produk Terbaru
                </h2>
                <p class="text-xs sm:text-sm text-gray-500">
                    Dessert segar dan lezat untuk hari ini
                </p>
            </div>
            <div class="self-start sm:self-auto">
                <a href="{{ route('products.index') }}" class="group inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold text-pink-500 hover:text-white bg-white hover:bg-gradient-to-r hover:from-pink-500 hover:to-rose-500 border border-pink-200 hover:border-transparent rounded-full shadow-sm hover:shadow-md hover:shadow-pink-100 active:scale-95 transition-all duration-300 select-none">
                    <span>Lihat Semua</span>
                    <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                </a>
            </div>
        </div>
        
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
            @foreach($featuredProducts as $product)
            @php 
                // Mengambil nilai rating rata-rata dari database atau perkiraan bawaan
                $ratingAvg = round($product->reviews_avg_rating ?? 4.8, 1); 
                $reviewsCount = $product->reviews_count ?? count($product->reviews ?? []);
            @endphp
            <div class="bg-white rounded-2xl shadow-sm border border-pink-50 overflow-hidden hover:shadow-lg transition group flex flex-col justify-between">
                <div>
                    <a href="{{ route('products.show', $product->slug) }}">
                        <div class="aspect-square bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center relative overflow-hidden rounded-t-2xl">
                            @if($product->image)
                                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                            @else
                                <span class="text-4xl sm:text-6xl">{{ ['🍰','🧁','🍪','🍮','🍫','🍩','🥐','🎂'][$loop->index % 8] }}</span>
                            @endif

                            {{-- Badge Rating Ringkas di Atas Gambar Produk --}}
                            <div class="absolute top-2 right-2 bg-white/90 backdrop-blur-md px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm border border-pink-100">
                                <svg class="w-3 h-3 text-amber-400 fill-current" viewBox="0 0 20 20">
                                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                                </svg>
                                <span class="text-[10px] sm:text-xs font-bold text-gray-700">{{ $ratingAvg }}</span>
                            </div>
                        </div>
                    </a>
                    <div class="p-3 sm:p-4">
                        <div class="flex items-center justify-between gap-1">
                            <p class="text-[10px] sm:text-xs text-pink-500 font-semibold uppercase tracking-wide truncate">{{ $product->category->name }}</p>
                            
                            {{-- Teks Jumlah Ulasan Singkat --}}
                            <span class="text-[10px] text-gray-400 shrink-0">({{ $reviewsCount }} ulasan)</span>
                        </div>

                        <h3 class="font-bold text-gray-800 text-sm sm:text-base mt-0.5 sm:mt-1 truncate">{{ $product->name }}</h3>
                        <p class="text-xs sm:text-sm text-gray-500 mt-1 line-clamp-2">{{ Str::limit($product->description, 60) }}</p>
                    </div>
                </div>
                
                <div class="p-3 sm:p-4 pt-0">
                    <div class="flex items-center justify-between mt-1 gap-1">
                        <span class="text-xs sm:text-lg font-bold text-rose-600 truncate">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
                        <form action="{{ route('cart.add') }}" method="POST" class="shrink-0">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $product->id }}">
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit" class="w-7 h-7 sm:w-9 sm:h-9 bg-pink-500 text-white rounded-full flex items-center justify-center hover:bg-pink-600 transition shadow-md shadow-pink-200">
                                <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<section class="py-12 bg-white/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid md:grid-cols-3 gap-8">
            <div class="text-center p-6">
                <div class="w-16 h-16 bg-pink-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">🍰</div>
                <h3 class="font-bold text-gray-800 text-lg">Bahan Premium</h3>
                <p class="text-gray-500 mt-2 text-sm">Hanya menggunakan bahan berkualitas tinggi tanpa pengawet.</p>
            </div>
            <div class="text-center p-6">
                <div class="w-16 h-16 bg-rose-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">🚚</div>
                <h3 class="font-bold text-gray-800 text-lg">Pesan Online</h3>
                <p class="text-gray-500 mt-2 text-sm">Pemesanan mudah dengan sistem PO dan konfirmasi otomatis.</p>
            </div>
            <div class="text-center p-6">
                <div class="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">❤️</div>
                <h3 class="font-bold text-gray-800 text-lg">Homemade</h3>
                <p class="text-gray-500 mt-2 text-sm">Dibuat dengan cinta di dapur rumahan kami setiap hari.</p>
            </div>
        </div>
    </div>
</section>
@endsection