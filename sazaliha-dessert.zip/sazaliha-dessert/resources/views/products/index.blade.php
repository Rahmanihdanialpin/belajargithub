@extends('layouts.public')

@section('title', 'Menu Dessert - Sazaliha')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="text-center mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Menu Dessert</h1>
        <p class="text-gray-500 mt-2">Pilih dessert favoritmu dan pesan sekarang</p>
    </div>

    {{-- Form Pencarian & Filter --}}
    <div class="bg-white rounded-xl p-4 shadow-sm border border-pink-50 mb-8">
        <form action="{{ route('products.index') }}" method="GET" class="flex flex-col md:flex-row gap-4">
            <div class="flex-1">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari dessert..." class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
            </div>
            <div class="md:w-56">
                <select name="category" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                    <option value="">Semua Kategori</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}" {{ request('category') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="px-6 py-2.5 bg-pink-500 text-white rounded-lg font-medium hover:bg-pink-600 transition">
                Cari
            </button>
        </form>
    </div>

    {{-- Grid Produk --}}
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        @forelse($products as $product)
        @php 
            // Mengambil rata-rata rating dan jumlah ulasan
            $ratingAvg = round($product->reviews_avg_rating ?? 4.8, 1); 
            $reviewsCount = $product->reviews_count ?? count($product->reviews ?? []);
        @endphp
        <div class="bg-white rounded-2xl shadow-sm border border-pink-50 overflow-hidden hover:shadow-lg transition group flex flex-col">
            <a href="{{ route('products.show', $product->slug) }}">
                <div class="aspect-square bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center relative overflow-hidden">
                    @if($product->image)
                        <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                    @else
                        <span class="text-4xl sm:text-6xl">{{ ['🍰','🧁','🍪','🍮','🍫','🍩','🥐','🎂'][$loop->index % 8] }}</span>
                    @endif

                    {{-- Badge Rating Ringkas Melayang --}}
                    <div class="absolute top-2 right-2 bg-white/90 backdrop-blur-md px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm border border-pink-100">
                        <svg class="w-3 h-3 text-amber-400 fill-current" viewBox="0 0 20 20">
                            <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                        </svg>
                        <span class="text-[10px] sm:text-xs font-bold text-gray-700">{{ $ratingAvg }}</span>
                    </div>
                </div>
            </a>
            
            <div class="p-3 sm:p-4 flex-1 flex flex-col">
                {{-- Kategori & Jumlah Ulasan --}}
                <div class="flex items-center justify-between gap-1">
                    <p class="text-[10px] sm:text-xs text-pink-500 font-semibold uppercase tracking-wide truncate">{{ $product->category->name }}</p>
                    <span class="text-[10px] text-gray-400 shrink-0">({{ $reviewsCount }})</span>
                </div>

                <h3 class="font-bold text-gray-800 mt-0.5 truncate text-sm">{{ $product->name }}</h3>
                
                <div class="mt-2 mb-4">
                    <span class="block text-sm sm:text-lg font-bold text-rose-600">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
                </div>

                <div class="flex flex-row gap-2 mt-auto">
                    <form action="{{ route('cart.add') }}" method="POST" class="w-1/4">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="w-full h-10 flex items-center justify-center bg-white border-2 border-pink-100 text-pink-500 rounded-lg hover:bg-pink-50 transition-all active:scale-95">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                        </button>
                    </form>

                    <form action="{{ route('cart.buy-now') }}" method="POST" class="w-3/4">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="w-full h-10 flex items-center justify-center bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-lg text-xs font-bold shadow-sm hover:shadow-pink-200 transition-all active:scale-95">
                            Beli
                        </button>
                    </form>
                </div>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-12">
            <div class="text-6xl mb-4">🍰</div>
            <h3 class="text-lg font-semibold text-gray-600">Produk tidak ditemukan</h3>
            <p class="text-gray-400">Coba kata kunci lain atau pilih kategori berbeda.</p>
        </div>
        @endforelse
    </div>

    {{-- Paginasi --}}
    <div class="mt-10">
        {{ $products->links() }}
    </div>
</div>
@endsection