<x-guest-layout>
    <!-- Container Utama: Rapat penuh dari atas di mobile, Center Card di desktop -->
    <div class="w-full min-h-screen sm:min-h-0 sm:max-w-md flex flex-col justify-start sm:justify-between bg-white sm:bg-transparent">
        
        <!-- Card Forgot Password -->
        <div class="bg-white sm:rounded-3xl sm:shadow-xl sm:shadow-pink-200/50 sm:border sm:border-pink-100 overflow-hidden flex-1 sm:flex-none flex flex-col justify-start sm:block">
            
            <div class="flex-1 sm:flex-none flex flex-col justify-center sm:block">
                <!-- Header: Konsisten dengan tema login & register -->
                <div class="bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 px-6 py-8 sm:px-8 sm:py-8 text-center relative shrink-0 pt-10 sm:pt-8">
                    <div class="w-16 h-16 sm:w-20 sm:h-20 bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-md sm:shadow-lg">
                        <span class="text-4xl sm:text-5xl">🔒</span>
                    </div>
                    <h1 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Sazaliha Dessert</h1>
                    <p class="text-pink-100 text-xs sm:text-sm mt-1">
                        Pulihkan akses kata sandi Anda
                    </p>
                </div>

                <!-- Form & Konten Utama -->
                <div class="px-6 py-6 sm:px-8 sm:py-6 flex-1">
                    
                    <!-- Deskripsi Petunjuk -->
                    <div class="mb-5 text-xs sm:text-sm text-gray-500 leading-relaxed bg-pink-50/40 p-4 rounded-xl border border-pink-100/50">
                        {{ __('Lupa kata sandi Anda? Tidak masalah. Cukup masukkan alamat email Anda di bawah ini, dan kami akan mengirimkan tautan pemulihan kata sandi melalui email.') }}
                    </div>

                    <!-- Session Status: Aman di dalam kontainer form -->
                    <x-auth-session-status class="mb-4" :status="session('status')" />

                    <form method="POST" action="{{ route('password.email') }}" class="w-full">
                        @csrf

                        <!-- Email Address -->
                        <div>
                            <label for="email" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-1.5">
                                📧 Alamat Email
                            </label>
                            <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus
                                class="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-pink-200 bg-pink-50/50 text-gray-800 placeholder-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition text-sm sm:text-base"
                                placeholder="email@contoh.com" />
                            
                            @if($errors->get('email'))
                                <p class="mt-1.5 text-xs text-rose-500 flex items-center gap-1">
                                    <svg class="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                    {{ $errors->get('email')[0] }}
                                </p>
                            @endif
                        </div>

                        <!-- Submit Button -->
                        <div class="mt-5 sm:mt-6">
                            <button type="submit" class="w-full py-3.5 px-4 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold rounded-xl shadow-md shadow-pink-300/40 active:scale-[0.98] transition duration-150 text-sm sm:text-base flex items-center justify-center gap-2">
                                Kirim Link Pemulihan
                            </button>
                        </div>
                    </form>

                    <!-- Divider -->
                    <div class="mt-5 sm:mt-6 flex items-center gap-3">
                        <div class="flex-1 h-px bg-pink-100/80"></div>
                        <span class="text-[11px] sm:text-xs text-pink-400 font-bold uppercase tracking-wider">atau</span>
                        <div class="flex-1 h-px bg-pink-100/80"></div>
                    </div>

                    <!-- Back to Login Link -->
                    <div class="mt-4 text-center text-xs sm:text-sm pb-4">
                        <span class="text-gray-500">Ingat kata sandi Anda?</span>
                        <a href="{{ route('login') }}" class="text-pink-500 hover:text-pink-700 font-bold transition ml-0.5">
                            Masuk di sini
                        </a>
                    </div>

                    <!-- Back to Home -->
                    <div class="mt-2 text-center">
                        <a href="{{ route('home') }}" class="inline-flex items-center gap-1.5 text-xs sm:text-sm text-gray-400 hover:text-pink-500 font-medium transition py-1">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                            Kembali ke Beranda
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <p class="text-center text-gray-400 text-[10px] sm:text-xs py-6 shrink-0 sm:mt-0">
            🧁 Sazaliha Dessert &copy; {{ date('Y') }} — Manisnya Setiap Momen
        </p>
    </div>
</x-guest-layout>