<x-guest-layout>
    <!-- Container Utama: Rapat penuh dari atas di mobile, Center Card di desktop -->
    <div class="w-full min-h-screen sm:min-h-0 sm:max-w-md flex flex-col justify-start sm:justify-between bg-white sm:bg-transparent">
        
        <!-- Card Verify Email -->
        <div class="bg-white sm:rounded-3xl sm:shadow-xl sm:shadow-pink-200/50 sm:border sm:border-pink-100 overflow-hidden flex-1 sm:flex-none flex flex-col justify-start sm:block">
            
            <div class="flex-1 sm:flex-none flex flex-col justify-center sm:block">
                <!-- Header: Konsisten dengan tema auth Sazaliha Dessert -->
                <div class="bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 px-6 py-8 sm:px-8 sm:py-8 text-center relative shrink-0 pt-10 sm:pt-8">
                    <div class="w-16 h-16 sm:w-20 sm:h-20 bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-md sm:shadow-lg">
                        <span class="text-4xl sm:text-5xl">📩</span>
                    </div>
                    <h1 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Verifikasi Email</h1>
                    <p class="text-pink-100 text-xs sm:text-sm mt-1">
                        Satu langkah lagi menuju kelezatan
                    </p>
                </div>

                <!-- Konten Utama -->
                <div class="px-6 py-6 sm:px-8 sm:py-6 flex-1">
                    
                    <!-- Deskripsi Petunjuk -->
                    <div class="mb-5 text-xs sm:text-sm text-gray-500 leading-relaxed bg-pink-50/40 p-4 rounded-xl border border-pink-100/50">
                        {{ __('Terima kasih telah mendaftar! Sebelum memulai, silakan verifikasi alamat email Anda dengan mengeklik tautan yang baru saja kami kirimkan. Jika Anda tidak menerima email tersebut, kami dengan senang hati akan mengirimkan yang baru.') }}
                    </div>

                    <!-- Notifikasi Sukses Mengirim Ulang Link -->
                    @if (session('status') == 'verification-link-sent')
                        <div class="mb-5 text-xs sm:text-sm font-semibold text-emerald-600 bg-emerald-50 border border-emerald-100 p-4 rounded-xl flex items-start gap-2">
                            <svg class="w-4 h-4 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <span>{{ __('Tautan verifikasi baru telah dikirim ke alamat email yang Anda berikan saat pendaftaran.') }}</span>
                        </div>
                    @endif

                    <!-- Aksi Tombol: Stack vertikal di mobile, Flex horizontal di desktop -->
                    <div class="mt-5 sm:mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                        
                        <!-- Form Kirim Ulang Link -->
                        <form method="POST" action="{{ route('verification.send') }}" class="w-full sm:w-auto order-1 sm:order-none">
                            @csrf
                            <button type="submit" class="w-full sm:w-auto py-3 px-5 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold rounded-xl shadow-md shadow-pink-300/40 active:scale-[0.98] transition duration-150 text-xs sm:text-sm flex items-center justify-center gap-2">
                                🔄 {{ __('Kirim Ulang Email Verifikasi') }}
                            </button>
                        </form>

                        <!-- Form Logout -->
                        <form method="POST" action="{{ route('logout') }}" class="w-full sm:w-auto text-center order-2 sm:order-none">
                            @csrf
                            <button type="submit" class="w-full sm:w-auto py-2.5 sm:py-0 text-xs sm:text-sm text-gray-400 hover:text-pink-500 font-semibold underline transition focus:outline-none">
                                {{ __('Keluar Akun') }}
                            </button>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <p class="text-center text-gray-400 text-[10px] sm:text-xs py-6 shrink-0 sm:mt-0">
            🧁 Sazaliha Dessert &copy; {{ date('Y') }} — Manisnya Setiap Momen
        </p>
    </div>
</x-guest-layout>