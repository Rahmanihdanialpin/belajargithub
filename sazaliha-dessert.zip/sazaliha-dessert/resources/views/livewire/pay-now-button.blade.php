<div>
    @if($order->status === 'pending')
        <div class="mt-4">
            @if($error)
                <div class="mb-3 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                    {{ $error }}
                </div>
            @endif

            <button
                wire:click="generateToken"
                wire:loading.attr="disabled"
                class="w-full px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-emerald-200 transition flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <span wire:loading.remove>
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                    </svg>
                </span>
                <span wire:loading>
                    <svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </span>
                <span wire:loading.remove>Bayar Sekarang</span>
                <span wire:loading>Memuat...</span>
            </button>
            <p class="text-[11px] text-gray-400 text-center mt-2">Pembayaman aman via Midtrans</p>
        </div>

        @once
            @push('scripts')
                @if($clientKey)
                    <script src="https://app.midtrans.com/snap/snap.js" data-client-key="{{ $clientKey }}"></script>
                @else
                    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ $clientKey }}"></script>
                @endif
                <script>
                    document.addEventListener('livewire:initialized', function() {
                        Livewire.on('snap-token-ready', (event) => {
                            const token = event[0]?.token || event.token;
                            if (token && typeof snap !== 'undefined') {
                                snap.pay(token, {
                                    onSuccess: function(result) {
                                        window.location.reload();
                                    },
                                    onPending: function(result) {
                                        window.location.reload();
                                    },
                                    onError: function(result) {
                                        alert('Pembayaran gagal. Silakan coba lagi.');
                                    },
                                    onClose: function() {
                                        console.log('Payment popup closed');
                                    }
                                });
                            }
                        });
                    });
                </script>
            @endpush
        @endonce
    @elseif($order->payment_status === 'settlement' || $order->status === 'processing')
        <div class="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
            <p class="text-sm text-emerald-700 font-medium flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Pembayaran Berhasil
            </p>
            <p class="text-xs text-emerald-600 mt-1">
                @if($order->paid_at)
                    Dibayar pada {{ $order->paid_at->format('d M Y H:i') }}
                @endif
                @if($order->payment_type)
                    · Metode: {{ ucfirst(str_replace('_', ' ', $order->payment_type)) }}
                @endif
            </p>
        </div>
    @elseif($order->payment_status === 'pending')
        <div class="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <p class="text-sm text-amber-700 font-medium flex items-center gap-2">
                <svg class="w-4 h-4 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Menunggu Pembayaran
            </p>
            <button
                wire:click="generateToken"
                wire:loading.attr="disabled"
                class="mt-2 w-full px-3 py-2 bg-amber-500 text-white rounded-lg text-sm font-medium hover:bg-amber-600 transition disabled:opacity-50"
            >
                Lanjutkan Pembayaran
            </button>
        </div>
    @elseif(in_array($order->payment_status, ['expire', 'cancel', 'deny']))
        <div class="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <p class="text-sm text-red-700 font-medium flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                Pembayaran Dibatalkan / Kadaluarsa
            </p>
        </div>
    @endif
</div>
