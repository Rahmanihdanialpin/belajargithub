@extends('layouts.customer')

@section('title', 'Pesanan Saya - Sazaliha')

@section('content')
<div class="w-full max-w-5xl mx-auto py-4 md:py-8 px-2 sm:px-4 lg:px-8">

    <!-- Header Halaman -->
    <div class="mb-5 px-2 md:px-0">
        <h1 class="text-xl md:text-2xl font-black text-gray-800 tracking-tight">Pesanan Saya</h1>
        <p class="text-xs md:text-sm text-gray-500 mt-0.5">Pantau status hidangan manis pesananmu di sini.</p>
    </div>

    <!-- Status Tabs (Mobile Scrollable) -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 mb-5 overflow-hidden">
        <div class="flex overflow-x-auto scrollbar-none snap-x snap-mandatory">
            @php
                $tabs = [
                    'all' => ['label' => 'Semua', 'count' => $counts['all']],
                    'pending' => ['label' => 'Belum Bayar', 'count' => $counts['pending']],
                    'processing' => ['label' => 'Dikemas', 'count' => $counts['processing']],
                    'completed' => ['label' => 'Selesai', 'count' => $counts['completed']],
                    'cancelled' => ['label' => 'Dibatalkan', 'count' => $counts['cancelled']],
                ];
            @endphp
            @foreach($tabs as $tabStatus => $tab)
                <a href="{{ route('orders.list', ['status' => $tabStatus]) }}"
                   class="flex-1 min-w-[100px] text-center px-4 py-3.5 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition snap-center
                   {{ $status === $tabStatus ? 'border-rose-500 text-rose-600 bg-rose-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50' }}">
                    {{ $tab['label'] }}
                    <span class="ml-1 px-1.5 py-0.5 text-[10px] md:text-xs rounded-full font-black {{ $status === $tabStatus ? 'bg-rose-100 text-rose-600' : 'bg-gray-100 text-gray-500' }}">
                        {{ $tab['count'] }}
                    </span>
                </a>
            @endforeach
        </div>
    </div>

    <!-- Orders List Stack -->
    <div class="space-y-4">
        @forelse($orders as $order)
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden transition hover:border-gray-200">
            
            <!-- Card Header -->
            <div class="px-4 py-3 bg-gray-50/50 border-b border-gray-100 flex flex-row items-center justify-between gap-2">
                <div class="min-w-0">
                    <span class="block font-black text-sm md:text-base text-gray-800 truncate">{{ $order->order_number }}</span>
                    <span class="block text-[10px] md:text-xs text-gray-400 mt-0.5">{{ $order->created_at->format('d M Y, H:i') }}</span>
                </div>
                <span class="px-2.5 py-1 text-[10px] md:text-xs rounded-xl font-bold uppercase tracking-wider shrink-0
                    @if($order->status == 'pending') bg-amber-50 text-amber-700 border border-amber-200/50
                    @elseif($order->status == 'processing') bg-blue-50 text-blue-700 border border-blue-200/50
                    @elseif($order->status == 'completed') bg-emerald-50 text-emerald-700 border border-emerald-200/50
                    @elseif($order->status == 'cancelled') bg-red-50 text-red-700 border border-red-200/50
                    @else bg-gray-50 text-gray-700 border border-gray-200 @endif">
                    @if($order->status == 'pending') Belum Bayar
                    @elseif($order->status == 'processing') Dikemas
                    @elseif($order->status == 'completed') Selesai
                    @elseif($order->status == 'cancelled') Dibatalkan
                    @else {{ $order->status }} @endif
                </span>
            </div>

            <!-- Card Body (Items List) -->
            <div class="px-4 py-3 divide-y divide-gray-50">
                @foreach($order->items as $item)
                <div class="flex items-start sm:items-center gap-3 py-3 {{ $loop->first ? 'pt-1' : '' }} {{ $loop->last ? 'pb-1' : '' }}">
                    <div class="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center text-xl shrink-0 border border-amber-100/40 shadow-sm">
                        @if($item->product->image)
                            <img src="{{ asset('storage/' . $item->product->image) }}" alt="{{ $item->product->name }}" class="w-full h-full object-cover rounded-xl">
                        @else
                            🍰
                        @endif
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="font-bold text-sm text-gray-800 truncate">{{ $item->product->name }}</p>
                        <p class="text-xs text-gray-400 mt-0.5">{{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                    </div>
                    <span class="font-bold text-sm text-gray-800 shrink-0 align-self-center">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</span>
                </div>
                @endforeach
            </div>

            <!-- Card Footer -->
            <div class="px-4 py-3 bg-gray-50/30 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="text-left w-full sm:w-auto">
                    <span class="text-xs text-gray-400 block sm:inline">Total Pembayaran:</span>
                    <span class="text-base font-black text-rose-600 sm:ml-1">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</span>
                </div>
                
                <!-- Action Buttons (Responsive Width) -->
                <div class="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <a href="{{ route('orders.show', $order) }}" class="flex-1 sm:flex-initial text-center px-4 py-2 text-xs md:text-sm bg-white text-gray-700 border border-gray-200 rounded-xl font-bold hover:bg-gray-50 active:scale-[0.98] transition">
                        Detail
                    </a>
                    @if($order->status == 'pending')
                    <form action="{{ route('orders.cancel', $order) }}" method="POST" onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?');" class="flex-1 sm:flex-initial">
                        @csrf
                        @method('PATCH')
                        <button type="submit" class="w-full text-center px-4 py-2 text-xs md:text-sm bg-red-50 text-red-600 border border-red-100 rounded-xl font-bold hover:bg-red-100 active:scale-[0.98] transition">Batal</button>
                    </form>
                    @elseif($order->status == 'cancelled')
                    <form action="{{ route('orders.destroy', $order) }}" method="POST" onsubmit="return confirm('Hapus riwayat pesanan ini?');" class="flex-1 sm:flex-initial">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="w-full text-center px-4 py-2 text-xs md:text-sm bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 active:scale-[0.98] transition">Hapus</button>
                    </form>
                    @elseif($order->status == 'completed')
                    <a href="{{ route('reviews.index') }}" class="flex-1 sm:flex-initial text-center px-4 py-2 text-xs md:text-sm bg-amber-50 text-amber-600 border border-amber-100 rounded-xl font-bold hover:bg-amber-100 active:scale-[0.98] transition">Beri Ulasan</a>
                    @endif
                </div>
            </div>
        </div>
        @empty
        <!-- Empty State Screen -->
        <div class="bg-white rounded-2xl border border-gray-100 p-8 md:p-12 text-center shadow-sm">
            <div class="w-16 h-16 bg-pink-50 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4 border border-pink-100/50">📦</div>
            <h3 class="text-base font-bold text-gray-800">Belum Ada Pesanan</h3>
            <p class="text-xs text-gray-400 max-w-xs mx-auto mt-1">Belum ada transaksi pada daftar kategori ini.</p>
            <a href="{{ route('products.index') }}" class="mt-4 inline-block px-5 py-2 text-xs md:text-sm bg-gradient-to-r from-pink-500 to-rose-600 text-white font-bold rounded-xl shadow-md shadow-rose-200 hover:opacity-90 active:scale-[0.97] transition">
                Jelajahi Menu Dessert
            </a>
        </div>
        @endforelse
    </div>

    <!-- Pagination Wrapper -->
    @if($orders->hasPages())
    <div class="mt-5 px-2">
        {{ $orders->links() }}
    </div>
    @endif
</div>
@endsection