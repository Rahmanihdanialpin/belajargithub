<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Sazaliha Dessert - Manisnya Setiap Momen')</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=quicksand:400,500,600,700&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saza-pink': '#fdf2f8',
                        'saza-rose': '#fda4af',
                        'saza-rose-dark': '#e11d48',
                        'saza-cream': '#fffbeb',
                        'saza-brown': '#92400e',
                        'saza-choco': '#78350f',
                    },
                    fontFamily: {
                        'saza': ['Quicksand', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Quicksand', sans-serif; }
        .dessert-pattern {
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23fda4af' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
    </style>
    @livewireStyles
    @stack('styles')
</head>
<body class="font-saza text-gray-800 antialiased bg-saza-pink dessert-pattern min-h-screen">
@php
    $cartCount = 0;
    try {
        if(auth()->check()) {
            $cart = \App\Models\Cart::with('items')->where('user_id', auth()->id())->first();
            $cartCount = $cart ? $cart->count : 0;
        }
    } catch (\Throwable $e) {
        // Jika tabel carts belum dimigrasi, jangan buat halaman crash.
        $cartCount = 0;
    }
@endphp

    <nav x-data="{ mobileMenuOpen: false }" class="bg-white/90 backdrop-blur-md sticky top-0 z-50 border-b border-pink-100 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                
                <div class="flex items-center md:hidden">
                    <button @click="mobileMenuOpen = !mobileMenuOpen" type="button" class="inline-flex items-center justify-center p-2 rounded-xl text-gray-500 hover:text-pink-600 hover:bg-pink-50 focus:outline-none transition-colors" aria-expanded="false">
                        <span class="sr-only">Buka menu utama</span>
                        <svg x-show="!mobileMenuOpen" class="block h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                        <svg x-show="mobileMenuOpen" x-cloak class="block h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>

                <div class="flex-1 flex items-center justify-center md:justify-start gap-8">
                    <a href="{{ route('home') }}" class="flex items-center gap-1.5 sm:gap-2 select-none">
                        <div class="w-8 h-8 sm:w-10 sm:h-10 bg-white bg-gradient-to-br from-white to-[#FFF8EA] rounded-xl sm:rounded-2xl flex items-center justify-center text-lg sm:text-xl shadow-[0_0_10px_rgba(251,191,36,0.12)] border border-amber-100/50">
                            🧁
                        </div>
                        <span class="text-lg sm:text-xl md:text-2xl font-black tracking-tight bg-gradient-to-r from-pink-500 to-rose-600 bg-clip-text text-transparent whitespace-nowrap">
                            Sazaliha Dessert
                        </span>
                    </a>

                    <div class="hidden md:flex items-center space-x-6">
                        <a href="{{ route('home') }}" class="text-gray-600 hover:text-pink-500 font-medium text-sm transition">Beranda</a>
                        <a href="{{ route('products.index') }}" class="text-gray-600 hover:text-pink-500 font-medium text-sm transition">Menu</a>
                        <a href="{{ route('about') }}" class="text-gray-600 hover:text-pink-500 font-medium text-sm transition">Tentang Kami</a>
                    </div>
                </div>

                <div class="flex items-center gap-2 sm:gap-4">
                    <a href="{{ route('cart.index') }}" class="relative p-2 text-gray-600 hover:text-pink-500 transition rounded-xl hover:bg-pink-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                        @if($cartCount > 0)
                            <span class="absolute top-1 right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center ring-2 ring-white">{{ $cartCount }}</span>
                        @endif
                    </a>

                    @auth
                        <div class="relative" x-data="{ userMenuOpen: false }" @click.away="userMenuOpen = false">
                            <button @click="userMenuOpen = !userMenuOpen" class="flex items-center gap-1 sm:gap-2 group focus:outline-none">
                                <div class="w-8 h-8 rounded-full overflow-hidden bg-pink-100 border border-pink-200 shadow-sm">
                                    @if(auth()->user()->avatar)
                                        <img src="{{ asset('storage/' . auth()->user()->avatar) }}" class="w-full h-full object-cover">
                                    @else
                                        <div class="w-full h-full flex items-center justify-center text-pink-600 font-bold text-xs">{{ substr(auth()->user()->name, 0, 1) }}</div>
                                    @endif
                                </div>
                                <span class="hidden md:block text-sm text-gray-600 group-hover:text-pink-500 transition font-medium">{{ auth()->user()->name }}</span>
                                <svg class="w-3 h-3 text-gray-400 transition-transform duration-200" :class="{ 'rotate-180': userMenuOpen }" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                            </button>
                            
                            <div x-show="userMenuOpen" x-transition x-cloak class="absolute right-0 mt-2 w-52 bg-white rounded-xl border border-pink-50 shadow-lg overflow-hidden z-50 origin-top-right">
                                
                                @if(auth()->user()->is_admin)
                                    <a href="{{ route('admin.dashboard') }}" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                                        Dashboard Admin
                                    </a>
                                @else
                                    <a href="{{ route('dashboard') }}" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6z"/></svg>
                                        Dashboard
                                    </a>
                                @endif

                                <a href="{{ route('orders.list') }}" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                                    Pesanan Saya
                                </a>

                                <a href="{{ route('profile.edit') }}#daftar-alamat" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                    Alamat
                                </a>

                                <a href="{{ route('reviews.index') }}" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
                                    Ulasan
                                </a>

                                <div class="border-t border-gray-100"></div>

                                <a href="{{ route('profile.edit') }}" class="block text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 transition px-4 py-2.5 flex items-center gap-2">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                    Profil
                                </a>

                                <div class="border-t border-gray-100"></div>

                                <form method="POST" action="{{ route('logout') }}" class="block">
                                    @csrf
                                    <button type="submit" class="w-full text-left text-sm text-red-500 hover:bg-red-50 transition px-4 py-2.5 flex items-center gap-2">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                                        Keluar
                                    </button>
                                </form>
                            </div>
                        </div>
                    @else
                        <div class="flex items-center gap-1.5 sm:gap-2">
                            <a href="{{ route('login') }}" class="inline-flex items-center gap-1.5 p-2 sm:px-4 sm:py-2 border border-pink-400 text-pink-500 bg-white rounded-xl text-sm font-semibold hover:bg-pink-50 hover:border-pink-500 transition">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75" />
                                </svg>
                                <span class="hidden sm:inline">Login</span>
                            </a>
                            <a href="{{ route('register') }}" class="inline-flex items-center gap-1.5 p-2 sm:px-4 sm:py-2 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl text-sm font-semibold hover:shadow-md hover:shadow-pink-100 transition">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
                                <span class="hidden sm:inline">Daftar</span>
                            </a>
                        </div>
                    @endauth
                </div>
            </div>
        </div>

        <div x-show="mobileMenuOpen" 
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-2"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 -translate-y-2"
             x-cloak 
             class="md:hidden border-t border-pink-50 bg-white">
            <div class="px-2 pt-2 pb-3 space-y-1 shadow-inner">
                <a href="{{ route('home') }}" class="block px-4 py-2.5 rounded-xl text-base font-medium text-gray-700 hover:bg-pink-50 hover:text-pink-600 transition">Beranda</a>
                <a href="{{ route('products.index') }}" class="block px-4 py-2.5 rounded-xl text-base font-medium text-gray-700 hover:bg-pink-50 hover:text-pink-600 transition">Menu</a>
                <a href="{{ route('about') }}" class="block px-4 py-2.5 rounded-xl text-base font-medium text-gray-700 hover:bg-pink-50 hover:text-pink-600 transition">Tentang Kami</a>
            </div>
        </div>
    </nav>

    @if(session('success'))
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                {{ session('success') }}
            </div>
        </div>
    @endif

    <main>
        @yield('content')
    </main>

    <footer class="bg-white border-t border-pink-100 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="text-center">
                <div class="flex items-center justify-center gap-2 mb-3">
                    <span class="text-2xl">🧁</span>
                    <span class="text-xl font-bold text-pink-500">Sazaliha Dessert</span>
                </div>
                <p class="text-gray-500 text-sm">Manisnya setiap momen bersama Sazaliha.</p>
                <p class="text-gray-400 text-xs mt-2">&copy; {{ date('Y') }} Sazaliha Dessert. All rights reserved.</p>
            </div>
        </div>
    </footer>

    @livewireScripts
    @stack('scripts')

    <a href="https://wa.me/{{ config('services.whatsapp.admin_number') }}?text=Halo%20Sazaliha%20Dessert%2C%20saya%20ingin%20bertanya..." target="_blank"
       class="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg hover:shadow-xl transition flex items-center justify-center"
       title="Chat WhatsApp">
        <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </a>
</body>
</html>