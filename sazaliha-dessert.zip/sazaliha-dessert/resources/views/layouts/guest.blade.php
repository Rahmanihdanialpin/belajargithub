<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title', 'Login - Sazaliha Dessert')</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=quicksand:400,500,600,700&display=swap" rel="stylesheet" />

        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            'saza-pink': '#fdf2f8',
                            'saza-rose': '#fda4af',
                            'saza-rose-dark': '#e11d48',
                            'saza-cream': '#fffbeb',
                            'saza-brown': '#92400e',
                            'saza-choco': '#78350f',
                        },
                        fontFamily: {
                            'saza': ['Quicksand', 'sans-serif'],
                        }
                    }
                }
            }
        </script>
        
        <style>
            body { font-family: 'Quicksand', sans-serif; }
            .dessert-pattern {
                background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23fda4af' fill-opacity='0.08'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            }
            /* Menghindari kedipan atau ikon muncul ganda sebelum Alpine selesai dimuat */
            [x-cloak] { display: none !important; }
        </style>

        <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/focus@3.x.x/dist/cdn.min.js"></script>
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    </head>
    <body class="font-saza text-gray-800 antialiased bg-saza-pink dessert-pattern min-h-screen flex flex-col justify-center items-center p-0 sm:p-4">
        {{ $slot }}
    </body>
</html>