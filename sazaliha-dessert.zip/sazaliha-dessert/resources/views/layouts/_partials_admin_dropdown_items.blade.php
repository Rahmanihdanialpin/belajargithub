<a href="{{ route('admin.dashboard') }}" class="w-full text-left text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 rounded-xl transition px-3 py-2 flex items-center gap-2.5 font-medium">
    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
    Dashboard Admin
</a>
<a href="{{ route('profile.edit') }}" class="w-full text-left text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 rounded-xl transition px-3 py-2 flex items-center gap-2.5 font-medium">
    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
    Profil Saya
</a>
<a href="{{ route('home') }}" class="w-full text-left text-sm text-gray-600 hover:bg-pink-50 hover:text-pink-600 rounded-xl transition px-3 py-2 flex items-center gap-2.5 font-medium">
    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
    Lihat Website
</a>
<div class="border-t border-gray-100 my-1"></div>
<form method="POST" action="{{ route('logout') }}">
    @csrf
    <input type="hidden" name="admin_logout" value="1">
    <button type="submit" class="w-full text-left text-sm text-red-500 hover:bg-red-50 rounded-xl transition px-3 py-2 flex items-center gap-2.5 font-bold">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
        Keluar Aplikasi
    </button>
</form>