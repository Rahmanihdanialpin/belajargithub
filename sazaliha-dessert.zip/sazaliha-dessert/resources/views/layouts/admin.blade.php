<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Panel Admin') - Sazaliha</title>
    
    <!-- 🌐 Google Fonts: Quicksand -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=quicksand:400,500,600,700&display=swap" rel="stylesheet" />
    
    
    <!-- 🎨 Tailwind CSS via Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- ⚡ Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- ⚡ Alpine.js via CDN -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- 🛠️ Konfigurasi Warna & Font Khas Sazaliha -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'saza-pink': '#fdf2f8',
                        'saza-rose': '#fda4af',
                        'saza-rose-dark': '#e11d48',
                        'saza-cream': '#fffbeb',
                        'saza-brown': '#92400e',
                        'saza-choco': '#78350f',
                    },
                    fontFamily: {
                        'saza': ['Quicksand', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Quicksand', sans-serif; }
        
        /* Efek Hover & Active Sidebar (Garis berada di kanan sidebar) */
        .sidebar-link { transition: all 0.2s; }
        .sidebar-link:hover, .sidebar-link.active { 
            background: linear-gradient(90deg, rgba(253,164,175,0.15) 0%, transparent 100%); 
            border-right: 3px solid #e11d48; 
            color: #e11d48; 
        }
    </style>
    @stack('styles')
</head>
<body class="font-saza text-gray-800 antialiased bg-gray-50" x-data="{ mobileSidebarOpen: false }">

    <div class="flex h-screen overflow-hidden">
        
        <!-- 🎛️ SIDEBAR MOBILE DRAWER (Slide-out dari kiri) -->
        <div x-show="mobileSidebarOpen" class="fixed inset-0 z-50 lg:hidden" x-cloak>
            <!-- Overlay Gelap Belakang -->
            <div @click="mobileSidebarOpen = false" x-show="mobileSidebarOpen" x-transition:enter="transition-opacity ease-linear duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition-opacity ease-linear duration-300" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" class="fixed inset-0 bg-black/50 backdrop-blur-sm"></div>

            <!-- Konten Drawer -->
            <div x-show="mobileSidebarOpen" x-transition:enter="transition ease-in-out duration-300 transform" x-transition:enter-start="-translate-x-full" x-transition:enter-end="translate-x-0" x-transition:leave="transition ease-in-out duration-300 transform" x-transition:leave-start="translate-x-0" x-transition:leave-end="-translate-x-full" class="relative flex flex-col w-full max-w-xs h-full bg-white shadow-2xl">
                
                <div class="p-5 flex items-center justify-between border-b border-gray-100">
                    <div class="flex items-center gap-2.5">
                        <div class="w-9 h-9 bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl flex items-center justify-center text-lg border border-amber-100/40">🧁</div>
                        <span class="text-base font-black tracking-tight bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">Sazaliha Dessert</span>
                    </div>
                    <button @click="mobileSidebarOpen = false" class="p-1 rounded-lg text-gray-400 hover:bg-gray-50 text-xl">&times;</button>
                </div>

                <!-- Menu Navigasi Mobile Drawer -->
                <nav class="flex-1 overflow-y-auto py-4">
                    @include('layouts._partials_admin_menu_items')
                </nav>
            </div>
        </div>

        <!-- 🎛️ SIDEBAR DESKTOP -->
        <aside class="w-64 bg-white border-r border-gray-100 flex-shrink-0 hidden lg:flex flex-col h-screen sticky top-0">
            <!-- Header Brand Sidebar -->
            <div class="p-5 flex items-center gap-3 border-b border-gray-100 select-none">
                <div class="w-10 h-10 shrink-0 bg-gradient-to-br from-amber-50 to-orange-50/50 rounded-xl flex items-center justify-center text-xl shadow-sm border border-amber-100/40">
                    <span class="drop-shadow-sm">🧁</span>
                </div>
                <div class="min-w-0 flex flex-col">
                    <h2 class="text-base font-extrabold tracking-tight bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent whitespace-nowrap">
                        Sazaliha Dessert
                    </h2>
                    <span class="text-[9px] text-gray-400 font-bold tracking-widest uppercase mt-0.5 block">
                        Panel Admin
                    </span>
                </div>
            </div>
            
            <!-- Navigasi Menu Pelanggan Desktop -->
            <nav class="flex-1 overflow-y-auto py-4">
                @include('layouts._partials_admin_menu_items')
            </nav>
            
            <!-- Profil Bawah Desktop -->
            <div class="p-4 border-t border-gray-100 bg-white">
                <div class="relative desktop-dropdown-container">
                    <button onclick="toggleDropdown('desktop-menu', 'desktop-arrow')" class="w-full flex items-center gap-3 p-1.5 rounded-xl hover:bg-gray-50 transition group">
                        <div class="w-9 h-9 rounded-full overflow-hidden bg-pink-100 shrink-0 border border-pink-200/60 shadow-sm">
                            @if(auth()->user()->avatar)
                                <img src="{{ asset('storage/' . auth()->user()->avatar) }}" class="w-full h-full object-cover">
                            @else
                                <div class="w-full h-full flex items-center justify-center text-pink-600 font-bold text-sm">{{ substr(auth()->user()->name, 0, 1) }}</div>
                            @endif
                        </div>
                        <div class="flex-1 min-w-0 text-left">
                            <p class="text-sm font-bold text-gray-700 truncate group-hover:text-pink-600 transition">{{ auth()->user()->name }}</p>
                            <p class="text-[11px] text-gray-400 font-medium uppercase tracking-wider mt-0.5">Admin</p>
                        </div>
                        <svg id="desktop-arrow" class="w-4 h-4 text-gray-400 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    
                    <!-- Dropdown Desktop -->
                    <div id="desktop-menu" class="hidden absolute bottom-full left-0 right-0 mb-2 bg-white rounded-2xl border border-gray-100 shadow-xl p-1 space-y-0.5 z-50">
                        @include('layouts._partials_admin_dropdown_items')
                    </div>
                </div>
            </div>
        </aside>

        <!-- 💻 AREA UTAMA KONTEN -->
        <div class="flex-1 flex flex-col overflow-hidden">
            
            <!-- NAVBAR ATAS MOBILE -->
            <header class="lg:hidden bg-white border-b border-gray-100 px-4 py-2.5 flex items-center justify-between z-40 shadow-sm">
                <!-- Hamburger Trigger -->
                <button @click="mobileSidebarOpen = true" class="text-gray-600 p-2 hover:bg-gray-50 rounded-xl transition active:scale-95">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
                </button>

                <!-- Brand Center -->
                <div class="flex items-center gap-1.5 select-none">
                    <span class="text-base font-black tracking-tight bg-gradient-to-r from-pink-500 to-rose-600 bg-clip-text text-transparent">
                        Sazaliha Dessert
                    </span>
                </div>
                
                <!-- Avatar & Dropdown Mobile -->
                <div class="relative mobile-dropdown-container">
                    <button onclick="toggleDropdown('mobile-user-menu', 'mobile-arrow')" class="flex items-center gap-1 p-1 rounded-full hover:bg-gray-50 transition active:scale-95">
                        <div class="w-8 h-8 rounded-full overflow-hidden bg-pink-100 border border-pink-200/60 shadow-sm shrink-0">
                            @if(auth()->user()->avatar)
                                <img src="{{ asset('storage/' . auth()->user()->avatar) }}" class="w-full h-full object-cover">
                            @else
                                <div class="w-full h-full flex items-center justify-center text-pink-600 font-bold text-xs">{{ substr(auth()->user()->name, 0, 1) }}</div>
                            @endif
                        </div>
                        <svg id="mobile-arrow" class="w-3.5 h-3.5 text-gray-400 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>

                    <!-- Dropdown Overlay Menu Mobile -->
                    <div id="mobile-user-menu" class="hidden absolute right-0 top-full mt-2 w-52 bg-white rounded-2xl border border-gray-100 shadow-xl p-1.5 space-y-0.5 z-50">
                        <div class="px-3 py-2 border-b border-gray-50 mb-1">
                            <p class="text-xs font-bold text-gray-700 truncate">{{ auth()->user()->name }}</p>
                            <p class="text-[10px] text-gray-400 font-semibold uppercase mt-0.5">Admin</p>
                        </div>
                        
                        <div class="border-t border-gray-50 pt-1 mt-1">
                            @include('layouts._partials_admin_dropdown_items')
                        </div>
                    </div>
                </div>
            </header>

            <!-- Wadah Inject Konten Halaman -->
            <main class="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-50/50">
                @yield('content')
            </main>
            
        </div>
    </div>

    <script>
        // Fungsi pembantu membuka/menutup menu dropdown
        function toggleDropdown(menuId, arrowId) {
            const menu = document.getElementById(menuId);
            const arrow = document.getElementById(arrowId);
            
            menu.classList.toggle('hidden');
            if(arrow) arrow.classList.toggle('rotate-180');
        }

        // Penutupan otomatis saat klik di luar area dropdown
        window.addEventListener('click', function(e) {
            // Tutup Dropdown Desktop
            if (!e.target.closest('.desktop-dropdown-container')) {
                const dMenu = document.getElementById('desktop-menu');
                const dArrow = document.getElementById('desktop-arrow');
                if(dMenu) dMenu.classList.add('hidden');
                if(dArrow) dArrow.classList.remove('rotate-180');
            }
            // Tutup Dropdown Avatar Mobile
            if (!e.target.closest('.mobile-dropdown-container')) {
                const mMenu = document.getElementById('mobile-user-menu');
                const mArrow = document.getElementById('mobile-arrow');
                if(mMenu) mMenu.classList.add('hidden');
                if(mArrow) mArrow.classList.remove('rotate-180');
            }
        });
    </script>
    @stack('scripts')
</body>
</html>