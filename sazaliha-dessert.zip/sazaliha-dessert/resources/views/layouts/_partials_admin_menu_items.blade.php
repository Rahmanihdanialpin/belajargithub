<a href="{{ route('admin.dashboard') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
    Dashboard Admin
</a>

<a href="{{ route('admin.pos.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.pos.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
    Point of Sale (POS)
</a>

<a href="{{ route('admin.ingredients.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.ingredients.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
    Bahan Baku
</a>

<a href="{{ route('admin.products.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.products.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
    Produk (Menu)
</a>

<a href="{{ route('admin.orders.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.orders.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
    </svg>
    Pesanan
</a>

<a href="{{ route('admin.reviews.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.reviews.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
    Ulasan Pelanggan
</a>

<a href="{{ route('admin.reports.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.reports.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
    Laporan Keuangan
</a>

 @can('admin.feature-toggle.manage')
<a href="{{ route('admin.feature-toggles.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.feature-toggles.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5h2M11 19h2M5 11v2M19 11v2M7.05 7.05l1.42 1.42M15.53 15.53l1.42 1.42M16.95 7.05l-1.42 1.42M8.47 15.53l-1.42 1.42M12 8a4 4 0 100 8 4 4 0 000-8z"/></svg>
    Fitur Admin
</a>
@endcan
@if(auth()->user()->hasRole('super admin'))
<a href="{{ route('admin.users.index') }}" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-3-3h-1m-4 5H7a3 3 0 01-3-3v-2a3 3 0 013-3h1m6 10v-2a4 4 0 00-4-4H7m12 0a4 4 0 00-4 4v2m4-4a4 4 0 00-4-4m-4 0a4 4 0 014 4"/></svg>
    Manajemen Pengguna
</a>
@endif