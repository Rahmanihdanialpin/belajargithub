@extends('layouts.admin')

@section('title', 'Ulasan Pelanggan')

@section('content')
<div class="max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-6">
    
    <div class="mb-6">
        <h1 class="text-xl sm:text-2xl font-bold text-gray-800">Ulasan Pelanggan</h1>
        <p class="text-xs sm:text-sm text-gray-500 mt-0.5">Pantau feedback dan tingkat kepuasan objektif dari pembeli Sazaliha Dessert.</p>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div class="bg-white p-4 sm:p-5 rounded-2xl border border-pink-50 shadow-sm flex items-center gap-4">
            <div class="w-10 h-10 sm:w-12 sm:h-12 bg-pink-50 rounded-xl flex items-center justify-center text-pink-600 shrink-0">
                <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1m8l-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v3l4-3h9a2 2 0 002-2v-6a2 2 0 00-2-2z"/>
                </svg>
            </div>
            <div>
                <p class="text-[10px] sm:text-xs font-medium text-gray-400 uppercase tracking-wider">Total Ulasan Masuk</p>
                <h3 class="text-lg sm:text-2xl font-bold text-gray-800 mt-0.5">{{ $totalReviews }} Ulasan</h3>
            </div>
        </div>

        <div class="bg-white p-4 sm:p-5 rounded-2xl border border-pink-50 shadow-sm flex items-center gap-4">
            <div class="w-10 h-10 sm:w-12 sm:h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500 shrink-0">
                <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                </svg>
            </div>
            <div>
                <p class="text-[10px] sm:text-xs font-medium text-gray-400 uppercase tracking-wider">Rata-Rata Kepuasan</p>
                <div class="flex items-baseline sm:items-center gap-1.5 mt-0.5">
                    <h3 class="text-lg sm:text-2xl font-bold text-gray-800">{{ $averageRating }}</h3>
                    <span class="text-[10px] sm:text-sm text-gray-400">/ 5.0 Skala</span>
                </div>
            </div>
        </div>
    </div>

    @if(session('success'))
        <div class="mb-4 p-3 sm:p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl text-xs sm:text-sm shadow-sm flex items-center gap-2">
            <svg class="w-4 h-4 sm:w-5 h-5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <span>{{ session('success') }}</span>
        </div>
    @endif

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        
        <div class="block md:hidden divide-y divide-gray-100">
            @forelse($reviews as $review)
                <div class="p-4 space-y-3">
                    <div class="flex justify-between items-start gap-2">
                        <div>
                            <h4 class="font-semibold text-gray-900 text-sm">{{ $review->user->name ?? 'Anonim' }}</h4>
                            <p class="text-xs text-gray-400">{{ $review->user->email ?? 'Tidak ada email' }}</p>
                        </div>
                        <span class="text-[10px] text-gray-400 whitespace-nowrap">
                            {{ $review->created_at ? $review->created_at->format('d M Y') : '-' }}
                        </span>
                    </div>

                    <div class="flex flex-wrap items-center justify-between gap-2 bg-gray-50/70 p-2.5 rounded-xl">
                        <div class="text-xs font-medium text-pink-600">
                            🍰 {{ $review->product->name ?? 'Produk Telah Dihapus' }}
                        </div>
                        <div class="flex items-center gap-0.5 text-amber-400">
                            @for($i = 1; $i <= 5; $i++)
                                <svg class="w-3.5 h-3.5 {{ $i <= $review->rating ? 'fill-current' : 'text-gray-200' }}" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                </svg>
                            @endfor
                        </div>
                    </div>

                    <div class="text-xs sm:text-sm text-gray-600 italic break-words bg-pink-50/20 p-2.5 rounded-xl border border-pink-50/50">
                        "{{ $review->comment ?? 'Hanya memberikan rating bintang.' }}"
                    </div>

                    <div class="flex justify-end pt-1">
                        <form action="{{ route('admin.reviews.destroy', $review->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus ulasan ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-600 font-medium bg-red-50 hover:bg-red-100 rounded-xl transition">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                </svg>
                                Hapus / Moderasi
                            </button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="p-8 text-center text-xs text-gray-400 italic">
                    Belum ada ulasan yang masuk dari pelanggan Sazaliha Dessert.
                </div>
            @endforelse
        </div>

        <div class="hidden md:block overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/75 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        <th class="px-6 py-4">Pelanggan</th>
                        <th class="px-6 py-4">Produk Dessert</th>
                        <th class="px-6 py-4">Rating</th>
                        <th class="px-6 py-4">Isi Komentar / Ulasan</th>
                        <th class="px-6 py-4">Tanggal Masuk</th>
                        <th class="px-6 py-4 text-center">Aksi Moderasi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 text-sm text-gray-700">
                    @forelse($reviews as $review)
                        <tr class="hover:bg-gray-50/50 transition-colors">
                            <td class="px-6 py-4 font-medium text-gray-900">
                                {{ $review->user->name ?? 'Anonim' }}
                                <span class="block text-xs font-normal text-gray-400 mt-0.5">{{ $review->user->email ?? 'Tidak ada email' }}</span>
                            </td>
                            <td class="px-6 py-4 text-pink-600 font-medium">
                                {{ $review->product->name ?? 'Produk Telah Dihapus' }}
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-0.5 text-amber-400">
                                    @for($i = 1; $i <= 5; $i++)
                                        <svg class="w-4 h-4 {{ $i <= $review->rating ? 'fill-current' : 'text-gray-200' }}" viewBox="0 0 20 20">
                                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                        </svg>
                                    @endfor
                                </div>
                            </td>
                            <td class="px-6 py-4 max-w-xs break-words text-gray-600 italic">
                                "{{ $review->comment ?? 'Hanya memberikan rating bintang.' }}"
                            </td>
                            <td class="px-6 py-4 text-xs text-gray-400">
                                {{ $review->created_at ? $review->created_at->format('d M Y, H:i') : '-' }}
                            </td>
                            <td class="px-6 py-4 text-center">
                                <form action="{{ route('admin.reviews.destroy', $review->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus ulasan ini? Langkah moderasi ini bersifat permanen.');" class="inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="p-2 text-gray-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition-all duration-150" title="Hapus Ulasan Kasar/Spam">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                        </svg>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-gray-400 italic">
                                Belum ada ulasan atau penilaian yang masuk dari pelanggan Sazaliha Dessert.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($reviews->hasPages())
            <div class="px-4 py-3 sm:px-6 sm:py-4 bg-gray-50 border-t border-gray-100 text-xs sm:text-sm">
                {{ $reviews->links() }}
            </div>
        @endif
    </div>
</div>
@endsection