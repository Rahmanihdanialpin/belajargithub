@extends('layouts.admin')

@section('title', 'Pengaturan Fitur Admin')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl sm:text-2xl font-bold">Pengaturan Fitur Admin</h1>
        @if(session('status'))
            <div class="text-sm text-green-600">{{ session('status') }}</div>
        @endif
    </div>

<form method="POST" action="{{ route('admin.feature-toggles.update') }}" enctype="multipart/form-data">
        @csrf
        <div class="bg-white rounded-xl shadow-sm border border-pink-50 overflow-hidden">
            <div class="p-4 sm:p-6 border-b border-gray-100">
                <p class="text-sm text-gray-600">Super admin dapat menyalakan/mematikan CRUD untuk admin biasa.</p>
            </div>

            <div class="p-4 sm:p-6">
                <div class="space-y-4">
                    @foreach($resources as $resource)
                        @php
                            $row = $rows[$resource] ?? null;
                        @endphp
                        <div class="border border-gray-100 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-3">
                                <div class="font-semibold">{{ ucfirst($resource) }}</div>
                            </div>

                            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                                @foreach(['can_create'=>'Create','can_read'=>'Read','can_update'=>'Update','can_delete'=>'Delete'] as $key=>$label)
                                    @php
                                        $checked = $row ? (bool)$row->{$key} : ($key==='can_read');
                                    @endphp
                                    <label class="flex items-center gap-2 text-sm text-gray-700">
                                        <input type="checkbox" name="resources[{{ $resource }}][{{ $key }}]" value="1" {{ $checked ? 'checked' : '' }}>
                                        {{ $label }}
                                    </label>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="mt-6 flex justify-end gap-3">
                    <a href="{{ route('admin.dashboard') }}" class="px-4 py-2 rounded-lg border border-gray-200 text-sm">Batal</a>
                    <button type="submit" class="px-4 py-2 rounded-lg bg-pink-500 text-white text-sm hover:bg-pink-600">Simpan</button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

