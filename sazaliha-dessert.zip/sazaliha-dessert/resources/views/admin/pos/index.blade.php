@extends('layouts.admin') {{-- Sesuaikan dengan nama master layout adminmu --}}

@section('content')
<div class="container mx-auto px-4 py-6" x-data="posSystem()">
    <div class="flex flex-col lg:flex-row gap-6">
        
        <div class="w-full lg:w-2/3 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Point of Sale (POS) - Sazaliha Dessert</h1>
                <div class="relative w-64">
                    <input type="text" x-model="searchQuery" placeholder="Cari menu dessert..." 
                           class="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-3 gap-4 overflow-y-auto max-h-[calc(100vh-220px)] pr-2">
                @foreach($products as $product)
                <div x-show="matchSearch('{{ strtolower($product->name) }}')"
                     @click="addToCart({{ $product->id }}, '{{ $product->name }}', {{ $product->price }})"
                     class="group bg-amber-50/30 hover:bg-amber-50 border border-gray-200 hover:border-amber-400 p-4 rounded-xl cursor-pointer transition-all duration-200 flex flex-col justify-between shadow-sm">
                    
                    {{-- Foto Menu --}}
                    <div class="w-full h-32 bg-gray-100 rounded-lg overflow-hidden mb-3">
                        @if($product->image)
                            <img src="{{ asset('storage/' . $product->image) }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                        @else
                            <div class="w-full h-full flex items-center justify-center text-gray-400 bg-gray-200 text-xs">No Image</div>
                        @endif
                    </div>

                    {{-- Info Detail Produk --}}
                    <div>
                        <h3 class="font-semibold text-gray-800 text-sm md:text-base line-clamp-2">{{ $product->name }}</h3>
                        <div class="flex justify-between items-center mt-2">
                            <span class="text-amber-700 font-bold text-sm">Rp {{ number_format($product->price, 0, ',', '.') }}</span>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        <div class="w-full lg:w-1/3 flex flex-col gap-4">
            
            <form action="{{ route('admin.pos.store') }}" method="POST" class="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col justify-between flex-1">
                @csrf
                <div>
                    <h2 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <span>🛒 Keranjang Kasir</span>
                    </h2>

                    <template x-for="(item, index) in cart" :key="item.product_id">
                        <div>
                            <input type="hidden" :name="'items['+index+'][product_id]'" :value="item.product_id">
                            <input type="hidden" :name="'items['+index+'][quantity]'" :value="item.quantity">
                        </div>
                    </template>

                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <div>
                            <label class="text-xs font-semibold text-gray-600 block mb-1">Nama Pelanggan</label>
                            <input type="text" name="customer_name" placeholder="Pelanggan Umum" class="w-full p-2 text-sm border rounded-lg focus:ring-1 focus:ring-amber-500">
                        </div>
                        <div>
                            <label class="text-xs font-semibold text-gray-600 block mb-1">No. HP (WhatsApp)</label>
                            <input type="text" name="customer_phone" placeholder="08..." class="w-full p-2 text-sm border rounded-lg focus:ring-1 focus:ring-amber-500">
                        </div>
                    </div>

                    <hr class="border-dashed my-3">

                    <div class="overflow-y-auto max-h-60 pr-1 space-y-3">
                        <template x-if="cart.length === 0">
                            <div class="text-center py-8 text-gray-400 text-sm">Belum ada menu yang dipilih</div>
                        </template>

                        <template x-for="item in cart" :key="item.product_id">
                            <div class="flex justify-between items-center bg-gray-50 p-2 rounded-lg text-sm border">
                                <div class="w-1/2">
                                    <span class="font-medium text-gray-800 block truncate" x-text="item.name"></span>
                                    <span class="text-xs text-amber-700 font-semibold" x-text="formatRupiah(item.price)"></span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <button type="button" @click="decreaseQty(item.product_id)" class="w-6 h-6 bg-gray-200 hover:bg-gray-300 rounded text-sm font-bold">-</button>
                                    <span class="w-6 text-center font-semibold" x-text="item.quantity"></span>
                                    <button type="button" @click="increaseQty(item.product_id)" class="w-6 h-6 bg-gray-200 hover:bg-gray-300 rounded text-sm font-bold">+</button>
                                </div>
                                <span class="font-bold text-gray-700 text-right w-20" x-text="formatRupiah(item.price * item.quantity)"></span>
                            </div>
                        </template>
                    </div>
                </div>

                <div class="mt-6 pt-4 border-t border-gray-100 space-y-3">
                    <div class="flex justify-between text-gray-700 font-medium">
                        <span>Subtotal Jual:</span>
                        <span class="font-bold text-gray-900" x-text="formatRupiah(totalCartValue())"></span>
                    </div>

                    <div>
                        <label class="text-xs font-bold text-gray-600 block mb-1">Metode Pembayaran</label>
                        <select name="payment_method" x-model="paymentMethod" class="w-full p-2 text-sm font-semibold border rounded-lg bg-gray-50 focus:ring-1 focus:ring-amber-500">
                            <option value="cash">Tunai / Cash</option>
                            <option value="qris">QRIS Statis</option>
                        </select>
                    </div>

                    <div x-show="paymentMethod === 'cash'" x-transition>
                        <label class="text-xs font-bold text-gray-600 block mb-1">Uang Dibayar (Rp)</label>
                        <input type="number" name="amount_paid" x-model.number="amountPaid" :required="paymentMethod === 'cash'" min="0"
                               class="w-full p-2 font-bold text-lg text-right border rounded-lg focus:ring-2 focus:ring-amber-500 text-green-700 bg-green-50/50">
                    </div>

                    <div x-show="paymentMethod === 'qris'" x-transition class="bg-amber-50/50 p-3 rounded-xl border border-amber-200 flex flex-col items-center justify-center text-center">
                        <p class="text-[11px] font-bold text-amber-800 uppercase tracking-wider mb-2">Scan QRIS Sazaliha Dessert</p>
                        <img src="{{ asset('images/qris.png') }}" alt="QRIS Code" class="w-40 h-40 object-contain bg-white p-1 rounded-lg border shadow-sm">
                        <p class="text-[10px] text-gray-400 mt-1.5">Uang otomatis terset senilai total belanja (Uang Pas)</p>
                    </div>

                    <div class="flex justify-between items-center p-3 rounded-lg" :class="changeAmount() >= 0 ? 'bg-amber-50' : 'bg-red-50'">
                        <span class="text-sm font-medium text-gray-700">Status Kembalian:</span>
                        <span class="text-lg font-black" :class="changeAmount() >= 0 ? 'text-amber-800' : 'text-red-600'" 
                              x-text="paymentMethod === 'qris' ? 'Rp 0 (Uang Pas)' : (changeAmount() >= 0 ? formatRupiah(changeAmount()) : 'Uang Kurang!')"></span>
                    </div>

                    <button type="submit" :disabled="cart.length === 0 || (paymentMethod === 'cash' && changeAmount() < 0)"
                            class="w-full py-3 bg-amber-600 hover:bg-amber-700 disabled:bg-gray-300 text-white font-bold rounded-xl shadow-md transition duration-200 mt-2 text-center block">
                        🔒 Kunci & Proses Transaksi POS
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<script>
function posSystem() {
    return {
        cart: [],
        searchQuery: '',
        paymentMethod: 'cash',
        amountPaid: 0,

        // Menggunakan init bawaan alpine untuk memantau perubahan select secara realtime
        init() {
            this.$watch('paymentMethod', value => {
                if (value === 'qris') {
                    this.amountPaid = this.totalCartValue();
                } else {
                    this.amountPaid = 0; // reset jika kembali ke cash
                }
            });
        },

        addToCart(id, name, price) {
            let found = this.cart.find(item => item.product_id === id);
            if (found) {
                found.quantity++;
            } else {
                this.cart.push({
                    product_id: id,
                    name: name,
                    price: price,
                    quantity: 1
                });
            }
            // Sinkronisasi ulang jika menambah barang saat posisi select berada di QRIS
            if (this.paymentMethod === 'qris') {
                this.amountPaid = this.totalCartValue();
            }
        },
        increaseQty(id) {
            let found = this.cart.find(item => item.product_id === id);
            if (found) {
                found.quantity++;
                if (this.paymentMethod === 'qris') this.amountPaid = this.totalCartValue();
            }
        },
        decreaseQty(id) {
            let found = this.cart.find(item => item.product_id === id);
            if (found) {
                found.quantity--;
                if (found.quantity <= 0) {
                    this.cart = this.cart.filter(item => item.product_id !== id);
                }
                if (this.paymentMethod === 'qris') this.amountPaid = this.totalCartValue();
            }
        },
        totalCartValue() {
            return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        },
        changeAmount() {
            if (this.paymentMethod === 'qris') return 0;
            return this.amountPaid - this.totalCartValue();
        },
        matchSearch(productName) {
            if (!this.searchQuery) return true;
            return productName.includes(this.searchQuery.toLowerCase());
        },
        formatRupiah(value) {
            return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
        }
    }
}
</script>
@endsection