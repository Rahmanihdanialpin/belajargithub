@extends('layouts.admin')

@section('title', 'Tambah Produk')

@section('content')
<div class="max-w-3xl"> 
    <div class="flex items-center gap-2 mb-6">
        <a href="{{ route('admin.products.index') }}" class="text-gray-500 hover:text-gray-700">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        </a>
        <h1 class="text-2xl font-bold text-gray-800">Tambah Produk Baru</h1>
    </div>

    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-6">
        <form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="space-y-6">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Produk</label>
                        <input type="text" name="name" required value="{{ old('name') }}" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                        @error('name')<p class="text-red-500 text-sm mt-1">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                        <select name="category_id" required class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                            <option value="">Pilih Kategori</option>
                            @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ old('category_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                            @endforeach
                        </select>
                        @error('category_id')<p class="text-red-500 text-sm mt-1">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                        <textarea name="description" rows="3" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">{{ old('description') }}</textarea>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Harga Jual</label>
                            <input type="number" name="price" required min="0" value="{{ old('price') }}" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                            @error('price')<p class="text-red-500 text-sm mt-1">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Harga Modal</label>
                            {{-- 🛠️ PERBAIKAN 1: Tambahkan id="cost_price" dan buat readonly agar mutlak diisi oleh kalkulasi resep --}}
                            <input type="number" name="cost_price" id="cost_price" readonly required min="0" value="{{ old('cost_price', 0) }}" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-500 font-semibold outline-none cursor-not-allowed transition">
                            <span class="text-[10px] text-amber-600 mt-1 block">💡 Otomatis terhitung berdasarkan resep di bawah</span>
                            @error('cost_price')<p class="text-red-500 text-sm mt-1">{{ $message }}</p>@enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Gambar Produk</label>
                        <input type="file" name="image" accept="image/*" class="w-full px-4 py-2.5 rounded-lg border border-gray-200 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-pink-50 file:text-pink-700 hover:file:bg-pink-100 transition">
                        @error('image')<p class="text-red-500 text-sm mt-1">{{ $message }}</p>@enderror
                    </div>

                    <div class="flex items-center gap-2">
                        <input type="checkbox" name="is_active" value="1" checked id="is_active" class="w-4 h-4 text-pink-500 border-gray-300 rounded focus:ring-pink-400">
                        <label for="is_active" class="text-sm text-gray-700">Produk aktif (ditampilkan di toko)</label>
                    </div>
                </div>

                <hr class="border-gray-100">

                <div>
                    <div class="flex items-center justify-between mb-3">
                        <div>
                            <h3 class="text-base font-semibold text-gray-800">Resep Kebutuhan Bahan Baku</h3>
                            <p class="text-xs text-gray-400">Tentukan bahan baku yang terpotong saat produk ini diproses</p>
                        </div>
                        <button type="button" id="add-ingredient-btn" class="inline-flex items-center gap-1 px-3 py-1.5 bg-pink-50 hover:bg-pink-100 text-pink-600 rounded-lg text-xs font-semibold transition">
                            ➕ Tambah Bahan
                        </button>
                    </div>

                    @error('ingredients')<p class="text-red-500 text-sm mb-2">{{ $message }}</p>@enderror

                    <div id="recipe-container" class="space-y-3">
                        <div class="flex items-center gap-3 recipe-row bg-gray-50 p-3 rounded-xl border border-gray-100">
                            <div class="flex-1">
                                <label class="block text-xs font-medium text-gray-500 mb-1">Pilih Bahan Baku</label>
                                {{-- 🛠️ PERBAIKAN 2: Tambahkan class ingredient-select --}}
                                <select name="ingredients[0][ingredient_id]" required class="ingredient-select w-full px-3 py-2 text-sm rounded-lg border border-gray-200 bg-white focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                                    <option value="">-- Pilih Bahan --</option>
                                    @foreach($ingredients as $ing)
                                        {{-- Kita sisipkan cost_per_unit ke dalam data-attribute agar bisa dibaca JS --}}
                                        <option value="{{ $ing->id }}" data-cost="{{ $ing->cost_per_unit }}">{{ $ing->name }} ({{ $ing->unit }})</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="w-1/3">
                                <label class="block text-xs font-medium text-gray-500 mb-1">Jumlah Dibutuhkan</label>
                                {{-- 🛠️ PERBAIKAN 3: Tambahkan class quantity-input --}}
                                <input type="number" name="ingredients[0][quantity_needed]" step="0.01" min="0.01" required placeholder="0.00" class="quantity-input w-full px-3 py-2 text-sm rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                            </div>
                            <div class="pt-5">
                                <button type="button" class="remove-ingredient-btn p-2 bg-white text-gray-400 hover:text-red-500 rounded-lg border border-gray-100 transition shadow-sm hidden">
                                    🗑️
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-8 flex gap-3 border-t border-gray-50 pt-5">
                <a href="{{ route('admin.products.index') }}" class="px-6 py-2.5 border border-gray-200 text-gray-600 rounded-lg font-medium hover:bg-gray-50 transition">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-pink-500 text-white rounded-lg font-medium hover:bg-pink-600 transition">Simpan Produk</button>
            </div>
        </form>
    </div>
</div>

{{-- 🛠️ PERBAIKAN MASTER JAVASCRIPT LOGIC --}}
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const container = document.getElementById('recipe-container');
        const addBtn = document.getElementById('add-ingredient-btn');
        const costPriceInput = document.getElementById('cost_price');
        let rowIndex = 1;

        // Fungsi Utama untuk menghitung total HPP secara keseluruhan
        function calculateTotalCost() {
            let totalCost = 0;
            const rows = container.querySelectorAll('.recipe-row');

            rows.forEach(row => {
                const select = row.querySelector('.ingredient-select');
                const qtyInput = row.querySelector('.quantity-input');

                if (select && qtyInput) {
                    const selectedOption = select.options[select.selectedIndex];
                    const quantity = parseFloat(qtyInput.value) || 0;
                    
                    // Ambil harga cost_per_unit dari atribut data-cost yang sudah dipasang di blade
                    const costPerUnit = selectedOption ? parseFloat(selectedOption.getAttribute('data-cost')) || 0 : 0;

                    totalCost += quantity * costPerUnit;
                }
            });

            // Set nilai ke input harga modal (dibulatkan)
            costPriceInput.value = Math.round(totalCost);
        }

        // Delegasi Event Listener untuk mendeteksi setiap perubahan input takaran atau select bahan baku
        container.addEventListener('input', function(e) {
            if (e.target.classList.contains('quantity-input') || e.target.classList.contains('ingredient-select')) {
                calculateTotalCost();
            }
        });

        container.addEventListener('change', function(e) {
            if (e.target.classList.contains('ingredient-select')) {
                calculateTotalCost();
            }
        });

        // Handler Tambah Baris Bahan Baku
        addBtn.addEventListener('click', function() {
            const firstRow = document.querySelector('.recipe-row');
            const newRow = firstRow.cloneNode(true);
            
            const select = newRow.querySelector('.ingredient-select');
            const input = newRow.querySelector('.quantity-input');
            const deleteBtn = newRow.querySelector('.remove-ingredient-btn');

            select.name = `ingredients[${rowIndex}][ingredient_id]`;
            select.value = "";
            
            input.name = `ingredients[${rowIndex}][quantity_needed]`;
            input.value = "";

            deleteBtn.classList.remove('hidden');
            container.appendChild(newRow);
            rowIndex++;
            
            // Pasang fungsi hapus pada tombol baru & kalkulasi ulang setelah dihapus
            deleteBtn.addEventListener('click', function() {
                newRow.remove();
                calculateTotalCost();
            });
        });

        // Pastikan baris pertama bawaan HTML juga bisa dihapus jika ditambahkan tombol hapus manual kelak
        const initialDeleteBtn = document.querySelector('.recipe-row .remove-ingredient-btn');
        if (initialDeleteBtn) {
            initialDeleteBtn.addEventListener('click', function() {
                this.closest('.recipe-row').remove();
                calculateTotalCost();
            });
        }
    });
</script>
@endsection