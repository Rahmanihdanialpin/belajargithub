@extends('layouts.admin')

@section('title', 'Manajemen Pengguna')

@section('content')
<div class="flex flex-col gap-5 sm:gap-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3.5">
        <div>
            <h1 class="text-xl sm:text-2xl font-black tracking-tight text-gray-800">Manajemen Pengguna</h1>
            <p class="text-xs sm:text-sm text-gray-400 font-medium mt-0.5">Kelola peran pengguna dan pembatasan hak akses sistem admin.</p>
        </div>
        <div class="text-xs sm:text-sm text-pink-700 bg-pink-50/60 border border-pink-100 rounded-xl px-4 py-3 font-semibold shadow-sm md:max-w-xs">
            📢 Hanya Super Admin yang dapat memodifikasi tingkatan peran pengguna di halaman ini.
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        
        <div class="block sm:hidden divide-y divide-gray-150">
            @forelse($users as $user)
                <div class="p-4 flex flex-col gap-3 hover:bg-gray-50/40 transition">
                    <div class="flex items-start justify-between gap-2">
                        <div>
                            <div class="text-sm font-bold text-gray-800 leading-tight">{{ $user->name }}</div>
                            <div class="text-xs text-gray-400 font-medium break-all mt-0.5">{{ $user->email }}</div>
                        </div>
                        <a href="{{ route('admin.users.edit', $user) }}" class="shrink-0 inline-flex items-center justify-center px-3 py-1.5 rounded-lg border border-gray-200 bg-white text-xs font-bold text-gray-700 hover:bg-pink-50 hover:text-pink-600 hover:border-pink-200 transition shadow-xs active:scale-98">
                            Ubah Peran
                        </a>
                    </div>
                    
                    <div class="flex flex-wrap gap-2 pt-1">
                        @if($user->hasRole('super admin'))
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-md bg-rose-50 text-rose-700 text-[11px] font-bold border border-rose-100">Super Admin</span>
                        @elseif($user->hasRole('admin'))
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-md bg-pink-50 text-pink-700 text-[11px] font-bold border border-pink-100">Admin</span>
                        @else
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-md bg-gray-100 text-gray-600 text-[11px] font-bold">Pengguna Biasa</span>
                        @endif

                        @if($user->hasVerifiedEmail())
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-[11px] font-bold border border-emerald-100">Terverifikasi</span>
                        @else
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-md bg-yellow-50 text-yellow-700 text-[11px] font-bold border border-yellow-100">Belum Verifikasi</span>
                        @endif
                    </div>
                </div>
            @empty
                <div class="p-8 text-center text-xs text-gray-400 font-medium">Tidak ada data pengguna ditemukan.</div>
            @endforelse
        </div>

        <div class="hidden sm:block overflow-x-auto">
            <table class="w-full text-sm text-left whitespace-nowrap">
                <thead class="bg-gray-50 text-gray-400 font-bold uppercase tracking-wider text-xs border-b border-gray-100">
                    <tr>
                        <th class="px-5 py-3.5 font-bold">Nama</th>
                        <th class="px-5 py-3.5 font-bold">Email</th>
                        <th class="px-5 py-3.5 font-bold">Peran</th>
                        <th class="px-5 py-3.5 font-bold">Verifikasi Email</th>
                        <th class="px-5 py-3.5 font-bold text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    @forelse($users as $user)
                        <tr class="hover:bg-gray-50/50 transition">
                            <td class="px-5 py-3.5">
                                <div class="font-bold text-gray-800">{{ $user->name }}</div>
                            </td>
                            <td class="px-5 py-3.5 text-gray-600 font-medium">{{ $user->email }}</td>
                            <td class="px-5 py-3.5">
                                @if($user->hasRole('super admin'))
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold border border-rose-100">Super Admin</span>
                                @elseif($user->hasRole('admin'))
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full bg-pink-50 text-pink-700 text-xs font-bold border border-pink-100">Admin</span>
                                @else
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-xs font-bold">Pengguna Biasa</span>
                                @endif
                            </td>
                            <td class="px-5 py-3.5">
                                @if($user->hasVerifiedEmail())
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-100">Terverifikasi</span>
                                @else
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full bg-yellow-50 text-yellow-700 text-xs font-bold border border-yellow-100">Belum</span>
                                @endif
                            </td>
                            <td class="px-5 py-3.5 text-right">
                                <a href="{{ route('admin.users.edit', $user) }}" class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-bold text-gray-700 hover:bg-pink-50 hover:text-pink-600 hover:border-pink-200 transition shadow-xs">
                                    Ubah Peran
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-5 py-10 text-center text-gray-400 font-medium">Tidak ada pengguna ditemukan.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="p-4 border-t border-gray-100 bg-white">
            {{ $users->links() }}
        </div>
    </div>
</div>
@endsection