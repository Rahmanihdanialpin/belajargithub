@extends('layouts.admin')

@section('title', 'Ubah Peran Pengguna')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-6">
        <div class="mb-4">
            <h1 class="text-2xl font-bold text-gray-800">Ubah Peran Pengguna</h1>
            <p class="text-gray-500">Pilih peran baru untuk pengguna tersebut.</p>
        </div>

        @if(session('error'))
            <div class="mb-4 px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-red-700">{{ session('error') }}</div>
        @endif

        <form action="{{ route('admin.users.update', $user) }}" method="POST">
            @csrf
            @method('PATCH')

            <div class="grid gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Nama</label>
                    <input type="text" value="{{ $user->name }}" disabled class="mt-1 block w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-gray-700" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="text" value="{{ $user->email }}" disabled class="mt-1 block w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-gray-700" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700" for="role">Peran</label>
                    <select id="role" name="role" class="mt-1 block w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-gray-700">
                        <option value="" {{ old('role', $user->roles->first()?->name) ? '' : 'selected' }}>Pengguna Biasa</option>
                        @foreach($roles as $roleValue => $roleLabel)
                            <option value="{{ $roleValue }}" {{ old('role', $user->roles->first()?->name) === $roleValue ? 'selected' : '' }}>{{ $roleLabel }}</option>
                        @endforeach
                    </select>
                    @error('role')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="grid gap-2 sm:grid-cols-2">
                    <a href="{{ route('admin.users.index') }}" class="inline-flex items-center justify-center px-4 py-3 rounded-lg border border-gray-200 text-sm text-gray-700 hover:bg-gray-50">Batal</a>
                    <button type="submit" class="inline-flex items-center justify-center px-4 py-3 rounded-lg bg-pink-500 text-white text-sm hover:bg-pink-600">Simpan Perubahan</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
