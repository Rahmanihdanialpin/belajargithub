<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Keuangan Sazaliha</title>
    <style>
        body { font-family: 'Helvetica', Arial, sans-serif; font-size: 12px; color: #333; }
        .header { text-align: center; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #e11d48; }
        .header h1 { color: #e11d48; margin: 0; font-size: 20px; }
        .header p { margin: 5px 0; color: #666; }
        .summary { display: flex; justify-content: space-between; margin-bottom: 20px; }
        .summary-box { width: 30%; background: #fdf2f8; padding: 10px; border-radius: 8px; text-align: center; }
        .summary-box h3 { margin: 0; font-size: 11px; color: #666; }
        .summary-box p { margin: 5px 0 0; font-size: 14px; font-weight: bold; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #fdf2f8; color: #e11d48; padding: 8px; text-align: left; font-size: 11px; border-bottom: 2px solid #e11d48; }
        td { padding: 8px; border-bottom: 1px solid #eee; }
        tr:nth-child(even) { background: #fafafa; }
        .text-right { text-align: right; }
        .text-green { color: #16a34a; }
        .text-red { color: #dc2626; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sazaliha Dessert</h1>
        <p>Laporan Keuangan</p>
        <p>Periode: {{ $startDate->format('d M Y') }} - {{ $endDate->format('d M Y') }}</p>
    </div>

    <div class="summary">
        <div class="summary-box">
            <h3>Total Pendapatan</h3>
            <p>Rp {{ number_format($totalRevenue, 0, ',', '.') }}</p>
        </div>
        <div class="summary-box">
            <h3>Total Modal</h3>
            <p>Rp {{ number_format($totalCost, 0, ',', '.') }}</p>
        </div>
        <div class="summary-box">
            <h3>Laba Kotor</h3>
            <p class="{{ $grossProfit >= 0 ? 'text-green' : 'text-red' }}">Rp {{ number_format($grossProfit, 0, ',', '.') }}</p>
        </div>
    </div>

    <h3 style="color: #e11d48; margin-bottom: 5px;">Rekap Harian</h3>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Jumlah Order</th>
                <th class="text-right">Pendapatan</th>
                <th class="text-right">Biaya Modal</th>
                <th class="text-right">Laba</th>
            </tr>
        </thead>
        <tbody>
            @forelse($dailyReport as $date => $report)
            <tr>
                <td>{{ \Carbon\Carbon::parse($date)->format('d M Y') }}</td>
                <td>{{ $report['orders'] }}</td>
                <td class="text-right">Rp {{ number_format($report['revenue'], 0, ',', '.') }}</td>
                <td class="text-right">Rp {{ number_format($report['cost'], 0, ',', '.') }}</td>
                <td class="text-right {{ $report['profit'] >= 0 ? 'text-green' : 'text-red' }}">Rp {{ number_format($report['profit'], 0, ',', '.') }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align: center; color: #999;">Tidak ada data.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <div class="footer">
        Dicetak pada {{ now()->format('d M Y H:i') }} | Sazaliha Dessert
    </div>
</body>
</html>
