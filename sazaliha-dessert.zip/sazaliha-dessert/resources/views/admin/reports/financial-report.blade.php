<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: 'Arial', sans-serif; color: #333; }
        .header h1 { color: #e11d48; margin: 0; font-size: 16px; font-weight: bold; }
        .header p { margin: 5px 0; color: #666; font-size: 11px; }
        
        /* Tabel Summary Horizontal */
        .summary-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .summary-table th { background: #fdf2f8; color: #666; padding: 10px; border: 1px solid #fbcfe8; font-size: 10px; text-transform: uppercase; }
        .summary-table td { padding: 10px; border: 1px solid #fbcfe8; text-align: center; font-weight: bold; font-size: 12px; }
        
        /* Tabel Data */
        table.data-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #fdf2f8; color: #e11d48; padding: 8px; text-align: left; font-size: 11px; font-weight: bold; border: 1px solid #e11d48; }
        td { padding: 8px; border: 1px solid #eee; font-size: 11px; }
        
        .text-right { text-align: right; }
        .text-green { color: #16a34a; }
        .text-red { color: #dc2626; }
        .footer { margin-top: 30px; text-align: center; font-size: 9px; color: #999; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sazaliha Dessert</h1>
        <p>Laporan Keuangan</p>
        <p>Periode: {{ $startDate->format('d M Y') }} - {{ $endDate->format('d M Y') }}</p>
    </div>

    <table class="summary-table" border="1">
        <thead>
            <tr>
                <th>Total Pendapatan</th>
                <th>Total Modal</th>
                <th>Laba Kotor</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Rp {{ number_format($totalRevenue, 0, ',', '.') }}</td>
                <td>Rp {{ number_format($totalCost, 0, ',', '.') }}</td>
                <td class="{{ $grossProfit >= 0 ? 'text-green' : 'text-red' }}">
                    Rp {{ number_format($grossProfit, 0, ',', '.') }}
                </td>
            </tr>
        </tbody>
    </table>

    <h3 style="color: #e11d48; font-size: 12px;">Rekap Harian</h3>
    <table class="data-table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th class="text-right">Jumlah Order</th>
                <th class="text-right">Pendapatan</th>
                <th class="text-right">Biaya Modal</th>
                <th class="text-right">Laba</th>
            </tr>
        </thead>
        <tbody>
            @forelse($dailyReport as $date => $report)
            <tr>
                <td>{{ \Carbon\Carbon::parse($date)->format('d M Y') }}</td>
                <td class="text-right">{{ $report['orders'] }}</td>
                <td class="text-right">Rp {{ number_format($report['revenue'], 0, ',', '.') }}</td>
                <td class="text-right">Rp {{ number_format($report['cost'], 0, ',', '.') }}</td>
                <td class="text-right {{ $report['profit'] >= 0 ? 'text-green' : 'text-red' }}">
                    Rp {{ number_format($report['profit'], 0, ',', '.') }}
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align: center;">Tidak ada data.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <div class="footer">
        Dicetak pada {{ now()->format('d M Y H:i') }} | Sazaliha Dessert
    </div>
</body>
</html>