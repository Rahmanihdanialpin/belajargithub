@extends('layouts.admin')

@section('title', 'Dashboard Admin')

@section('content')
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
    <p class="text-gray-500">Ringkasan toko hari ini</p>
</div>

<!-- Stats Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Penjualan Hari Ini</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">Rp {{ number_format($todaySales, 0, ',', '.') }}</p>
            </div>
            <div class="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center text-2xl">💰</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Pesanan Hari Ini</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">{{ $todayOrders }}</p>
            </div>
            <div class="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center text-2xl">📦</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Menunggu Diproses</p>
                <p class="text-2xl font-bold text-amber-600 mt-1">{{ $pendingOrders }}</p>
            </div>
            <div class="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-2xl">⏳</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Produk</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">{{ $totalProducts }}</p>
            </div>
            <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-2xl">🍰</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Bahan Baku</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">{{ $totalIngredients }}</p>
            </div>
            <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center text-2xl">🧂</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Nilai Stok Bahan</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">Rp {{ number_format($totalIngredientValue, 0, ',', '.') }}</p>
            </div>
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center text-2xl">📊</div>
        </div>
    </div>
</div>

<div class="grid lg:grid-cols-3 gap-6">
    <!-- Chart -->
    <div class="lg:col-span-2 bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Grafik Penjualan 7 Hari Terakhir</h2>
        <canvas id="salesChart" height="100"></canvas>
    </div>

    <!-- Low Stock Ingredients -->
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-bold text-gray-800">Stok Bahan Baku Menipis</h2>
            @if($lowStockIngredients->count() > 0)
                <span class="bg-red-100 text-red-700 text-xs font-bold px-2 py-1 rounded-full">{{ $lowStockIngredients->count() }} item</span>
            @endif
        </div>
        <div class="space-y-3 max-h-80 overflow-y-auto">
            @forelse($lowStockIngredients as $ingredient)
            <div class="flex items-center gap-3 p-3 {{ $ingredient->status == 'habis' ? 'bg-red-50 border-red-100' : 'bg-amber-50 border-amber-100' }} rounded-lg border">
                <div class="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-xl">🧂</div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-semibold text-gray-800 truncate">{{ $ingredient->name }}</p>
                    <p class="text-xs text-gray-500">{{ $ingredient->supplier ?: 'Tanpa supplier' }}</p>
                </div>
                <span class="text-sm font-bold {{ $ingredient->status == 'habis' ? 'text-red-600' : 'text-amber-600' }}">
                    {{ number_format($ingredient->stock, 0, ',', '.') }} {{ $ingredient->unit }}
                </span>
            </div>
            @empty
            <div class="text-center py-8 text-gray-400">
                <div class="text-4xl mb-2">✅</div>
                <p class="text-sm">Semua bahan baku aman</p>
            </div>
            @endforelse
        </div>
    </div>
</div>

<!-- Additional Stats -->
<div class="grid lg:grid-cols-2 gap-6 mt-6">
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Ringkasan Minggu & Bulan Ini</h2>
        <div class="space-y-4">
            <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-600">Penjualan Minggu Ini</span>
                <span class="font-bold text-gray-800">Rp {{ number_format($weekSales, 0, ',', '.') }}</span>
            </div>
            <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-600">Penjualan Bulan Ini</span>
                <span class="font-bold text-gray-800">Rp {{ number_format($monthSales, 0, ',', '.') }}</span>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Top Kategori</h2>
        <div class="space-y-3">
            @foreach($categorySales as $cat)
            <div class="flex items-center gap-3">
                <div class="flex-1">
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-700">{{ $cat->name }}</span>
                        <span class="font-semibold text-gray-800">Rp {{ number_format($cat->total_sales ?? 0, 0, ',', '.') }}</span>
                    </div>
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <div class="bg-gradient-to-r from-pink-400 to-rose-500 h-2 rounded-full" style="width: {{ min(100, (($cat->total_sales ?? 0) / max(1, $categorySales->max('total_sales') ?? 1)) * 100) }}%"></div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

@push('scripts')
<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: {!! json_encode($chartData->pluck('date')) !!},
        datasets: [{
            label: 'Penjualan (Rp)',
            data: {!! json_encode($chartData->pluck('total')) !!},
            borderColor: '#e11d48',
            backgroundColor: 'rgba(225, 29, 72, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#e11d48',
            pointRadius: 4,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + value.toLocaleString('id-ID');
                    }
                }
            }
        }
    }
});
</script>
@endpush
@endsection
