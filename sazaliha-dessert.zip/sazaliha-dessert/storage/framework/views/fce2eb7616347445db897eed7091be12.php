<a href="<?php echo e(route('dashboard')); ?>" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
    Dashboard Saya
</a>
<a href="<?php echo e(route('orders.list')); ?>" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 <?php echo e(request()->routeIs('orders.*') ? 'active' : ''); ?>">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
    Pesanan Saya
</a>
<a href="<?php echo e(route('cart.index')); ?>" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 <?php echo e(request()->routeIs('cart.*') ? 'active' : ''); ?>">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
    Keranjang
</a>
<a href="<?php echo e(route('profile.edit')); ?>" class="w-full text-left text-sm text-slate-600 hover:bg-pink-50 hover:text-pink-600 rounded-xl transition px-4 py-2.5 flex items-center gap-3 font-semibold group">
    <svg class="w-5 h-5 group-hover:text-pink-600 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
    </svg>
    Profil Saya
</a>
<a href="<?php echo e(route('reviews.index')); ?>" class="sidebar-link flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-gray-600 <?php echo e(request()->routeIs('reviews.*') ? 'active' : ''); ?>">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>
    Ulasan Produk
</a><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/layouts/_partials_customer_menu_items.blade.php ENDPATH**/ ?>