

<?php $__env->startSection('title', 'Edit Produk & Resep'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl" x-data="recipeManager(<?php echo e(json_encode($ingredients)); ?>)">
    <div class="flex items-center gap-2 mb-6">
        <a href="<?php echo e(route('admin.products.index')); ?>" class="text-gray-500 hover:text-gray-700">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
        </a>
        <h1 class="text-2xl font-bold text-gray-800">Edit Produk & Komposisi Resep</h1>
    </div>

    <form action="<?php echo e(route('admin.products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            
            <div class="lg:col-span-1 space-y-4 bg-white rounded-xl border border-pink-50 shadow-sm p-5">
                <h3 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Informasi Dessert</h3>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Produk</label>
                    <input type="text" name="name" required value="<?php echo e(old('name', $product->name)); ?>" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition text-sm">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                    <select name="category_id" required class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition text-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $product->category_id) == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                    <textarea name="description" rows="3" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition text-sm"><?php echo e(old('description', $product->description)); ?></textarea>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Harga Jual</label>
                        <input type="number" name="price" required min="0" value="<?php echo e(old('price', $product->price)); ?>" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Harga Modal</label>
                        <input type="number" name="cost_price" readonly x-model="costPrice" class="w-full px-3 py-2 rounded-lg border border-gray-200 bg-gray-50 text-gray-500 outline-none font-semibold cursor-not-allowed text-sm">
                        <span class="text-[10px] text-amber-600 mt-1 block">💡 Otomatis dari resep</span>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Gambar Produk</label>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->image): ?>
                        <div class="mb-2">
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="h-20 rounded-lg object-cover">
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <input type="file" name="image" accept="image/*" class="w-full text-xs text-gray-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-pink-50 file:text-pink-700 hover:file:bg-pink-100 file:cursor-pointer transition">
                </div>

                
                <div class="flex items-center gap-2 pt-2">
                    
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $product->is_active) ? 'checked' : ''); ?> id="is_active" class="w-4 h-4 text-pink-500 border-gray-300 rounded focus:ring-pink-400">
                    <label for="is_active" class="text-xs text-gray-700 font-medium select-none cursor-pointer">Produk aktif (Tampilkan di toko)</label>
                </div>
            </div>

            <div class="lg:col-span-2 space-y-4 bg-white rounded-xl border border-pink-50 shadow-sm p-5">
                <div class="flex items-center justify-between border-b border-gray-100 pb-3">
                    <div>
                        <h3 class="text-sm font-bold text-gray-800">Komposisi Bahan Baku (Resep)</h3>
                        <p class="text-xs text-gray-400 mt-0.5">Tentukan takaran bahan baku yang berkurang setiap kali dessert ini terjual.</p>
                    </div>
                    <button type="button" @click="addIngredient()" class="px-3 py-1.5 bg-amber-50 border border-amber-200 text-amber-700 rounded-lg text-xs font-bold hover:bg-amber-100 transition flex items-center gap-1">
                        ➕ Tambah Bahan
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="text-xs font-semibold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                                <th class="py-2 pr-4 w-6/12">Pilih Bahan Baku</th>
                                <th class="py-2 px-2 w-5/12">Jumlah Dibutuhkan</th>
                                <th class="py-2 text-center w-1/12">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <template x-for="(item, index) in recipeIngredients" :key="index">
                                <tr>
                                    <td class="py-2.5 pr-4">
                                        <select :name="'ingredients['+index+'][ingredient_id]'" required x-model="item.ingredient_id" @change="calculateTotalCost()" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-1 focus:ring-pink-100 outline-none text-xs transition">
                                            <option value="">-- Pilih Bahan Baku --</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <option value="<?php echo e($ing->id); ?>"><?php echo e($ing->name); ?></option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                    </td>
                                    
                                    <td class="py-2.5 px-2">
                                        <div class="relative flex items-center rounded-lg shadow-sm">
                                            <input type="number" :name="'ingredients['+index+'][quantity_needed]'" step="any" required min="0.01" x-model="item.quantity_needed" @input="calculateTotalCost()" placeholder="0.00" class="w-full pl-3 pr-16 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-1 focus:ring-pink-100 outline-none text-xs transition text-right">
                                            <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                                <span class="text-xs font-semibold text-gray-400 bg-gray-50 px-2 py-1 rounded border border-gray-100" x-text="getUnit(item.ingredient_id)">-</span>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="py-2.5 text-center">
                                        <button type="button" @click="removeIngredient(index)" class="p-1.5 text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                        </button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

                <div x-show="recipeIngredients.length === 0" class="text-center py-6 border border-dashed border-gray-200 rounded-xl text-xs text-gray-400 italic">
                    Belum ada bahan baku yang dikaitkan dengan resep produk ini. Klik 'Tambah Bahan' di atas.
                </div>
            </div>
        </div>

        <div class="mt-6 flex gap-3">
            <a href="<?php echo e(route('admin.products.index')); ?>" class="px-5 py-2 border border-gray-200 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition">Batal</a>
            <button type="submit" class="px-5 py-2 bg-pink-500 text-white rounded-lg text-sm font-medium hover:bg-pink-600 transition shadow-sm">Simpan Perubahan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function recipeManager(masterIngredients) {
        return {
            masterIngredients: masterIngredients,
            
            costPrice: <?php echo e(old('cost_price', $calculatedCostPrice ?? 0)); ?>,

            recipeIngredients: <?php echo json_encode($product->ingredients->map(function($ing) {
                return [
                    'ingredient_id' => $ing->id, 'quantity_needed' => $ing->pivot->quantity_needed
                ];
            }), 512) ?>,

            init() {
                this.calculateTotalCost();
            },

            getUnit(id) {
                if (!id) return '-';
                let ingredient = this.masterIngredients.find(i => i.id == id);
                return ingredient ? ingredient.unit : '-';
            },

            calculateTotalCost() {
                let total = 0;
                this.recipeIngredients.forEach(item => {
                    if (item.ingredient_id && item.quantity_needed) {
                        let master = this.masterIngredients.find(i => i.id == item.ingredient_id);
                        if (master) {
                            let pricePerUnit = master.cost_per_unit ?? 0; 
                            total += parseFloat(item.quantity_needed) * parseFloat(pricePerUnit);
                        }
                    }
                });
                this.costPrice = Math.round(total);
            },

            addIngredient() {
                this.recipeIngredients.push({
                    ingredient_id: '',
                    quantity_needed: ''
                });
            },

            removeIngredient(index) {
                this.recipeIngredients.splice(index, 1);
                this.calculateTotalCost(); 
            }
        };
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>