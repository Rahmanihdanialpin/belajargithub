

<?php $__env->startSection('title', 'Manajemen Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">
    <div class="space-y-0.5">
        <h1 class="text-xl sm:text-2xl font-black text-gray-800 tracking-tight">Manajemen Produk</h1>
        <p class="text-xs sm:text-sm text-gray-500">Kelola stok dan data produk dessert</p>
    </div>
    
    <div class="self-start sm:self-auto w-full sm:w-auto">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="inline-flex items-center justify-center w-full sm:w-auto px-4 py-2.5 bg-pink-500 text-white text-sm rounded-xl font-bold hover:bg-pink-600 transition shadow-md shadow-pink-200 active:scale-95">
            <svg class="w-5 h-5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Tambah Produk
        </a>
    </div>
    
</div>


<div class="bg-white rounded-2xl border border-pink-50 shadow-sm overflow-hidden">
    
    <div class="grid grid-cols-1 divide-y divide-gray-100 md:hidden">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="p-4 space-y-4">
            <div class="flex items-start gap-3">
                <div class="w-12 h-12 bg-pink-50 rounded-xl flex items-center justify-center text-2xl shrink-0 border border-pink-100/50">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="w-full h-full object-cover rounded-xl">
                    <?php else: ?>
                        🍰
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="min-w-0 flex-1">
                    <div class="flex items-center justify-between gap-2">
                        <p class="font-bold text-gray-800 truncate text-sm sm:text-base"><?php echo e($product->name); ?></p>
                        <span class="px-2 py-0.5 <?php echo e($product->is_active ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-600'); ?> rounded-full text-[10px] font-bold tracking-wide shrink-0">
                            <?php echo e($product->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                    </div>
                    <p class="text-xs text-gray-400 mt-0.5 line-clamp-1"><?php echo e($product->description); ?></p>
                    <span class="inline-block px-2 py-0.5 bg-pink-50 text-pink-600 rounded-md text-[10px] font-bold mt-1.5 uppercase tracking-wider">
                        <?php echo e($product->category->name); ?>

                    </span>
                </div>
            </div>

            <div class="flex items-center justify-between bg-gray-50/70 p-2.5 rounded-xl text-xs">
                <div>
                    <span class="text-gray-400 block text-[10px] uppercase font-semibold">Harga</span>
                    <span class="font-black text-gray-800">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                </div>
                
            </div>

            <div class="flex justify-end items-center gap-2 pt-1">
                
                <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-amber-600 bg-amber-50 hover:bg-amber-100 rounded-lg transition">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    Edit
                </a>
                
               
                <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?')" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        Hapus
                    </button>
                </form>
                
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="hidden md:block overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-pink-50/50 text-gray-700 uppercase text-xs tracking-wider">
                <tr>
                    <th class="px-5 py-4">Produk</th>
                    <th class="px-5 py-4">Kategori</th>
                    <th class="px-5 py-4">Harga</th>
                    <th class="px-5 py-4">Status</th>
                    <th class="px-5 py-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="hover:bg-gray-50/80 transition">
                    <td class="px-5 py-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-pink-50 rounded-xl flex items-center justify-center text-xl shrink-0">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="w-full h-full object-cover rounded-xl">
                                <?php else: ?>
                                    🍰
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <div>
                                <p class="font-bold text-gray-800"><?php echo e($product->name); ?></p>
                                <p class="text-xs text-gray-400"><?php echo e(Str::limit($product->description, 40)); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-4">
                        <span class="px-2.5 py-1 bg-pink-50 text-pink-700 rounded-md text-xs font-bold uppercase tracking-wide"><?php echo e($product->category->name); ?></span>
                    </td>
                    <td class="px-5 py-4 font-bold text-gray-800">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                    
                    <td class="px-5 py-4">
                        <span class="px-2.5 py-1 <?php echo e($product->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'); ?> rounded-full text-xs font-bold">
                            <?php echo e($product->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                    </td>
                    <td class="px-5 py-4 text-right">
                        <div class="flex items-center justify-end gap-1.5">
                            
                            <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="p-2 text-amber-500 hover:bg-amber-50 hover:text-amber-600 rounded-xl transition" title="Edit">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            </a>
                            
                            <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?')" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="p-2 text-red-500 hover:bg-red-50 hover:text-red-600 rounded-xl transition" title="Hapus">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </form>
                            
                        </div>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="p-4 border-t border-pink-50 bg-gray-50/50">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/products/index.blade.php ENDPATH**/ ?>