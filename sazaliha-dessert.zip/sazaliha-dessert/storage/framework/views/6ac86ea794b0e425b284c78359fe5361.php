

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
    <p class="text-gray-500">Ringkasan toko hari ini</p>
</div>

<!-- Stats Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Penjualan Hari Ini</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">Rp <?php echo e(number_format($todaySales, 0, ',', '.')); ?></p>
            </div>
            <div class="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center text-2xl">💰</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Pesanan Hari Ini</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?php echo e($todayOrders); ?></p>
            </div>
            <div class="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center text-2xl">📦</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Menunggu Diproses</p>
                <p class="text-2xl font-bold text-amber-600 mt-1"><?php echo e($pendingOrders); ?></p>
            </div>
            <div class="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-2xl">⏳</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Produk</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?php echo e($totalProducts); ?></p>
            </div>
            <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-2xl">🍰</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Total Bahan Baku</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?php echo e($totalIngredients); ?></p>
            </div>
            <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center text-2xl">🧂</div>
        </div>
    </div>
    <div class="bg-white rounded-xl p-5 border border-pink-50 shadow-sm">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm text-gray-500">Nilai Stok Bahan</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">Rp <?php echo e(number_format($totalIngredientValue, 0, ',', '.')); ?></p>
            </div>
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center text-2xl">📊</div>
        </div>
    </div>
</div>

<div class="grid lg:grid-cols-3 gap-6">
    <!-- Chart -->
    <div class="lg:col-span-2 bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Grafik Penjualan 7 Hari Terakhir</h2>
        <canvas id="salesChart" height="100"></canvas>
    </div>

    <!-- Low Stock Ingredients -->
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-bold text-gray-800">Stok Bahan Baku Menipis</h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lowStockIngredients->count() > 0): ?>
                <span class="bg-red-100 text-red-700 text-xs font-bold px-2 py-1 rounded-full"><?php echo e($lowStockIngredients->count()); ?> item</span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="space-y-3 max-h-80 overflow-y-auto">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $lowStockIngredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="flex items-center gap-3 p-3 <?php echo e($ingredient->status == 'habis' ? 'bg-red-50 border-red-100' : 'bg-amber-50 border-amber-100'); ?> rounded-lg border">
                <div class="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-xl">🧂</div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-semibold text-gray-800 truncate"><?php echo e($ingredient->name); ?></p>
                    <p class="text-xs text-gray-500"><?php echo e($ingredient->supplier ?: 'Tanpa supplier'); ?></p>
                </div>
                <span class="text-sm font-bold <?php echo e($ingredient->status == 'habis' ? 'text-red-600' : 'text-amber-600'); ?>">
                    <?php echo e(number_format($ingredient->stock, 0, ',', '.')); ?> <?php echo e($ingredient->unit); ?>

                </span>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="text-center py-8 text-gray-400">
                <div class="text-4xl mb-2">✅</div>
                <p class="text-sm">Semua bahan baku aman</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>

<!-- Additional Stats -->
<div class="grid lg:grid-cols-2 gap-6 mt-6">
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Ringkasan Minggu & Bulan Ini</h2>
        <div class="space-y-4">
            <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-600">Penjualan Minggu Ini</span>
                <span class="font-bold text-gray-800">Rp <?php echo e(number_format($weekSales, 0, ',', '.')); ?></span>
            </div>
            <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-600">Penjualan Bulan Ini</span>
                <span class="font-bold text-gray-800">Rp <?php echo e(number_format($monthSales, 0, ',', '.')); ?></span>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-xl border border-pink-50 shadow-sm p-5">
        <h2 class="text-lg font-bold text-gray-800 mb-4">Top Kategori</h2>
        <div class="space-y-3">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categorySales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="flex items-center gap-3">
                <div class="flex-1">
                    <div class="flex justify-between text-sm mb-1">
                        <span class="text-gray-700"><?php echo e($cat->name); ?></span>
                        <span class="font-semibold text-gray-800">Rp <?php echo e(number_format($cat->total_sales ?? 0, 0, ',', '.')); ?></span>
                    </div>
                    <div class="w-full bg-gray-100 rounded-full h-2">
                        <div class="bg-gradient-to-r from-pink-400 to-rose-500 h-2 rounded-full" style="width: <?php echo e(min(100, (($cat->total_sales ?? 0) / max(1, $categorySales->max('total_sales') ?? 1)) * 100)); ?>%"></div>
                    </div>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chartData->pluck('date')); ?>,
        datasets: [{
            label: 'Penjualan (Rp)',
            data: <?php echo json_encode($chartData->pluck('total')); ?>,
            borderColor: '#e11d48',
            backgroundColor: 'rgba(225, 29, 72, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#e11d48',
            pointRadius: 4,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + value.toLocaleString('id-ID');
                    }
                }
            }
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>