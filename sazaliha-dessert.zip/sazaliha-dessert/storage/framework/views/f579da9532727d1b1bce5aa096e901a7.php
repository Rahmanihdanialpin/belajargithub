<?php $__env->startSection('title', 'Checkout - Sazaliha'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

    <h1 class="text-xl font-bold text-gray-800 mb-4">Checkout</h1>

    <form action="<?php echo e(route('order.store')); ?>" method="POST" id="checkout-form" class="space-y-4">
        <?php echo csrf_field(); ?>

        <div class="bg-white rounded-xl shadow-sm border border-pink-50 p-4">
            <h2 class="text-base font-bold text-gray-800 mb-3">Ringkasan Pesanan</h2>
            <div class="space-y-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center text-lg flex-shrink-0 overflow-hidden">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['product']->image): ?>
                            <img src="<?php echo e(asset('storage/' . $item['product']->image)); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            🍰
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="font-medium text-gray-800 text-sm truncate"><?php echo e($item['product']->name); ?></p>
                        <p class="text-xs text-gray-500"><?php echo e($item['quantity']); ?> x Rp <?php echo e(number_format($item['product']->price, 0, ',', '.')); ?></p>
                    </div>
                    <span class="font-semibold text-gray-800 text-sm whitespace-nowrap">Rp <?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></span>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="border-t border-gray-100 mt-3 pt-3 space-y-1.5">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Subtotal</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Ongkir</span>
                    <span class="font-medium text-green-600">Gratis</span>
                </div>
                <div class="border-t border-gray-100 pt-1.5 flex justify-between items-center">
                    <span class="font-semibold text-gray-800">Total</span>
                    <span class="text-lg font-bold text-rose-600">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->has('selected_cart_item_ids')): ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = (array) request()->input('selected_cart_item_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <input type="hidden" name="selected_cart_item_ids[]" value="<?php echo e($id); ?>">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="bg-white rounded-xl shadow-sm border border-pink-50 p-4 space-y-3">
            <h2 class="text-base font-bold text-gray-800 flex items-center gap-2">
                <span class="w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold">1</span>
                Data Pemesan
            </h2>
            <div class="grid sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Nama Lengkap</label>
                    <input type="text" name="customer_name" value="<?php echo e(auth()->user()->name ?? old('customer_name')); ?>" required class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none text-sm">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Telepon / WhatsApp</label>
                    <input type="tel" 
                        id="customer_phone"
                        name="customer_phone" 
                        value="<?php echo e(auth()->user()->phone ?? old('customer_phone')); ?>" 
                        required 
                        placeholder="Contoh: 628123456789"
                        class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none text-sm">
                </div>
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Email</label>
                <input type="email" name="customer_email" value="<?php echo e(auth()->user()->email ?? old('customer_email')); ?>" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none text-sm">
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-pink-50 p-4 space-y-3">
            <h2 class="text-base font-bold text-gray-800 flex items-center gap-2">
                <span class="w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold">2</span>
                Alamat Pengiriman
            </h2>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->check() && auth()->user()->addresses && auth()->user()->addresses->count() > 0): ?>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Gunakan Alamat Tersimpan</label>
                    <select id="address_select" name="address_id" class="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm bg-white outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-100 transition">
                        <option value="">-- Ketik Alamat Baru / Alamat Berbeda --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = auth()->user()->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <option value="<?php echo e($address->id); ?>" 
                                    data-name="<?php echo e($address->recipient_name ?? auth()->user()->name); ?>"
                                    data-phone="<?php echo e($address->phone ?? auth()->user()->phone); ?>"
                                    data-address="<?php echo e($address->full_address); ?>, <?php echo e($address->city); ?><?php echo e($address->postal_code ? ' ('.$address->postal_code.')' : ''); ?>">
                                <?php echo e($address->label ?? 'Alamat'); ?> (<?php echo e($address->city); ?>) <?php echo e($address->is_primary ? '[Utama]' : ''); ?>

                            </option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </select>
                </div>
            <?php else: ?>
                <div class="bg-pink-50/50 rounded-lg p-2.5 border border-pink-100 text-center">
                    <p class="text-[11px] text-pink-700 font-medium">Anda belum menyimpan alamat di profil. Silakan ketik alamat pengiriman manual di bawah ini.</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Alamat Lengkap Tujuan Pengiriman</label>
                <textarea id="customer_address" 
                          name="customer_address" 
                          required 
                          rows="3" 
                          placeholder="Ketik alamat lengkap (Nama Jalan, RT/RW, No. Rumah, Kelurahan, Kecamatan, Kabupaten)..."
                          class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none text-sm"><?php echo e(old('customer_address')); ?></textarea>
            </div>
            
            <div>
                <label class="block text-xs font-medium text-gray-600 mb-1">Catatan Tambahan (Opsional)</label>
                <textarea name="notes" rows="2" class="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none text-sm" placeholder="Contoh: Titipkan ke satpam depan cluster, pagar warna cokelat..."><?php echo e(old('notes')); ?></textarea>
            </div>
        </div>

        <button type="submit" class="w-full px-4 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-pink-200 transition flex items-center justify-center gap-2 text-sm">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
            Pesan Sekarang — Rp <?php echo e(number_format($total, 0, ',', '.')); ?>

        </button>

        <p class="text-[11px] text-gray-400 text-center leading-relaxed">
            Pesanan diproses setelah konfirmasi. Admin akan menghubungi via WhatsApp. Pembayaran bisa dilakukan saat pengiriman.
        </p>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const addressSelect = document.getElementById('address_select');
    const customerAddressInput = document.getElementById('customer_address');
    const nameInput = document.querySelector('input[name="customer_name"]');
    const phoneInput = document.getElementById('customer_phone');

    // 1. Auto-Fill Otomatis jika Memilih Alamat Tersimpan
    if (addressSelect && customerAddressInput) {
        // Set alamat default saat halaman pertama kali terbuka jika opsi default dipilih
        if (addressSelect.value !== "") {
            triggerAddressFill();
        }

        addressSelect.addEventListener('change', triggerAddressFill);

        function triggerAddressFill() {
            const opt = addressSelect.options[addressSelect.selectedIndex];
            const savedAddress = opt.getAttribute('data-address');

            if (savedAddress) {
                customerAddressInput.value = savedAddress;
                if(opt.dataset.name && nameInput) nameInput.value = opt.dataset.name;
                if(opt.dataset.phone && phoneInput) phoneInput.value = opt.dataset.phone;
            } else {
                // Jika user memilih ketik manual, bersihkan textarea alamat
                customerAddressInput.value = '';
            }
        }
    }

    // 2. Format Otomatis Nomor Telepon / WhatsApp (Konversi 0 ke 62)
    if (phoneInput) {
        const formatPhoneNumber = function () {
            let value = phoneInput.value.trim();
            value = value.replace(/\D/g, ''); // Bersihkan karakter non-angka

            if (value.startsWith('0')) {
                value = '62' + value.slice(1);
            }
            phoneInput.value = value;
        };

        phoneInput.addEventListener('blur', formatPhoneNumber);

        const form = phoneInput.closest('form');
        if (form) {
            form.addEventListener('submit', formatPhoneNumber);
        }
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/order/create.blade.php ENDPATH**/ ?>