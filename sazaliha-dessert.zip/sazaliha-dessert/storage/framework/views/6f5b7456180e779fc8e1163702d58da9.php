<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; background: #fdf2f8; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 16px; padding: 30px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { color: #e11d48; margin: 0; }
        .content { color: #333; line-height: 1.6; }
        .box { background: #fffbeb; padding: 15px; border-radius: 10px; margin: 15px 0; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div style="font-size: 40px;">🧁</div>
            <h1>Pesanan Diterima!</h1>
        </div>
        <div class="content">
            <p>Halo <?php echo e($order->customer_name); ?>,</p>
            <p>Terima kasih telah memesan di Sazaliha Dessert. Pesanan Anda telah kami terima dan sedang diproses.</p>
            <div class="box">
                <p><strong>No Pesanan:</strong> <?php echo e($order->order_number); ?></p>
                <p><strong>Total:</strong> Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></p>
                <p><strong>Status:</strong> <?php echo e(ucfirst($order->status)); ?></p>
            </div>
            <p>Kami akan segera menghubungi Anda untuk konfirmasi lebih lanjut.</p>
        </div>
        <div class="footer">
            Sazaliha Dessert &copy; <?php echo e(date('Y')); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/emails/order-confirmation.blade.php ENDPATH**/ ?>