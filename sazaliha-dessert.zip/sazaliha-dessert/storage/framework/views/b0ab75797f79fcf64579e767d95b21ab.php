

<?php $__env->startSection('title', 'Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // 1. Bersihkan nomor telepon customer dari karakter non-angka
    $cleanPhone = preg_replace('/[^0-9]/', '', $order->customer_phone);
    
    // 2. Susun template teks pesanan Sazaliha Dessert
    $waMessage = "Halo *" . $order->customer_name . "*,\n\n";
    $waMessage .= "Kami dari *Sazaliha Dessert* ingin mengonfirmasi pesanan Anda:\n";
    $waMessage .= "*Order Number:* " . $order->order_number . "\n"; // 
    $waMessage .= "----------------------------------------\n";
    
    // Loop untuk mengambil detail produk, qty, dan harga
    foreach($order->items as $item) {
        $productName = $item->product ? $item->product->name : 'Produk';
        $waMessage .= "- " . $productName . " (" . $item->quantity . "x) : Rp " . number_format($item->subtotal, 0, ',', '.') . "\n";
    }
    
    $waMessage .= "----------------------------------------\n";
    $waMessage .= "*Total Tagihan:* Rp " . number_format($order->total_amount, 0, ',', '.') . "\n\n";
    $waMessage .= "Mohon ditunggu ya, pesanan Anda sedang kami proses. Terima kasih! ";
    
    // 3. Encode teks agar aman dibaca oleh URL browser/WhatsApp
    $encodedMessage = urlencode($waMessage);
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Detail Pesanan</h1>
            <p class="text-gray-500 text-sm mt-1"><?php echo e($order->order_number); ?></p>
        </div>
        <div class="flex gap-2">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition">Kembali</a>
        </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">
        <!-- Info Pesanan & Item (Kolom Kiri - Lebar) -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Informasi Pemesan -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700">Informasi Pemesan</h3>
                    <span class="px-3 py-1 text-sm rounded-full font-semibold
                        <?php if($order->status == 'pending'): ?> bg-amber-100 text-amber-700
                        <?php elseif($order->status == 'processing'): ?> bg-blue-100 text-blue-700
                        <?php elseif($order->status == 'completed'): ?> bg-green-100 text-green-700
                        <?php elseif($order->status == 'cancelled'): ?> bg-red-100 text-red-700
                        <?php else: ?> bg-gray-100 text-gray-700 <?php endif; ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?> Menunggu
                        <?php elseif($order->status == 'processing'): ?> Diproses
                        <?php elseif($order->status == 'completed'): ?> Selesai
                        <?php elseif($order->status == 'cancelled'): ?> Dibatalkan
                        <?php else: ?> <?php echo e(ucfirst($order->status)); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </span>
                </div>
                
                <div class="grid sm:grid-cols-2 gap-4 text-sm">
                    <div><p class="text-gray-400">Nama</p><p class="font-medium text-gray-800"><?php echo e($order->customer_name); ?></p></div>
                    <div><p class="text-gray-400">Telepon</p><p class="font-medium text-gray-800"><?php echo e($order->customer_phone); ?></p></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->customer_email): ?>
                        <div><p class="text-gray-400">Email</p><p class="font-medium text-gray-800"><?php echo e($order->customer_email); ?></p></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="sm:col-span-2">
                        <p class="text-gray-400">Alamat</p>
                        <p class="font-medium text-gray-800"><?php echo e($order->customer_address); ?></p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->notes): ?>
                        <div class="sm:col-span-2"><p class="text-gray-400">Catatan</p><p class="font-medium text-gray-800"><?php echo e($order->notes); ?></p></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <!-- Tombol WhatsApp -->
                <div class="mt-5 pt-4 border-t border-gray-50">
                    <a href="https://wa.me/<?php echo e($cleanPhone); ?>?text=<?php echo e($encodedMessage); ?>" 
                       target="_blank"
                       class="inline-flex items-center gap-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium transition shadow-sm">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                        </svg>
                        Chat Customer via WhatsApp
                    </a>
                </div>
            </div>

            <!-- Item Pesanan -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 class="font-semibold text-gray-700 mb-4">Item Pesanan</h3>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left text-gray-400 border-b border-gray-100">
                                <th class="pb-2 font-medium">Produk</th>
                                <th class="pb-2 font-medium text-center">Jumlah</th>
                                <th class="pb-2 font-medium text-right">Harga</th>
                                <th class="pb-2 font-medium text-right">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="py-3">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-lg bg-pink-50 flex items-center justify-center text-lg overflow-hidden flex-shrink-0">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->product && $item->product->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>" class="w-full h-full object-cover">
                                            <?php else: ?>
                                                🍰
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                        <span class="font-medium text-gray-800"><?php echo e($item->product ? $item->product->name : 'Produk Tidak Diketahui'); ?></span>
                                    </div>
                                </td>
                                <td class="py-3 text-center text-gray-600"><?php echo e($item->quantity); ?></td>
                                <td class="py-3 text-right text-gray-600">Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                                <td class="py-3 text-right font-semibold text-gray-800">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                            </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="border-t border-gray-100 mt-4 pt-4 flex justify-between items-center">
                    <span class="font-semibold text-gray-700">Total</span>
                    <span class="text-xl font-bold text-rose-600">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>

        <!-- Sidebar Actions (Kolom Kanan - Tipis) -->
        <div class="space-y-4">
            <!-- Card Update Status -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-700 mb-3">Aksi Pesanan</h3>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status !== 'completed' && $order->status !== 'cancelled'): ?>
                    <form action="<?php echo e(route('admin.orders.status', $order)); ?>" method="POST" class="space-y-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div>
                            <label class="text-xs font-medium text-gray-400 block mb-1">Status Transaksi</label>
                            <select name="status" class="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
                                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Menunggu</option>
                                <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Diproses</option>
                                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                                <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Dibatalkan</option>
                            </select>
                        </div>
                        <button type="submit" class="w-full px-4 py-2 bg-pink-500 text-white rounded-lg font-medium hover:bg-pink-600 transition text-sm shadow-sm">
                            Update Status
                        </button>
                    </form>
                <?php elseif($order->status == 'completed'): ?>
                    <div class="bg-green-50 rounded-xl border border-green-100 p-4">
                        <div class="flex items-center gap-2 text-green-700">
                            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <span class="font-semibold text-sm">Pesanan Selesai</span>
                        </div>
                        <p class="text-xs text-green-600 mt-1">Pesanan yang sudah selesai tidak dapat diubah kembali.</p>
                    </div>
                <?php elseif($order->status == 'cancelled'): ?>
                    <div class="bg-red-50 rounded-xl border border-red-100 p-4 mb-2">
                        <div class="flex items-center gap-2 text-red-700">
                            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <span class="font-semibold text-sm">Pesanan Dibatalkan</span>
                        </div>
                        <p class="text-xs text-red-600 mt-1">Pesanan ini telah dibatalkan oleh sistem/pelanggan.</p>
                    </div>

                    <!-- Tombol Hapus khusus status Cancelled -->
                    <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus permanen data pesanan ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="w-full px-4 py-2 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 transition text-sm shadow-sm">
                            Hapus Pesanan
                        </button>
                    </form>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <!-- Detail Log Info Singkat -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <h3 class="font-semibold text-gray-700 mb-2">Metadata</h3>
                <div class="text-sm space-y-2">
                    <div class="flex justify-between"><span class="text-gray-400">Tanggal</span><span class="text-gray-700 font-medium"><?php echo e($order->created_at->format('d M Y, H:i')); ?></span></div>
                    <div class="flex justify-between"><span class="text-gray-400">Akun User</span><span class="text-gray-700 font-medium"><?php echo e($order->user ? $order->user->name : 'Guest/Tamu'); ?></span></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>