

<?php $__env->startSection('title', $product->name . ' - Sazaliha'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto px-0 sm:px-6 lg:px-8 py-0 sm:py-8">
    
    <div class="grid lg:grid-cols-2 gap-6 lg:gap-12 items-start">
        
        
        <div class="bg-white overflow-hidden sm:rounded-2xl shadow-sm border-0 sm:border sm:border-pink-50">
            <div class="aspect-square bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center relative overflow-hidden">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->image): ?>
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <span class="text-7xl sm:text-8xl"><?php echo e(['🍰','🧁','🍪','🍮','🍫','🍩'][$product->id % 6]); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        
        <div class="flex flex-col justify-between px-4 sm:px-0">
            <div>
                <p class="text-xs sm:text-sm text-pink-500 font-semibold uppercase tracking-wide"><?php echo e($product->category->name); ?></p>
                <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mt-1 sm:mt-2"><?php echo e($product->name); ?></h1>
                
                
                <div class="flex items-center gap-2 mt-2">
                    <div class="flex text-amber-400">
                        <?php $ratingAvg = round($product->reviews_avg_rating ?? 4.8, 1); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <svg class="w-4 h-4 <?php echo e($i <= $ratingAvg ? 'fill-current' : 'text-gray-200'); ?>" viewBox="0 0 20 20">
                                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                    <span class="text-xs sm:text-sm font-semibold text-gray-700"><?php echo e($ratingAvg); ?></span>
                    <span class="text-xs sm:text-sm text-gray-400">(<?php echo e(count($product->reviews ?? [])); ?> Ulasan)</span>
                </div>

                <div class="flex items-center gap-4 mt-4">
                    <span class="text-2xl sm:text-3xl font-bold text-rose-600">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                </div>

                <p class="text-sm sm:text-base text-gray-600 mt-4 leading-relaxed"><?php echo e($product->description ?? 'Deskripsi produk belum tersedia.'); ?></p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
            <div class="mt-6 space-y-4">
                
                <div class="flex items-center gap-3">
                    <span class="text-xs sm:text-sm font-medium text-gray-700">Jumlah:</span>
                    <div class="flex items-center border border-gray-200 rounded-lg">
                        <button type="button" onclick="this.parentNode.querySelector('input').stepDown(); updateQuantities(this.parentNode.querySelector('input').value)" class="px-3 py-1.5 text-gray-500 hover:text-pink-500 font-bold">-</button>
                        <input type="number" id="main-quantity" name="quantity" value="1" min="1" max="<?php echo e($product->stock); ?>" onchange="updateQuantities(this.value)" class="w-12 text-center border-x border-gray-200 py-1 text-sm outline-none">
                        <button type="button" onclick="this.parentNode.querySelector('input').stepUp(); updateQuantities(this.parentNode.querySelector('input').value)" class="px-3 py-1.5 text-gray-500 hover:text-pink-500 font-bold">+</button>
                    </div>
                    <span class="text-xs text-gray-400">Stok: <?php echo e($product->stock ?? 'Tersedia'); ?></span>
                </div>

                
                <div class="grid grid-cols-2 gap-3">
                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="quantity" id="quantity-input" value="1">
                        <button type="submit" class="w-full bg-pink-100 text-pink-600 py-3 rounded-xl font-semibold hover:bg-pink-200 transition text-sm sm:text-base flex items-center justify-center gap-1.5">
                            <svg class="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                            + Keranjang
                        </button>
                    </form>
                    <form action="<?php echo e(route('cart.buy-now')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="quantity" id="quantity-input-buy" value="1">
                        <button type="submit" class="w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-pink-200 transition text-sm sm:text-base flex items-center justify-center gap-1.5">
                            <svg class="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                            Beli Langsung
                        </button>
                    </form>
                </div>
            </div>
            <?php else: ?>
            <div class="mt-6">
                <a href="<?php echo e(route('login')); ?>" class="block w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white text-center py-3 sm:py-3.5 rounded-xl font-semibold hover:shadow-lg hover:shadow-pink-200 transition flex items-center justify-center gap-2 text-sm sm:text-base">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/></svg>
                    Masuk untuk Memesan
                </a>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <section class="mt-12 pt-8 px-4 sm:px-0 border-t border-pink-100">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
                <h2 class="text-xl sm:text-2xl font-bold text-gray-800">Ulasan Pembeli</h2>
                <div class="flex items-center gap-1 px-2.5 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-semibold text-amber-700">
                    <span>★ <?php echo e($ratingAvg); ?></span>
                    <span class="text-gray-400">(<?php echo e(count($product->reviews ?? [])); ?>)</span>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
            <button onclick="toggleReviewModal()" class="px-3 py-2 sm:px-4 sm:py-2 text-xs sm:text-sm bg-pink-50 text-pink-600 font-semibold rounded-lg hover:bg-pink-100 transition border border-pink-200">
                Tulis Ulasan
            </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <div class="space-y-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $product->reviews ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="bg-white p-4 sm:p-5 rounded-2xl border border-pink-50 shadow-sm transition hover:border-pink-100">
                <div class="flex items-start justify-between gap-3">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr from-pink-400 to-rose-400 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                            <?php echo e(strtoupper(substr($review->user->name ?? 'User', 0, 1))); ?>

                        </div>
                        <div>
                            <h4 class="font-bold text-gray-800 text-sm sm:text-base"><?php echo e($review->user->name ?? 'Pelanggan Sazaliha'); ?></h4>
                            <p class="text-[10px] sm:text-xs text-gray-400"><?php echo e($review->created_at ? $review->created_at->diffForHumans() : 'Baru saja'); ?></p>
                        </div>
                    </div>
                    <div class="flex text-amber-400">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4 <?php echo e($i <= $review->rating ? 'fill-current' : 'text-gray-200'); ?>" viewBox="0 0 20 20">
                                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                </div>
                <p class="text-xs sm:text-sm text-gray-600 mt-3 leading-relaxed"><?php echo e($review->comment); ?></p>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="bg-white p-8 rounded-2xl border border-pink-50 text-center">
                <span class="text-4xl">💬</span>
                <h3 class="font-bold text-gray-700 text-sm sm:text-base mt-2">Belum Ada Ulasan</h3>
                <p class="text-xs sm:text-sm text-gray-400 mt-1">Jadilah yang pertama memberikan ulasan manis untuk rasa dessert ini!</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
    <div id="reviewModal" class="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-pink-100">
            <div class="flex items-center justify-between mb-4">
                <h3 class="font-bold text-gray-800 text-lg">Tulis Ulasan Dessert</h3>
                <button onclick="toggleReviewModal()" class="text-gray-400 hover:text-gray-600 font-bold">&times;</button>
            </div>
            <form action="<?php echo e(route('reviews.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                
                <div class="mb-4">
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Rating Produk</label>
                    <select name="rating" required class="w-full border border-gray-200 rounded-xl p-2.5 text-sm focus:border-pink-500 focus:outline-none">
                        <option value="5">⭐⭐⭐⭐⭐ (5 - Sangat Enak)</option>
                        <option value="4">⭐⭐⭐⭐ (4 - Enak)</option>
                        <option value="3">⭐⭐⭐ (3 - Cukup)</option>
                        <option value="2">⭐⭐ (2 - Kurang)</option>
                        <option value="1">⭐ (1 - Tidak Suka)</option>
                    </select>
                </div>

                <div class="mb-5">
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Ulasan Kamu</label>
                    <textarea name="comment" rows="3" required placeholder="Bagikan kesan rasa manis dari dessert ini..." class="w-full border border-gray-200 rounded-xl p-3 text-sm focus:border-pink-500 focus:outline-none"></textarea>
                </div>

                <div class="flex gap-2">
                    <button type="button" onclick="toggleReviewModal()" class="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 text-sm font-semibold hover:bg-gray-50">Batal</button>
                    <button type="submit" class="flex-1 py-2.5 rounded-xl bg-pink-500 text-white text-sm font-semibold hover:bg-pink-600 shadow-md shadow-pink-200">Kirim Ulasan</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($related) && $related->count() > 0): ?>
    <div class="mt-12 pt-8 px-4 sm:px-0 border-t border-pink-100">
        <h2 class="text-xl sm:text-2xl font-bold text-gray-800 mb-6">Produk Serupa</h2>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="bg-white rounded-2xl shadow-sm border border-pink-50 overflow-hidden hover:shadow-lg transition">
                <a href="<?php echo e(route('products.show', $prod->slug)); ?>">
                    <div class="aspect-square bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center relative overflow-hidden">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prod->image): ?>
                            <img src="<?php echo e(asset('storage/' . $prod->image)); ?>" alt="<?php echo e($prod->name); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <span class="text-4xl sm:text-5xl"><?php echo e(['🍰','🧁','🍪','🍮','🍫','🍩'][$loop->index % 6]); ?></span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        
                        <div class="absolute top-2 right-2 bg-white/90 backdrop-blur-md px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm border border-pink-100">
                            <svg class="w-3 h-3 text-amber-400 fill-current" viewBox="0 0 20 20">
                                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                            </svg>
                            <span class="text-[10px] font-bold text-gray-700"><?php echo e(round($prod->reviews_avg_rating ?? 4.8, 1)); ?></span>
                        </div>
                    </div>
                </a>
                <div class="p-3 sm:p-4">
                    <h3 class="font-bold text-gray-800 text-sm sm:text-base truncate"><?php echo e($prod->name); ?></h3>
                    <p class="text-rose-600 font-bold text-xs sm:text-sm mt-1">Rp <?php echo e(number_format($prod->price, 0, ',', '.')); ?></p>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<script>
    function updateQuantities(val) {
        const qty = Math.max(1, val);
        document.getElementById('quantity-input').value = qty;
        document.getElementById('quantity-input-buy').value = qty;
    }

    function toggleReviewModal() {
        const modal = document.getElementById('reviewModal');
        if (modal) {
            modal.classList.toggle('hidden');
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/products/show.blade.php ENDPATH**/ ?>