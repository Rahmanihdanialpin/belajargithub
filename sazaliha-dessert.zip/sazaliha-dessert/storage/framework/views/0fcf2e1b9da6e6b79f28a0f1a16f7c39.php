

<?php $__env->startSection('title', 'Manajemen Bahan Baku'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">
    <div class="space-y-0.5">
        <h1 class="text-xl sm:text-2xl font-black text-gray-800 tracking-tight">Manajemen Bahan Baku</h1>
        <p class="text-xs sm:text-sm text-gray-500">Pantau dan kelola stok bahan dasar produksi dessert</p>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingredients.create')): ?>
    <div class="self-start sm:self-auto w-full sm:w-auto">
        <a href="<?php echo e(route('admin.ingredients.create')); ?>" class="inline-flex items-center justify-center w-full sm:w-auto px-4 py-2.5 bg-pink-500 text-white text-sm rounded-xl font-bold hover:bg-pink-600 transition shadow-md shadow-pink-100 active:scale-95">
            <svg class="w-5 h-5 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Tambah Bahan
        </a>
    </div>
    <?php endif; ?>
</div>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lowStockCount > 0): ?>
<div class="bg-amber-50 border border-amber-200 text-amber-700 p-4 rounded-xl mb-6 flex items-start gap-3 text-xs sm:text-sm shadow-sm">
    <svg class="w-5 h-5 text-amber-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
    <div>
        <span class="font-bold"><?php echo e($lowStockCount); ?> bahan baku terdeteksi kritis atau menipis.</span> Segera lakukan pemesanan ke supplier!
    </div>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="bg-white rounded-2xl border border-pink-50 shadow-sm overflow-hidden">
    
    <div class="grid grid-cols-1 divide-y divide-gray-100 md:hidden">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="p-4 space-y-4">
            <div class="flex items-start gap-3">
                <div class="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-xl shrink-0 border border-orange-100/50">
                    🧂
                </div>
                <div class="min-w-0 flex-1">
                    <div class="flex items-center justify-between gap-2">
                        <p class="font-bold text-gray-800 text-sm sm:text-base truncate"><?php echo e($ingredient->name); ?></p>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ingredient->status == 'habis'): ?>
                            <span class="px-2 py-0.5 bg-red-50 text-red-700 border border-red-100 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0">Habis</span>
                        <?php elseif($ingredient->status == 'menipis'): ?>
                            <span class="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-100 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0">Menipis</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 bg-green-50 text-green-700 border border-green-100 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0">Aman</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <p class="text-xs text-gray-400 mt-0.5 line-clamp-1"><?php echo e($ingredient->notes ?: 'Tidak ada catatan tambahan.'); ?></p>
                    <div class="flex items-center gap-1.5 mt-2 text-[11px] text-gray-500">
                        <span class="font-medium">Supplier:</span>
                        <span class="font-semibold text-gray-700 truncate max-w-[150px]"><?php echo e($ingredient->supplier ?: '-'); ?></span>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-2 bg-gray-50/70 p-3 rounded-xl text-xs">
                <div class="space-y-1">
                    <span class="text-gray-400 block text-[10px] uppercase font-bold tracking-wider">Kondisi Fisik</span>
                    <p class="text-gray-800">
                        Stok: <span class="font-bold"><?php echo e(number_format($ingredient->stock, 2, ',', '.')); ?></span> <?php echo e($ingredient->unit); ?>

                    </p>
                    <p class="text-gray-500 text-[11px]">
                        Min: <?php echo e(number_format($ingredient->min_stock, 2, ',', '.')); ?> <?php echo e($ingredient->unit); ?>

                    </p>
                </div>
                <div class="space-y-1 text-right">
                    <span class="text-gray-400 block text-[10px] uppercase font-bold tracking-wider">Nilai Keuangan</span>
                    <p class="text-gray-800">
                        Rp <?php echo e(number_format($ingredient->cost_per_unit, 0, ',', '.')); ?>

                    </p>
                    <p class="font-bold text-rose-600 text-[13px]">
                        Rp <?php echo e(number_format($ingredient->stock_value, 0, ',', '.')); ?>

                    </p>
                </div>
            </div>

            <div class="flex justify-end items-center gap-2 pt-1">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingredients.update')): ?>
                <a href="<?php echo e(route('admin.ingredients.edit', $ingredient)); ?>" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-amber-600 bg-amber-50 hover:bg-amber-100 rounded-lg transition">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    Edit
                </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingredients.delete')): ?>
                <form action="<?php echo e(route('admin.ingredients.destroy', $ingredient)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus bahan baku ini?')" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        Hapus
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>

    <div class="hidden md:block overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-pink-50/50 text-gray-700 uppercase text-xs tracking-wider">
                <tr>
                    <th class="px-5 py-4">Nama Bahan</th>
                    <th class="px-5 py-4">Supplier</th>
                    <th class="px-5 py-4">Stok Saat Ini</th>
                    <th class="px-5 py-4">Batas Min</th>
                    <th class="px-5 py-4">Harga / Unit</th>
                    <th class="px-5 py-4">Total Aset Stok</th>
                    <th class="px-5 py-4">Status</th>
                    <th class="px-5 py-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="hover:bg-gray-50/80 transition">
                    <td class="px-5 py-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-xl shrink-0">🧂</div>
                            <div>
                                <p class="font-bold text-gray-800"><?php echo e($ingredient->name); ?></p>
                                <p class="text-xs text-gray-400 mt-0.5"><?php echo e($ingredient->notes ?: '-'); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-4 text-gray-600 font-medium"><?php echo e($ingredient->supplier ?: '-'); ?></td>
                    <td class="px-5 py-4">
                        <span class="font-black <?php echo e($ingredient->status == 'menipis' ? 'text-amber-600' : ($ingredient->status == 'habis' ? 'text-red-600' : 'text-green-600')); ?>">
                            <?php echo e(number_format($ingredient->stock, 2, ',', '.')); ?> <?php echo e($ingredient->unit); ?>

                        </span>
                    </td>
                    <td class="px-5 py-4 text-gray-400 font-medium">
                        <?php echo e(number_format($ingredient->min_stock, 2, ',', '.')); ?> <?php echo e($ingredient->unit); ?>

                    </td>
                    <td class="px-5 py-4 font-bold text-gray-700">Rp <?php echo e(number_format($ingredient->cost_per_unit, 0, ',', '.')); ?></td>
                    <td class="px-5 py-4 font-black text-rose-600">Rp <?php echo e(number_format($ingredient->stock_value, 0, ',', '.')); ?></td>
                    <td class="px-5 py-4">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ingredient->status == 'habis'): ?>
                            <span class="px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold">Habis</span>
                        <?php elseif($ingredient->status == 'menipis'): ?>
                            <span class="px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">Menipis</span>
                        <?php else: ?>
                            <span class="px-2.5 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">Aman</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                    <td class="px-5 py-4 text-right">
                        <div class="flex items-center justify-end gap-1.5">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingredients.update')): ?>
                            <a href="<?php echo e(route('admin.ingredients.edit', $ingredient)); ?>" class="p-2 text-amber-500 hover:bg-amber-50 hover:text-amber-600 rounded-xl transition" title="Edit">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingredients.delete')): ?>
                            <form action="<?php echo e(route('admin.ingredients.destroy', $ingredient)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus bahan baku ini?')" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="p-2 text-red-500 hover:bg-red-50 hover:text-red-600 rounded-xl transition" title="Hapus">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="p-4 border-t border-pink-50 bg-gray-50/50">
        <?php echo e($ingredients->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/ingredients/index.blade.php ENDPATH**/ ?>