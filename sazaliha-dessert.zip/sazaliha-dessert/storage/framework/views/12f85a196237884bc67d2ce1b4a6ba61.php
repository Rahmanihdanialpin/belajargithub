

<?php $__env->startSection('title', 'Manajemen Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header Section -->
<div class="space-y-1 mb-6">
    <h1 class="text-xl sm:text-2xl font-black text-gray-800 tracking-tight">Manajemen Pesanan</h1>
    <p class="text-xs sm:text-sm text-gray-500">Kelola dan proses pesanan pelanggan Sazaliha Dessert</p>
</div>

<!-- Status Cards: Berjejer 3 di desktop, tapi pas di HP menyesuaikan ruang tanpa merusak layout -->
<div class="grid grid-cols-3 gap-3 sm:gap-4 mb-6">
    <div class="bg-amber-50 rounded-xl p-3 sm:p-4 border border-amber-100 shadow-sm">
        <p class="text-[11px] sm:text-sm font-semibold text-amber-600 uppercase tracking-wider">Pending</p>
        <p class="text-xl sm:text-2xl font-black text-amber-700 mt-0.5"><?php echo e($pendingCount); ?></p>
    </div>
    <div class="bg-blue-50 rounded-xl p-3 sm:p-4 border border-blue-100 shadow-sm">
        <p class="text-[11px] sm:text-sm font-semibold text-blue-600 uppercase tracking-wider">Diproses</p>
        <p class="text-xl sm:text-2xl font-black text-blue-700 mt-0.5"><?php echo e($processingCount); ?></p>
    </div>
    <div class="bg-green-50 rounded-xl p-3 sm:p-4 border border-green-100 shadow-sm">
        <p class="text-[11px] sm:text-sm font-semibold text-green-600 uppercase tracking-wider">Selesai</p>
        <p class="text-xl sm:text-2xl font-black text-green-700 mt-0.5"><?php echo e($completedCount); ?></p>
    </div>
</div>

<!-- Filters Form: Tumpuk vertikal penuh di HP, sejajar horizontal di desktop -->
<div class="bg-white rounded-xl p-4 shadow-sm border border-pink-50 mb-6">
    <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET" class="flex flex-col md:flex-row md:items-center gap-3">
        <div class="w-full md:w-52">
            <label class="block text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-1 md:hidden">Filter Status</label>
            <select name="status" class="w-full px-3 py-2 text-sm rounded-xl border border-gray-200 focus:border-pink-400 focus:ring-1 focus:ring-pink-400 outline-none transition bg-gray-50/50">
                <option value="">Semua Status</option>
                <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="processing" <?php echo e(request('status') == 'processing' ? 'selected' : ''); ?>>Diproses</option>
                <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Dibatalkan</option>
            </select>
        </div>
        <div class="w-full md:w-52">
            <label class="block text-[10px] uppercase tracking-wider font-bold text-gray-400 mb-1 md:hidden">Filter Tanggal</label>
            <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="w-full px-3 py-2 text-sm rounded-xl border border-gray-200 focus:border-pink-400 focus:ring-1 focus:ring-pink-400 outline-none transition bg-gray-50/50">
        </div>
        <button type="submit" class="w-full md:w-auto px-6 py-2 bg-pink-500 text-white text-sm rounded-xl font-bold hover:bg-pink-600 transition shadow-md shadow-pink-100 active:scale-95 text-center">
            Terapkan Filter
        </button>
    </form>
</div>

<!-- Container Utama Data Pesanan -->
<div class="bg-white rounded-2xl border border-pink-50 shadow-sm overflow-hidden">
    
    <!-- ==================== TAMPILAN MOBILE (Order Card List) ==================== -->
    <div class="grid grid-cols-1 divide-y divide-gray-100 md:hidden">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="p-4 space-y-3.5">
            <!-- Baris Atas: ID Pesanan & Status -->
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-1.5">
                    <span class="text-xs text-gray-400">#</span>
                    <span class="font-black text-gray-800 text-sm tracking-wide"><?php echo e($order->order_number); ?></span>
                </div>
                <div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?>
                        <span class="px-2.5 py-0.5 bg-amber-50 text-amber-700 rounded-full text-[10px] font-bold uppercase tracking-wider border border-amber-100">Pending</span>
                    <?php elseif($order->status == 'processing'): ?>
                        <span class="px-2.5 py-0.5 bg-blue-50 text-blue-700 rounded-full text-[10px] font-bold uppercase tracking-wider border border-blue-100">Diproses</span>
                    <?php elseif($order->status == 'completed'): ?>
                        <span class="px-2.5 py-0.5 bg-green-50 text-green-700 rounded-full text-[10px] font-bold uppercase tracking-wider border border-green-100">Selesai</span>
                    <?php else: ?>
                        <span class="px-2.5 py-0.5 bg-red-50 text-red-700 rounded-full text-[10px] font-bold uppercase tracking-wider border border-red-100">Batal</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <!-- Detail Pelanggan & Waktu Transaksi -->
            <div class="bg-gray-50/60 p-3 rounded-xl space-y-1.5 text-xs">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="font-bold text-gray-800"><?php echo e($order->customer_name); ?></p>
                        <p class="text-gray-500 text-[11px] mt-0.5"><?php echo e($order->customer_phone); ?></p>
                    </div>
                    <span class="text-gray-400 text-[10px] shrink-0 font-medium"><?php echo e($order->created_at->format('d M Y, H:i')); ?></span>
                </div>
            </div>

            <!-- Baris Bawah: Total Biaya & Tombol Aksi -->
            <div class="flex items-center justify-between pt-1">
                <div>
                    <span class="text-[10px] text-gray-400 block uppercase font-bold tracking-wider">Total Pembayaran</span>
                    <span class="font-black text-rose-600 text-sm">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                </div>
                <div class="flex items-center gap-2">
                    <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="inline-flex items-center justify-center px-3 py-1.5 bg-pink-50 text-pink-600 rounded-lg text-xs font-bold hover:bg-pink-100 transition">
                        Detail
                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'cancelled'): ?>
                    <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus pesanan ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="inline-flex items-center justify-center px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100 transition">
                            Hapus
                        </button>
                    </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <div class="p-8 text-center text-gray-400 text-sm">Belum ada data pesanan masuk.</div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- ==================== TAMPILAN DESKTOP (Tabel Konvensional) ==================== -->
    <div class="hidden md:block overflow-x-auto">
        <table class="w-full text-sm text-left">
            <thead class="bg-pink-50/50 text-gray-700 uppercase text-xs tracking-wider">
                <tr>
                    <th class="px-5 py-4">No Pesanan</th>
                    <th class="px-5 py-4">Pelanggan</th>
                    <th class="px-5 py-4">Total</th>
                    <th class="px-5 py-4">Status</th>
                    <th class="px-5 py-4">Tanggal</th>
                    <th class="px-5 py-4 text-right">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="hover:bg-gray-50/80 transition">
                    <td class="px-5 py-4 font-bold text-gray-800 tracking-wide">#<?php echo e($order->order_number); ?></td>
                    <td class="px-5 py-4">
                        <p class="font-bold text-gray-800"><?php echo e($order->customer_name); ?></p>
                        <p class="text-xs text-gray-400 mt-0.5"><?php echo e($order->customer_phone); ?></p>
                    </td>
                    <td class="px-5 py-4 font-black text-rose-600">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></td>
                    <td class="px-5 py-4">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?>
                            <span class="px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">Pending</span>
                        <?php elseif($order->status == 'processing'): ?>
                            <span class="px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold">Diproses</span>
                        <?php elseif($order->status == 'completed'): ?>
                            <span class="px-2.5 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">Selesai</span>
                        <?php else: ?>
                            <span class="px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold">Dibatalkan</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                    <td class="px-5 py-4 text-gray-500 font-medium"><?php echo e($order->created_at->format('d M Y, H:i')); ?></td>
                    <td class="px-5 py-4 text-right">
                        <div class="flex items-center justify-end gap-2">
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="inline-flex items-center px-3 py-1.5 bg-pink-50 text-pink-600 rounded-lg text-xs font-bold hover:bg-pink-100 transition">
                                Detail
                            </a>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'cancelled'): ?>
                            <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus pesanan ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="inline-flex items-center px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100 transition">
                                    Hapus
                                </button>
                            </form>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="6" class="px-5 py-8 text-center text-gray-400">Belum ada data pesanan masuk.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Footer -->
    <div class="p-4 border-t border-pink-50 bg-gray-50/50">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>