

<?php $__env->startSection('title', 'Pesanan Saya - Sazaliha'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-5xl mx-auto py-4 md:py-8 px-2 sm:px-4 lg:px-8">

    <!-- Header Halaman -->
    <div class="mb-5 px-2 md:px-0">
        <h1 class="text-xl md:text-2xl font-black text-gray-800 tracking-tight">Pesanan Saya</h1>
        <p class="text-xs md:text-sm text-gray-500 mt-0.5">Pantau status hidangan manis pesananmu di sini.</p>
    </div>

    <!-- Status Tabs (Mobile Scrollable) -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 mb-5 overflow-hidden">
        <div class="flex overflow-x-auto scrollbar-none snap-x snap-mandatory">
            <?php
                $tabs = [
                    'all' => ['label' => 'Semua', 'count' => $counts['all']],
                    'pending' => ['label' => 'Belum Bayar', 'count' => $counts['pending']],
                    'processing' => ['label' => 'Dikemas', 'count' => $counts['processing']],
                    'completed' => ['label' => 'Selesai', 'count' => $counts['completed']],
                    'cancelled' => ['label' => 'Dibatalkan', 'count' => $counts['cancelled']],
                ];
            ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabStatus => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(route('orders.list', ['status' => $tabStatus])); ?>"
                   class="flex-1 min-w-[100px] text-center px-4 py-3.5 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition snap-center
                   <?php echo e($status === $tabStatus ? 'border-rose-500 text-rose-600 bg-rose-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'); ?>">
                    <?php echo e($tab['label']); ?>

                    <span class="ml-1 px-1.5 py-0.5 text-[10px] md:text-xs rounded-full font-black <?php echo e($status === $tabStatus ? 'bg-rose-100 text-rose-600' : 'bg-gray-100 text-gray-500'); ?>">
                        <?php echo e($tab['count']); ?>

                    </span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>

    <!-- Orders List Stack -->
    <div class="space-y-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden transition hover:border-gray-200">
            
            <!-- Card Header -->
            <div class="px-4 py-3 bg-gray-50/50 border-b border-gray-100 flex flex-row items-center justify-between gap-2">
                <div class="min-w-0">
                    <span class="block font-black text-sm md:text-base text-gray-800 truncate"><?php echo e($order->order_number); ?></span>
                    <span class="block text-[10px] md:text-xs text-gray-400 mt-0.5"><?php echo e($order->created_at->format('d M Y, H:i')); ?></span>
                </div>
                <span class="px-2.5 py-1 text-[10px] md:text-xs rounded-xl font-bold uppercase tracking-wider shrink-0
                    <?php if($order->status == 'pending'): ?> bg-amber-50 text-amber-700 border border-amber-200/50
                    <?php elseif($order->status == 'processing'): ?> bg-blue-50 text-blue-700 border border-blue-200/50
                    <?php elseif($order->status == 'completed'): ?> bg-emerald-50 text-emerald-700 border border-emerald-200/50
                    <?php elseif($order->status == 'cancelled'): ?> bg-red-50 text-red-700 border border-red-200/50
                    <?php else: ?> bg-gray-50 text-gray-700 border border-gray-200 <?php endif; ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?> Belum Bayar
                    <?php elseif($order->status == 'processing'): ?> Dikemas
                    <?php elseif($order->status == 'completed'): ?> Selesai
                    <?php elseif($order->status == 'cancelled'): ?> Dibatalkan
                    <?php else: ?> <?php echo e($order->status); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </span>
            </div>

            <!-- Card Body (Items List) -->
            <div class="px-4 py-3 divide-y divide-gray-50">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="flex items-start sm:items-center gap-3 py-3 <?php echo e($loop->first ? 'pt-1' : ''); ?> <?php echo e($loop->last ? 'pb-1' : ''); ?>">
                    <div class="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center text-xl shrink-0 border border-amber-100/40 shadow-sm">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>" class="w-full h-full object-cover rounded-xl">
                        <?php else: ?>
                            🍰
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="font-bold text-sm text-gray-800 truncate"><?php echo e($item->product->name); ?></p>
                        <p class="text-xs text-gray-400 mt-0.5"><?php echo e($item->quantity); ?> x Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></p>
                    </div>
                    <span class="font-bold text-sm text-gray-800 shrink-0 align-self-center">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></span>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <!-- Card Footer -->
            <div class="px-4 py-3 bg-gray-50/30 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="text-left w-full sm:w-auto">
                    <span class="text-xs text-gray-400 block sm:inline">Total Pembayaran:</span>
                    <span class="text-base font-black text-rose-600 sm:ml-1">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                </div>
                
                <!-- Action Buttons (Responsive Width) -->
                <div class="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="flex-1 sm:flex-initial text-center px-4 py-2 text-xs md:text-sm bg-white text-gray-700 border border-gray-200 rounded-xl font-bold hover:bg-gray-50 active:scale-[0.98] transition">
                        Detail
                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?>
                    <form action="<?php echo e(route('orders.cancel', $order)); ?>" method="POST" onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?');" class="flex-1 sm:flex-initial">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="w-full text-center px-4 py-2 text-xs md:text-sm bg-red-50 text-red-600 border border-red-100 rounded-xl font-bold hover:bg-red-100 active:scale-[0.98] transition">Batal</button>
                    </form>
                    <?php elseif($order->status == 'cancelled'): ?>
                    <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST" onsubmit="return confirm('Hapus riwayat pesanan ini?');" class="flex-1 sm:flex-initial">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="w-full text-center px-4 py-2 text-xs md:text-sm bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 active:scale-[0.98] transition">Hapus</button>
                    </form>
                    <?php elseif($order->status == 'completed'): ?>
                    <a href="<?php echo e(route('reviews.index')); ?>" class="flex-1 sm:flex-initial text-center px-4 py-2 text-xs md:text-sm bg-amber-50 text-amber-600 border border-amber-100 rounded-xl font-bold hover:bg-amber-100 active:scale-[0.98] transition">Beri Ulasan</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <!-- Empty State Screen -->
        <div class="bg-white rounded-2xl border border-gray-100 p-8 md:p-12 text-center shadow-sm">
            <div class="w-16 h-16 bg-pink-50 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4 border border-pink-100/50">📦</div>
            <h3 class="text-base font-bold text-gray-800">Belum Ada Pesanan</h3>
            <p class="text-xs text-gray-400 max-w-xs mx-auto mt-1">Belum ada transaksi pada daftar kategori ini.</p>
            <a href="<?php echo e(route('products.index')); ?>" class="mt-4 inline-block px-5 py-2 text-xs md:text-sm bg-gradient-to-r from-pink-500 to-rose-600 text-white font-bold rounded-xl shadow-md shadow-rose-200 hover:opacity-90 active:scale-[0.97] transition">
                Jelajahi Menu Dessert
            </a>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- Pagination Wrapper -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($orders->hasPages()): ?>
    <div class="mt-5 px-2">
        <?php echo e($orders->links()); ?>

    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/orders/index.blade.php ENDPATH**/ ?>