

<?php $__env->startSection('title', 'Keranjang Belanja - Sazaliha'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 py-6 md:py-8">
    <h1 class="text-xl md:text-2xl font-bold text-gray-800 mb-4 md:mb-6">Keranjang Belanja</h1>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($products) > 0): ?>
    <div class="bg-white rounded-2xl shadow-sm border border-pink-50 overflow-hidden">
        <div class="divide-y divide-gray-100">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="p-4 flex flex-col sm:flex-row items-center gap-4" data-cart-item-id="<?php echo e($item['cart_item_id']); ?>">
                <div class="flex items-center w-full gap-3">
                    <input type="checkbox" name="selected_cart_item_ids[]" value="<?php echo e($item['cart_item_id']); ?>" form="checkout-selected-form" class="h-5 w-5 text-pink-600 border-gray-300 rounded flex-shrink-0" onchange="recalc()">
                    
                    <div class="w-16 h-16 bg-gradient-to-br from-pink-50 to-rose-50 rounded-xl flex-shrink-0">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['product']->image): ?>
                            <img src="<?php echo e(asset('storage/' . $item['product']->image)); ?>" class="w-full h-full object-cover rounded-xl">
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center text-xl">🍰</div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    
                    <div class="flex-1 min-w-0">
                        <h3 class="font-bold text-gray-800 truncate text-sm"><?php echo e($item['product']->name); ?></h3>
                        <p class="text-xs text-gray-500">Rp <?php echo e(number_format($item['product']->price, 0, ',', '.')); ?></p>
                    </div>
                </div>

                <div class="flex items-center justify-between w-full sm:w-auto gap-4">
                    <form action="<?php echo e(route('cart.update', $item['cart_item_id'])); ?>" method="POST" class="flex items-center">
                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                        <div class="flex items-center border border-gray-200 rounded-lg">
                            <button type="button" onclick="this.parentNode.querySelector('input').stepDown(); this.closest('form').submit()" class="px-3 py-1 text-gray-500">-</button>
                            <input type="number" name="quantity" value="<?php echo e($item['quantity']); ?>" min="1" max="<?php echo e($item['product']->stock); ?>" class="w-10 text-center text-sm outline-none" onchange="this.closest('form').submit()">
                            <button type="button" onclick="this.parentNode.querySelector('input').stepUp(); this.closest('form').submit()" class="px-3 py-1 text-gray-500">+</button>
                        </div>
                    </form>
                    <span class="text-rose-600 font-bold w-20 text-right text-sm">Rp <?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></span>
                    
                    <form action="<?php echo e(route('cart.remove', $item['cart_item_id'])); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-gray-400 hover:text-red-500">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                        </button>
                    </form>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <div class="p-4 bg-pink-50/50 border-t border-pink-100 text-right">
            <p class="text-xs text-gray-500">Total Belanja (Dipilih)</p>
            <p class="text-2xl font-bold text-rose-600" id="selected-total">Rp 0</p>
        </div>
    </div>

    <form action="<?php echo e(route('order.create')); ?>" method="GET" id="checkout-selected-form" class="mt-6">
        <input type="hidden" name="total_pembayaran" id="selected_cart_item_subtotal" value="0" />
        <button type="submit" class="w-full sm:w-auto flex items-center justify-center px-8 py-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-full font-semibold hover:shadow-lg transition">
            Checkout Dipilih
        </button>
    </form>
    <?php else: ?>
    <div class="text-center py-16 bg-white rounded-2xl border border-pink-50">
        <div class="text-6xl mb-4">🛒</div>
        <h3 class="text-lg font-semibold text-gray-600">Keranjang Kosong</h3>
        <a href="<?php echo e(route('products.index')); ?>" class="mt-4 inline-block px-6 py-2 bg-pink-500 text-white rounded-full">Jelajahi Menu</a>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<script>
    function recalc() {
        let sum = 0;
        const checkboxes = document.querySelectorAll('input[name="selected_cart_item_ids[]"]:checked');
        
        checkboxes.forEach((cb) => {
            const itemRow = cb.closest('[data-cart-item-id]');
            const subtotalText = itemRow.querySelector('span.text-rose-600').textContent;
            const rawValue = subtotalText.replace(/[^0-9]/g, '');
            sum += Number(rawValue) || 0;
        });

        // Update UI
        document.getElementById('selected-total').textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(sum);
        // Update Input Hidden
        document.getElementById('selected_cart_item_subtotal').value = sum;
    }

    // Jalankan saat halaman dimuat
    document.addEventListener('DOMContentLoaded', recalc);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/order/cart.blade.php ENDPATH**/ ?>