<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <!-- Session Status -->
    <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4 px-4 sm:px-0','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 px-4 sm:px-0','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

    <?php
        $isAdminMode = request('as') === 'admin';
    ?>

    <!-- Container Utama: Fullscreen di mobile, Center Card di desktop -->
    <div class="w-full min-h-screen sm:min-h-0 sm:max-w-md flex flex-col justify-between bg-white sm:bg-transparent">
        
        <!-- Card Login -->
        <div class="bg-white sm:rounded-3xl sm:shadow-xl sm:shadow-pink-200/50 sm:border sm:border-pink-100 overflow-hidden flex-1 sm:flex-none flex flex-col justify-between sm:block">
            
            <!-- Header -->
            <div class="bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 px-6 py-8 sm:px-8 sm:py-8 text-center relative shrink-0">
                <div class="w-16 h-16 sm:w-20 sm:h-20 bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-md sm:shadow-lg">
                    <span class="text-4xl sm:text-5xl">🧁</span>
                </div>
                <h1 class="text-xl sm:text-2xl font-bold text-white tracking-tight">Sazaliha Dessert</h1>
                <p class="text-pink-100 text-xs sm:text-sm mt-1">
                    <?php echo e($isAdminMode ? 'Panel Admin Sazaliha' : 'Masuk ke akun Anda'); ?>

                </p>
            </div>

            <!-- Form & Konten Utama -->
            <div class="px-6 py-6 sm:px-8 sm:py-6 flex-1 flex flex-col justify-center sm:block">
                <form method="POST" action="<?php echo e(route('login', $isAdminMode ? ['as' => 'admin'] : [])); ?>" class="w-full">
                    <?php echo csrf_field(); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isAdminMode): ?>
                        <input type="hidden" name="as" value="admin">
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <!-- Email Address -->
                    <div>
                        <label for="email" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-1.5">
                            📧 Alamat Email
                        </label>
                        <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" maxlength="255" required autofocus autocomplete="username"
                            class="w-full px-4 py-3.5 sm:py-3 rounded-xl border border-pink-200 bg-pink-50/50 text-gray-800 placeholder-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition text-sm sm:text-base"
                            placeholder="email@contoh.com" />
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->get('email')): ?>
                            <p class="mt-1.5 text-xs text-rose-500 flex items-center gap-1">
                                <svg class="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <?php echo e($errors->get('email')[0]); ?>

                            </p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <!-- Password dengan Fitur Show/Hide -->
                    <div class="mt-4 sm:mt-5" x-data="{ showPass: false }">
                        <label for="password" class="block text-xs sm:text-sm font-semibold text-gray-700 mb-1.5">
                            🔒 Kata Sandi
                        </label>
                        <div class="relative flex items-center">
                            <input id="password" 
                                :type="showPass ? 'text' : 'password'" 
                                name="password" 
                                required 
                                autocomplete="current-password"
                                class="w-full pl-4 pr-12 py-3.5 sm:py-3 rounded-xl border border-pink-200 bg-pink-50/50 text-gray-800 placeholder-pink-300 focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition text-sm sm:text-base z-0"
                                placeholder="••••••••" />
                            
                            <!-- Tombol Toggle Intip Password -->
                            <button type="button" @click="showPass = !showPass" class="absolute right-0 top-0 h-full w-12 flex items-center justify-center text-gray-400 hover:text-pink-500 transition z-10 focus:outline-none" aria-label="Toggle password visibility">
                                
                                <template x-if="!showPass">
                                    <svg class="w-5 h-5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                    </svg>
                                </template>

                                <template x-if="showPass">
                                    <svg class="w-5 h-5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7a10.025 10.025 0 014.132-5.4m3.045-1.257A9.971 9.971 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.4M9.9 9.9l4.2 4.2m7.8 7.8l-18-18"/>
                                    </svg>
                                </template>

                            </button>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->get('password')): ?>
                            <p class="mt-1.5 text-xs text-rose-500 flex items-center gap-1">
                                <svg class="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <?php echo e($errors->get('password')[0]); ?>

                            </p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <!-- Remember Me & Lupa Password -->
                    <div class="flex items-center justify-between mt-4 sm:mt-5 text-xs sm:text-sm">
                        <label for="remember_me" class="inline-flex items-center cursor-pointer select-none">
                            <input id="remember_me" type="checkbox" class="w-4 h-4 rounded border-pink-300 text-pink-500 focus:ring-pink-400 focus:ring-offset-0" name="remember">
                            <span class="ms-2 text-gray-600 font-medium">Ingat saya</span>
                        </label>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('password.request')): ?>
                            <a class="text-pink-500 hover:text-pink-700 font-semibold transition py-1" href="<?php echo e(route('password.request')); ?>">
                                Lupa password?
                            </a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <!-- Login Button -->
                    <div class="mt-5 sm:mt-6">
                        <button type="submit" class="w-full py-3.5 px-4 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold rounded-xl shadow-md shadow-pink-300/40 active:scale-[0.98] transition duration-150 text-sm sm:text-base flex items-center justify-center gap-2">
                            Masuk
                        </button>
                    </div>
                </form>

                <!-- Divider -->
                <div class="mt-5 sm:mt-6 flex items-center gap-3">
                    <div class="flex-1 h-px bg-pink-100/80"></div>
                    <span class="text-[11px] sm:text-xs text-pink-400 font-bold uppercase tracking-wider">atau</span>
                    <div class="flex-1 h-px bg-pink-100/80"></div>
                </div>

                <!-- Register Link -->
                <div class="mt-4 text-center text-xs sm:text-sm">
                    <span class="text-gray-500">Belum punya akun?</span>
                    <a href="<?php echo e(route('register')); ?>" class="text-pink-500 hover:text-pink-700 font-bold transition ml-0.5">
                        Daftar sekarang
                    </a>
                </div>

                <!-- Back to Home -->
                <div class="mt-4 sm:mt-3 text-center">
                    <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center gap-1.5 text-xs sm:text-sm text-gray-400 hover:text-pink-500 font-medium transition py-1">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                        Kembali ke Beranda
                    </a>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <p class="text-center text-gray-400 text-[10px] sm:text-xs py-4 sm:py-0 sm:mt-6 shrink-0">
            🧁 Sazaliha Dessert &copy; <?php echo e(date('Y')); ?> — Manisnya Setiap Momen
        </p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/auth/login.blade.php ENDPATH**/ ?>