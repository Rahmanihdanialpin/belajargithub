<?php $__env->startSection('title', 'Profil & Alamat Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-6xl mx-auto px-0 sm:px-6 lg:px-8 py-0 sm:py-8 min-h-screen bg-gray-50/50 sm:bg-transparent" x-data="{ isEdit: false, isChangePassword: false }">
    
    
    <div class="p-4 sm:px-0 sm:pt-0 sm:pb-6 bg-white sm:bg-transparent border-b sm:border-0 border-gray-100">
        <h1 class="text-xl sm:text-2xl font-bold text-gray-800">Akun Saya</h1>
        <p class="text-gray-500 text-xs sm:text-sm mt-0.5">Kelola identitas diri, kata sandi, dan daftar alamat pengiriman Anda</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-0 sm:gap-8 items-start">
        
        
        <div class="lg:col-span-5 space-y-4 sm:space-y-6 lg:sticky lg:top-24 mb-3 sm:mb-0">
            
            
            <div class="bg-white sm:rounded-3xl shadow-none sm:shadow-sm border-b sm:border border-pink-50 overflow-hidden">
                <div class="px-4 sm:px-6 py-4 sm:py-5 border-b border-gray-100 bg-gradient-to-r from-pink-50/40 via-transparent to-transparent flex items-center justify-between">
                    <span class="text-xs sm:text-sm font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
                        👤 Data Diri
                    </span>
                    <button type="button" x-show="!isEdit" @click="isEdit = true"
                        class="px-3 py-1.5 bg-pink-50 text-pink-600 hover:bg-pink-100 rounded-xl font-bold text-xs transition flex items-center gap-1 shrink-0">
                        ✏️ Edit Profil
                    </button>
                </div>

                <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data" class="p-4 sm:p-6 space-y-4 sm:space-y-5">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    
                    <div class="flex flex-col items-center pb-1">
                        <div class="relative group shrink-0">
                            <div class="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden bg-pink-50 border-4 border-pink-100 shadow-sm">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->avatar): ?>
                                    <img id="avatar-display" src="<?php echo e(asset('storage/' . $user->avatar)); ?>" alt="Avatar" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center bg-pink-100 text-pink-500 text-xl sm:text-2xl font-bold">
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <label for="avatar" x-show="isEdit" x-transition
                                class="absolute bottom-0 right-0 w-7 h-7 sm:w-8 sm:h-8 bg-pink-500 text-white rounded-full flex items-center justify-center cursor-pointer hover:bg-pink-600 transition shadow-md">
                                <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                            </label>
                            <input type="file" id="avatar" name="avatar" accept="image/png, image/jpeg, image/jpg, image/webp" class="hidden" onchange="previewAvatar(this)">
                        </div>
                    </div>

                    
                    <div class="space-y-3.5 sm:space-y-4">
                        <div>
                            <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Nama Lengkap</label>
                            <div x-show="!isEdit" class="text-gray-800 font-semibold text-sm sm:text-base break-words"><?php echo e($user->name); ?></div>
                            <input x-show="isEdit" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" maxlength="100" required class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-pink-300">
                        </div>

                        <div>
                            <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Alamat Email</label>
                            <div x-show="!isEdit" class="text-gray-800 text-sm sm:text-base break-all"><?php echo e($user->email); ?></div>
                            <input x-show="isEdit" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" maxlength="255" required class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-pink-300">
                        </div>

                        <div class="grid grid-cols-2 gap-3 sm:gap-4">
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">No. WhatsApp</label>
                                <div x-show="!isEdit" class="text-gray-800 text-sm"><?php echo e($user->phone ?? '-'); ?></div>
                                <input x-show="isEdit" type="tel" inputmode="tel" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" maxlength="15" placeholder="08123456789" class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-pink-300">
                            </div>
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Jenis Kelamin</label>
                                <div x-show="!isEdit" class="text-gray-800 text-sm"><?php echo e($user->gender == 'L' ? 'Laki-laki' : ($user->gender == 'P' ? 'Perempuan' : '-')); ?></div>
                                <select x-show="isEdit" name="gender" class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-pink-300 bg-white">
                                    <option value="" <?php echo e(!$user->gender ? 'selected' : ''); ?> disabled>Pilih</option>
                                    <option value="L" <?php echo e($user->gender == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                                    <option value="P" <?php echo e($user->gender == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Tanggal Lahir</label>
                            <div x-show="!isEdit" class="text-gray-800 text-sm"><?php echo e($user->birth_date ? \Carbon\Carbon::parse($user->birth_date)->translatedFormat('d F Y') : '-'); ?></div>
                            <input x-show="isEdit" type="date" name="birth_date" value="<?php echo e(old('birth_date', $user->birth_date ? \Carbon\Carbon::parse($user->birth_date)->format('Y-m-d') : '')); ?>" class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-sm focus:outline-none focus:ring-2 focus:ring-pink-300">
                        </div>

                        <div>
                            <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">📍 Catatan Alamat Utama</label>
                            <div x-show="!isEdit" class="text-gray-700 bg-gray-50 p-3 rounded-xl text-xs leading-relaxed font-medium border border-gray-100 break-words">
                                <?php echo e($user->address ?? 'Belum ada alamat pengiriman utama yang diatur.'); ?>

                            </div>
                            <textarea x-show="isEdit" name="address" rows="2" maxlength="500" placeholder="Detail alamat utama Anda..." class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-xs resize-none focus:outline-none focus:ring-2 focus:ring-pink-300"><?php echo e(old('address', $user->address)); ?></textarea>
                        </div>
                    </div>

                    <div x-show="isEdit" x-transition class="flex items-center gap-2 pt-2">
                        <button type="submit" class="flex-1 py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-xl text-xs shadow-sm active:scale-[0.98] transition">Simpan</button>
                        <button type="button" @click="isEdit = false" class="px-4 py-2.5 bg-gray-100 text-gray-500 font-bold rounded-xl text-xs active:scale-[0.98] transition">Batal</button>
                    </div>
                </form>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status') === 'profile-updated' || session('success')): ?>
                    <div class="mx-4 sm:mx-6 mb-4 text-xs text-emerald-600 font-semibold bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                        ✅ Pembaruan data berhasil disimpan!
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div class="bg-white sm:rounded-3xl shadow-none sm:shadow-sm border-y sm:border border-pink-50 overflow-hidden">
                <div class="px-4 sm:px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-pink-50/40 via-transparent to-transparent flex items-center justify-between">
                    <span class="text-xs sm:text-sm font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
                        🔒 Keamanan Akun
                    </span>
                    <button type="button" @click="isChangePassword = !isChangePassword"
                        class="px-3 py-1.5 bg-pink-50 text-pink-600 hover:bg-pink-100 rounded-xl font-bold text-xs transition flex items-center gap-1 shrink-0">
                        <span x-text="isChangePassword ? '✖ Batal' : '🔑 Ubah Password'"></span>
                    </button>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status') === 'password-updated'): ?>
                    <div class="m-4 text-xs text-emerald-600 font-semibold bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                        ✅ Password Anda berhasil diperbarui!
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->updatePassword->any()): ?>
                    <div class="m-4 text-xs text-red-600 font-semibold bg-red-50 p-3 rounded-xl border border-red-100 space-y-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->updatePassword->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <p class="flex items-center gap-1">⚠️ <?php echo e($error); ?></p>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <form action="<?php echo e(route('password.update')); ?>" method="POST" x-show="isChangePassword || <?php echo e($errors->updatePassword->any() ? 'true' : 'false'); ?>" x-transition class="p-4 sm:p-6 space-y-3.5 sm:space-y-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>
                        <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Password Saat Ini</label>
                        <input type="password" name="current_password" required class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-pink-300" placeholder="••••••••">
                    </div>

                    <div>
                        <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Password Baru</label>
                        <input type="password" name="password" minlength="8" required class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-pink-300" placeholder="Minimal 8 karakter">
                    </div>

                    <div>
                        <label class="block text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Konfirmasi Password Baru</label>
                        <input type="password" name="password_confirmation" minlength="8" required class="w-full px-3 py-2 rounded-xl border border-pink-100 bg-pink-50/20 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-pink-300" placeholder="Ulangi password baru">
                    </div>

                    <div class="pt-2">
                        <button type="submit" class="w-full py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-xl text-xs shadow-sm active:scale-[0.98] transition">🔒 Update Password</button>
                    </div>
                </form>
            </div>

        </div>

        
        <div class="lg:col-span-7 space-y-4 sm:space-y-6">
            
            <div class="space-y-3 sm:space-y-4">
                <h2 class="text-base sm:text-lg font-bold text-gray-800 px-4 sm:px-0 pt-2 sm:pt-0 flex items-center gap-2">📍 Daftar Alamat Pengiriman</h2>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="bg-white sm:rounded-2xl shadow-none sm:shadow-sm border-y sm:border border-pink-50 p-4 sm:p-5 relative transition hover:border-pink-100">
                        <div class="flex items-start justify-between gap-3">
                            <div class="flex-1 break-words">
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="font-bold text-gray-800 text-sm sm:text-base"><?php echo e($addr->label); ?></span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($addr->is_primary): ?>
                                        <span class="text-[9px] sm:text-[10px] bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full font-bold">Utama</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <p class="text-xs sm:text-sm text-gray-600 font-medium"><?php echo e($addr->recipient_name); ?> • <span class="text-gray-400"><?php echo e($addr->phone); ?></span></p>
                                <p class="text-xs sm:text-sm text-gray-500 mt-1 leading-relaxed"><?php echo e($addr->full_address); ?></p>
                                <p class="text-xs text-pink-500 font-semibold mt-0.5"><?php echo e($addr->city); ?><?php echo e($addr->postal_code ? ' - ' . $addr->postal_code : ''); ?></p>
                            </div>
                            
                            <div class="flex gap-1 shrink-0">
                                <button type="button" onclick="editAddress(<?php echo e($addr->id); ?>)" class="p-1.5 sm:p-2 text-gray-400 hover:text-pink-500 transition" title="Edit Alamat">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                </button>
                                <form action="<?php echo e(route('addresses.destroy', $addr)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus alamat ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="p-1.5 sm:p-2 text-gray-400 hover:text-red-500 transition" title="Hapus Alamat">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    
                    <div id="edit-form-<?php echo e($addr->id); ?>" class="hidden bg-white sm:rounded-2xl shadow-none sm:shadow-sm border-y sm:border border-pink-100 p-4 sm:p-5 my-2 animate-fade-in">
                        <h3 class="text-xs sm:text-sm font-bold text-gray-800 mb-3 flex items-center gap-1">✏️ Edit Informasi Alamat</h3>
                        <form action="<?php echo e(route('addresses.update', $addr)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="space-y-3">
                                <div class="grid grid-cols-2 gap-2.5 sm:gap-3">
                                    <div>
                                        <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Label</label>
                                        <input type="text" name="label" value="<?php echo e($addr->label); ?>" maxlength="50" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                                    </div>
                                    <div>
                                        <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Kabupaten / Kota</label>
                                        <input type="text" name="city" value="<?php echo e($addr->city); ?>" maxlength="100" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                                    </div>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                                    <div>
                                        <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Nama Penerima</label>
                                        <input type="text" name="recipient_name" value="<?php echo e($addr->recipient_name); ?>" maxlength="100" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                                    </div>
                                    <div>
                                        <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">No. Telepon Penerima</label>
                                        <input type="tel" inputmode="tel" name="phone" value="<?php echo e($addr->phone); ?>" maxlength="15" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Alamat Lengkap</label>
                                    <textarea name="full_address" rows="2" maxlength="500" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none resize-none"><?php echo e($addr->full_address); ?></textarea>
                                </div>
                                <div class="grid grid-cols-2 gap-2.5 sm:gap-3 items-center">
                                    <div>
                                        <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Kode Pos</label>
                                        <input type="text" inputmode="numeric" name="postal_code" value="<?php echo e($addr->postal_code); ?>" maxlength="10" class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                                    </div>
                                    <div class="pt-3">
                                        <label class="flex items-center gap-1.5 cursor-pointer select-none">
                                            <input type="checkbox" name="is_primary" value="1" <?php echo e($addr->is_primary ? 'checked' : ''); ?> class="text-pink-500 rounded focus:ring-pink-400 w-3.5 h-3.5">
                                            <span class="text-xs text-gray-600 font-medium">Alamat Utama</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="flex gap-2 pt-1.5">
                                    <button type="submit" class="flex-1 py-2 bg-pink-500 text-white rounded-xl font-bold text-xs">Perbarui</button>
                                    <button type="button" onclick="document.getElementById('edit-form-<?php echo e($addr->id); ?>').classList.add('hidden')" class="px-4 py-2 border border-gray-200 text-gray-600 rounded-xl text-xs">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <div class="bg-white sm:rounded-2xl border-y sm:border border-dashed border-pink-200 p-6 sm:p-8 text-center">
                        <div class="text-3xl sm:text-4xl mb-2">📍</div>
                        <p class="text-gray-400 text-xs font-medium">Belum ada daftar alamat pengiriman tersimpan.</p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div class="bg-white sm:rounded-2xl shadow-none sm:shadow-sm border-y sm:border border-pink-100 p-4 sm:p-5 mt-2 sm:mt-4">
                <h2 class="text-xs sm:text-sm font-bold text-gray-800 mb-3 flex items-center gap-1">➕ Tambah Alamat Pengiriman Baru</h2>
                <form action="<?php echo e(route('addresses.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="space-y-3">
                        <div class="grid grid-cols-2 gap-2.5 sm:gap-3">
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Label Alamat</label>
                                <input type="text" name="label" placeholder="Rumah, Kantor..." maxlength="50" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                            </div>
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Kabupaten / Kota</label>
                                <input type="text" name="city" placeholder="Nama kota" maxlength="100" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                            </div>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Nama Penerima</label>
                                <input type="text" name="recipient_name" maxlength="100" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                            </div>
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">No. Telepon / WA</label>
                                <input type="tel" inputmode="tel" name="phone" placeholder="08123456789" maxlength="15" required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Alamat Lengkap</label>
                            <textarea name="full_address" rows="2" maxlength="500" placeholder="Nama jalan, RT/RW, nomor rumah, patokan..." required class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none resize-none"></textarea>
                        </div>
                        <div class="grid grid-cols-2 gap-2.5 sm:gap-3 items-center">
                            <div>
                                <label class="block text-[10px] sm:text-[11px] font-semibold text-gray-600 mb-1">Kode Pos</label>
                                <input type="text" inputmode="numeric" name="postal_code" maxlength="10" class="w-full px-3 py-1.5 rounded-lg border border-gray-200 text-xs focus:border-pink-400 outline-none">
                            </div>
                            <div class="pt-3">
                                <label class="flex items-center gap-1.5 cursor-pointer select-none">
                                    <input type="checkbox" name="is_primary" value="1" class="text-pink-500 rounded focus:ring-pink-400 w-3.5 h-3.5">
                                    <span class="text-xs text-gray-600 font-medium">Jadikan Alamat Utama</span>
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="w-full py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-bold rounded-xl text-xs shadow-sm active:scale-[0.98] transition">💾 Simpan Alamat Baru</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<script>
function editAddress(id) {
    document.querySelectorAll('[id^="edit-form-"]').forEach(el => el.classList.add('hidden'));
    const form = document.getElementById('edit-form-' + id);
    if (form) {
        form.classList.remove('hidden');
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function previewAvatar(input) {
    if (input.files && input.files[0]) {
        // Validasi ukuran gambar di sisi client (Opsional, max 2MB)
        if (input.files[0].size > 2 * 1024 * 1024) {
            alert("Ukuran gambar terlalu besar! Maksimal 2MB.");
            input.value = "";
            return;
        }
        var reader = new FileReader();
        reader.onload = function(e) {
            const avatarDisplay = document.getElementById('avatar-display');
            if (avatarDisplay) {
                avatarDisplay.src = e.target.result;
            }
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout ?? 'layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/profile/edit.blade.php ENDPATH**/ ?>