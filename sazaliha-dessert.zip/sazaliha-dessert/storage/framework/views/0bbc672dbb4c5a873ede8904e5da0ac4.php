

<?php $__env->startSection('title', 'Dashboard Customer'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
    
    <!-- Welcome Header -->
    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5">
        <div>
            <h1 class="text-xl sm:text-2xl font-black tracking-tight text-gray-800">Dashboard Saya</h1>
            <p class="text-xs sm:text-sm text-gray-400 font-medium mt-0.5">Selamat datang kembali, <?php echo e(auth()->user()->name); ?>! 🍰</p>
        </div>
    </div>

    <!-- Stats Grid (Mobile: 1 Kolom, Tablet: 2 Kolom, Desktop: 3 Kolom) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 mb-6">
        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-xs flex items-center justify-between">
            <div>
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Pesanan</p>
                <p class="text-xl sm:text-2xl font-extrabold text-gray-800 mt-1"><?php echo e($totalOrders); ?></p>
            </div>
            <div class="w-11 h-11 bg-pink-50 rounded-xl flex items-center justify-center text-lg shrink-0">📦</div>
        </div>
        
        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-xs flex items-center justify-between">
            <div>
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Menunggu</p>
                <p class="text-xl sm:text-2xl font-extrabold text-amber-600 mt-1"><?php echo e($pendingOrders); ?></p>
            </div>
            <div class="w-11 h-11 bg-amber-50 rounded-xl flex items-center justify-center text-lg shrink-0">⏳</div>
        </div>

        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-xs flex items-center justify-between sm:col-span-2 lg:col-span-1">
            <div>
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Selesai</p>
                <p class="text-xl sm:text-2xl font-extrabold text-green-600 mt-1"><?php echo e($completedOrders); ?></p>
            </div>
            <div class="w-11 h-11 bg-green-50 rounded-xl flex items-center justify-center text-lg shrink-0">✅</div>
        </div>
    </div>

    <!-- Banner Call To Action (CTA) -->
    <div class="bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl p-5 sm:p-6 text-white mb-6 shadow-sm shadow-pink-100">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
                <h2 class="text-base sm:text-lg font-extrabold tracking-tight">Mau Pesan Dessert Lagi?</h2>
                <p class="text-pink-100 text-xs mt-0.5 font-medium">Temukan varian rasa manis premium kesukaanmu langsung dari dapur kami.</p>
            </div>
            <a href="<?php echo e(route('products.index')); ?>" class="w-full sm:w-auto inline-flex items-center justify-center px-5 py-2.5 bg-white text-pink-600 text-xs sm:text-sm font-bold rounded-xl hover:bg-pink-50 transition shadow-xs whitespace-nowrap active:scale-98">
                Lihat Menu Dessert
                <svg class="w-4 h-4 ml-1.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </a>
        </div>
    </div>

    <!-- Quick Navigation Menu Hub (Hanya tampil di Mobile/Tablet untuk kemudahan jempol) -->
    <div class="block lg:hidden grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <a href="<?php echo e(route('orders.list')); ?>" class="bg-white rounded-xl p-3 border border-gray-100 shadow-xs text-center group active:scale-98 transition">
            <div class="w-9 h-9 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mx-auto mb-1.5 group-hover:scale-105 transition-transform">📦</div>
            <p class="text-xs font-bold text-gray-700">Pesanan</p>
        </a>
        <a href="<?php echo e(route('cart.index')); ?>" class="bg-white rounded-xl p-3 border border-gray-100 shadow-xs text-center group active:scale-98 transition">
            <div class="w-9 h-9 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center mx-auto mb-1.5 group-hover:scale-105 transition-transform">🛒</div>
            <p class="text-xs font-bold text-gray-700">Keranjang</p>
        </a>
        <a href="<?php echo e(route('addresses.index')); ?>" class="bg-white rounded-xl p-3 border border-gray-100 shadow-xs text-center group active:scale-98 transition">
            <div class="w-9 h-9 bg-green-50 text-green-600 rounded-lg flex items-center justify-center mx-auto mb-1.5 group-hover:scale-105 transition-transform">📍</div>
            <p class="text-xs font-bold text-gray-700">Alamat</p>
        </a>
        <a href="<?php echo e(route('reviews.index')); ?>" class="bg-white rounded-xl p-3 border border-gray-100 shadow-xs text-center group active:scale-98 transition">
            <div class="w-9 h-9 bg-amber-50 text-amber-600 rounded-lg flex items-center justify-center mx-auto mb-1.5 group-hover:scale-105 transition-transform">⭐</div>
            <p class="text-xs font-bold text-gray-700">Ulasan</p>
        </a>
    </div>

    <!-- Recent Orders Section -->
    <div class="bg-white rounded-2xl shadow-xs border border-gray-100 overflow-hidden">
        <div class="px-4 sm:px-5 py-3.5 border-b border-gray-50 flex justify-between items-center bg-white">
            <h2 class="font-extrabold text-gray-700 text-xs sm:text-sm uppercase tracking-wider">Riwayat Pesanan</h2>
            <a href="<?php echo e(route('order.create')); ?>" class="text-xs text-pink-500 hover:text-pink-600 font-bold transition">+ Buat Pesanan</a>
        </div>
        
        <div class="divide-y divide-gray-50">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="px-4 sm:px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-gray-50/40 transition">
                <div class="min-w-0 space-y-1">
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="font-bold text-gray-800 text-sm tracking-tight"><?php echo e($order->order_number); ?></span>
                        <span class="px-2.5 py-0.5 text-[10px] rounded-md font-bold uppercase border
                            <?php if($order->status == 'pending'): ?> bg-amber-50 text-amber-700 border-amber-100
                            <?php elseif($order->status == 'processing'): ?> bg-blue-50 text-blue-700 border-blue-100
                            <?php elseif($order->status == 'completed'): ?> bg-green-50 text-green-700 border-green-100
                            <?php else: ?> bg-gray-100 text-gray-600 border-gray-200 <?php endif; ?>">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?> Menunggu
                            <?php elseif($order->status == 'processing'): ?> Diproses
                            <?php elseif($order->status == 'completed'): ?> Selesai
                            <?php elseif($order->status == 'cancelled'): ?> Dibatalkan
                            <?php else: ?> <?php echo e($order->status); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </span>
                    </div>
                    <div class="text-xs text-gray-500 font-semibold">
                        <?php echo e($order->items->count()); ?> Item <span class="text-gray-300 mx-1">·</span> <span class="text-rose-600 font-bold">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                    </div>
                    <div class="text-[11px] text-gray-400 font-medium"><?php echo e($order->created_at->format('d M Y, H:i')); ?> Wita</div>
                </div>

                <!-- Action Row Buttons -->
                <div class="flex items-center gap-2 pt-1 sm:pt-0">
                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="flex-1 sm:flex-initial px-3 py-1.5 text-center text-xs bg-gray-50 text-gray-700 rounded-lg font-bold hover:bg-pink-50 hover:text-pink-600 transition border border-gray-100">
                        Detail
                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status == 'pending'): ?>
                    <form action="<?php echo e(route('orders.cancel', $order)); ?>" method="POST" onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?');" class="flex-1 sm:flex-initial">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="w-full px-3 py-1.5 text-center text-xs bg-red-50 text-red-600 rounded-lg font-bold hover:bg-red-100 transition border border-red-100">
                            Batal
                        </button>
                    </form>
                    <?php elseif($order->status == 'cancelled'): ?>
                    <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus berkas riwayat pesanan ini?');" class="flex-1 sm:flex-initial">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="w-full px-3 py-1.5 text-center text-xs bg-gray-100 text-gray-500 rounded-lg font-bold hover:bg-red-50 hover:text-red-600 transition">
                            Hapus
                        </button>
                    </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <div class="px-5 py-12 text-center">
                <div class="text-3xl mb-2">🧁</div>
                <p class="text-gray-400 text-xs font-bold uppercase tracking-wider">Belum ada riwayat transaksi</p>
                <a href="<?php echo e(route('products.index')); ?>" class="text-pink-500 text-xs font-black hover:underline mt-1 inline-block">Yuk, pilih kue pertamamu!</a>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>