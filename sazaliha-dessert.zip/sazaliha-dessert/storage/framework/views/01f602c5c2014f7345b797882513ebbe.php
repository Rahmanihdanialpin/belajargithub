

<?php $__env->startSection('title', 'Laporan Keuangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-5 sm:mb-6">
    <h1 class="text-xl sm:text-2xl font-black tracking-tight text-gray-800">Laporan Keuangan Terintegrasi</h1>
    <p class="text-xs sm:text-sm text-gray-400 font-medium mt-0.5">Sinkronisasi otomatis penjualan Web E-Commerce dan Point of Sale (POS)</p>
</div>

<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5 sm:mb-6">
    <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
        <p class="text-xs sm:text-sm font-semibold text-gray-400 uppercase tracking-wider">Total Omset</p>
        <p class="text-xl sm:text-2xl font-extrabold text-gray-800 mt-1.5 break-all">Rp <?php echo e(number_format($totalRevenue, 0, ',', '.')); ?></p>
        <div class="flex gap-2 mt-2 text-[10px] font-bold">
            <span class="text-pink-500">🌐 Web: Rp <?php echo e(number_format($onlineRevenue, 0, ',', '.')); ?></span>
            <span class="text-amber-600">🏪 POS: Rp <?php echo e(number_format($posRevenue, 0, ',', '.')); ?></span>
        </div>
    </div>
    <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
        <p class="text-xs sm:text-sm font-semibold text-gray-400 uppercase tracking-wider">Total Biaya Modal (HPP)</p>
        <p class="text-xl sm:text-2xl font-extrabold text-gray-800 mt-1.5 break-all">Rp <?php echo e(number_format($totalCost, 0, ',', '.')); ?></p>
    </div>
    <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
        <p class="text-xs sm:text-sm font-semibold text-gray-400 uppercase tracking-wider">Laba Kotor Gabungan</p>
        <p class="text-xl sm:text-2xl font-extrabold mt-1.5 break-all <?php echo e($grossProfit >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
            Rp <?php echo e(number_format($grossProfit, 0, ',', '.')); ?>

        </p>
    </div>
    <div class="bg-white rounded-2xl p-4 sm:p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
        <p class="text-xs sm:text-sm font-semibold text-gray-400 uppercase tracking-wider">Rasio Transaksi</p>
        <p class="text-xl sm:text-2xl font-extrabold text-gray-800 mt-1.5"><?php echo e($orders->count()); ?> <span class="text-xs font-normal text-gray-400">Total</span></p>
        <div class="flex gap-2 mt-2 text-[10px] font-bold">
            <span class="bg-pink-50 text-pink-600 px-1.5 py-0.5 rounded">🌐 <?php echo e($orders->where('source', 'online')->count()); ?> Online</span>
            <span class="bg-amber-50 text-amber-600 px-1.5 py-0.5 rounded">🏪 <?php echo e($orders->where('source', 'pos')->count()); ?> POS</span>
        </div>
    </div>
</div>

<div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 mb-5 sm:mb-6">
    <form action="<?php echo e(route('admin.reports.index')); ?>" method="GET" class="space-y-4 md:space-y-0 md:flex md:flex-row md:gap-3 md:items-end">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Dari Tanggal</label>
                <input type="date" name="start_date" value="<?php echo e(request('start_date', $startDate->format('Y-m-d'))); ?>" class="w-full text-sm px-3.5 py-2.5 rounded-xl border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Sampai Tanggal</label>
                <input type="date" name="end_date" value="<?php echo e(request('end_date', $endDate->format('Y-m-d'))); ?>" class="w-full text-sm px-3.5 py-2.5 rounded-xl border border-gray-200 focus:border-pink-400 focus:ring-2 focus:ring-pink-100 outline-none transition">
            </div>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-3 md:flex md:flex-row gap-2.5 pt-2 md:pt-0">
            <button type="submit" class="w-full md:w-auto px-5 py-2.5 bg-pink-500 text-white text-sm rounded-xl font-bold hover:bg-pink-600 transition shadow-sm active:scale-98">
                Tampilkan
            </button>
            <a href="<?php echo e(route('admin.reports.pdf', request()->only(['start_date', 'end_date']))); ?>" class="w-full md:w-auto px-5 py-2.5 bg-red-500 text-white text-sm rounded-xl font-bold hover:bg-red-600 transition flex items-center justify-center gap-2 shadow-sm active:scale-98">
                <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                PDF
            </a>
            <a href="<?php echo e(route('admin.reports.excel', request()->only(['start_date', 'end_date']))); ?>" class="w-full md:w-auto px-5 py-2.5 bg-green-600 text-white text-sm rounded-xl font-bold hover:bg-green-700 transition flex items-center justify-center gap-2 shadow-sm active:scale-98">
                <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Excel
            </a>
        </div>
    </form>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mb-5 sm:mb-6">
    <div class="px-4 py-3.5 border-b border-gray-50 bg-white/50">
        <h2 class="text-sm sm:text-base font-extrabold text-gray-700">Rekap Penjualan Harian</h2>
    </div>
    <div class="overflow-x-auto scrollbar-thin">
        <table class="w-full text-xs sm:text-sm text-left whitespace-nowrap">
            <thead class="bg-gray-50 text-gray-400 font-bold uppercase tracking-wider text-[10px] sm:text-xs border-b border-gray-100">
                <tr>
                    <th class="px-4 py-3 font-bold">Tanggal</th>
                    <th class="px-4 py-3 font-bold text-center">Order (Web / POS)</th>
                    <th class="px-4 py-3 font-bold">Pendapatan (Web / POS)</th>
                    <th class="px-4 py-3 font-bold">Biaya Modal (HPP)</th>
                    <th class="px-4 py-3 font-bold">Laba Bersih</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $dailyReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="hover:bg-gray-50/50 transition">
                    <td class="px-4 py-3 font-bold text-gray-700"><?php echo e(\Carbon\Carbon::parse($date)->format('d M Y')); ?></td>
                    <td class="px-4 py-3 text-center text-gray-600 font-medium">
                        <span class="font-bold text-gray-800"><?php echo e($report['orders']); ?></span>
                        <span class="text-gray-400 text-[11px]">(<?php echo e($report['online_orders']); ?> / <?php echo e($report['pos_orders']); ?>)</span>
                    </td>
                    <td class="px-4 py-3 text-gray-600 font-semibold">
                        <div>Rp <?php echo e(number_format($report['revenue'], 0, ',', '.')); ?></div>
                        <div class="text-[10px] text-gray-400 font-normal">
                            🌐 Rp <?php echo e(number_format($report['online_revenue'], 0, ',', '.')); ?> | 🏪 Rp <?php echo e(number_format($report['pos_revenue'], 0, ',', '.')); ?>

                        </div>
                    </td>
                    <td class="px-4 py-3 text-gray-500">Rp <?php echo e(number_format($report['cost'], 0, ',', '.')); ?></td>
                    <td class="px-4 py-3 font-bold <?php echo e($report['profit'] >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
                        Rp <?php echo e(number_format($report['profit'], 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="5" class="px-4 py-10 text-center text-gray-400 font-medium">Tidak ada data penjualan pada periode ini.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-4 py-3.5 border-b border-gray-50 bg-white/50">
        <h2 class="text-sm sm:text-base font-extrabold text-gray-700">Detail Transaksi Gabungan (<?php echo e($orders->count()); ?>)</h2>
    </div>
    <div class="overflow-x-auto scrollbar-thin">
        <table class="w-full text-xs sm:text-sm text-left whitespace-nowrap">
            <thead class="bg-gray-50 text-gray-400 font-bold uppercase tracking-wider text-[10px] sm:text-xs border-b border-gray-100">
                <tr>
                    <th class="px-4 py-3 font-bold">No Pesanan</th>
                    <th class="px-4 py-3 font-bold">Sumber</th>
                    <th class="px-4 py-3 font-bold">Nama Pelanggan / Kasir</th>
                    <th class="px-4 py-3 font-bold">Total Transaksi</th>
                    <th class="px-4 py-3 font-bold">Tanggal</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr class="hover:bg-gray-50/50 transition">
                    <td class="px-4 py-3 font-bold text-pink-600 tracking-tight"><?php echo e($order->order_number); ?></td>
                    <td class="px-4 py-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->source === 'online'): ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold rounded-full bg-pink-50 text-pink-600 border border-pink-100">
                                🌐 Online
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold rounded-full bg-amber-50 text-amber-600 border border-amber-100">
                                🏪 POS Kasir
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-gray-700 font-semibold">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->source === 'online'): ?>
                            <?php echo e($order->customer_name ?? $order->user->name ?? 'Pelanggan Web'); ?>

                        <?php else: ?>
                            <span class="text-gray-800"><?php echo e($order->customer_name ?? 'Walk-in Customer'); ?></span>
                            <span class="text-gray-400 text-xs font-normal block">Staf: <?php echo e($order->cashier->name ?? 'Kasir Utama'); ?></span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                    <td class="px-4 py-3 font-extrabold text-rose-600">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></td>
                    <td class="px-4 py-3 text-gray-400 font-medium"><?php echo e($order->created_at->format('d M Y H:i')); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="5" class="px-4 py-10 text-center text-gray-400 font-medium">Belum ada riwayat pesanan terdata.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>