<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: 'Arial', sans-serif; color: #333; }
        .header h1 { color: #e11d48; margin: 0; font-size: 16px; font-weight: bold; }
        .header p { margin: 5px 0; color: #666; font-size: 11px; }
        
        /* Tabel Summary Horizontal */
        .summary-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .summary-table th { background: #fdf2f8; color: #666; padding: 10px; border: 1px solid #fbcfe8; font-size: 10px; text-transform: uppercase; }
        .summary-table td { padding: 10px; border: 1px solid #fbcfe8; text-align: center; font-weight: bold; font-size: 12px; }
        
        /* Tabel Data */
        table.data-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #fdf2f8; color: #e11d48; padding: 8px; text-align: left; font-size: 11px; font-weight: bold; border: 1px solid #e11d48; }
        td { padding: 8px; border: 1px solid #eee; font-size: 11px; }
        
        .text-right { text-align: right; }
        .text-green { color: #16a34a; }
        .text-red { color: #dc2626; }
        .footer { margin-top: 30px; text-align: center; font-size: 9px; color: #999; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Sazaliha Dessert</h1>
        <p>Laporan Keuangan</p>
        <p>Periode: <?php echo e($startDate->format('d M Y')); ?> - <?php echo e($endDate->format('d M Y')); ?></p>
    </div>

    <table class="summary-table" border="1">
        <thead>
            <tr>
                <th>Total Pendapatan</th>
                <th>Total Modal</th>
                <th>Laba Kotor</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Rp <?php echo e(number_format($totalRevenue, 0, ',', '.')); ?></td>
                <td>Rp <?php echo e(number_format($totalCost, 0, ',', '.')); ?></td>
                <td class="<?php echo e($grossProfit >= 0 ? 'text-green' : 'text-red'); ?>">
                    Rp <?php echo e(number_format($grossProfit, 0, ',', '.')); ?>

                </td>
            </tr>
        </tbody>
    </table>

    <h3 style="color: #e11d48; font-size: 12px;">Rekap Harian</h3>
    <table class="data-table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th class="text-right">Jumlah Order</th>
                <th class="text-right">Pendapatan</th>
                <th class="text-right">Biaya Modal</th>
                <th class="text-right">Laba</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $dailyReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($date)->format('d M Y')); ?></td>
                <td class="text-right"><?php echo e($report['orders']); ?></td>
                <td class="text-right">Rp <?php echo e(number_format($report['revenue'], 0, ',', '.')); ?></td>
                <td class="text-right">Rp <?php echo e(number_format($report['cost'], 0, ',', '.')); ?></td>
                <td class="text-right <?php echo e($report['profit'] >= 0 ? 'text-green' : 'text-red'); ?>">
                    Rp <?php echo e(number_format($report['profit'], 0, ',', '.')); ?>

                </td>
            </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <tr>
                <td colspan="5" style="text-align: center;">Tidak ada data.</td>
            </tr>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        Dicetak pada <?php echo e(now()->format('d M Y H:i')); ?> | Sazaliha Dessert
    </div>
</body>
</html><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/admin/reports/financial-report.blade.php ENDPATH**/ ?>