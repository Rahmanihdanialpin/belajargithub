

<?php $__env->startSection('title', 'Ulasan Saya - Sazaliha'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">

    <h1 class="text-xl md:text-2xl font-bold text-gray-800 mb-5 md:mb-6">Ulasan & Rating ⭐</h1>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pendingReviews->count() > 0): ?>
    <div class="bg-white rounded-xl shadow-sm border border-pink-50 p-4 md:p-6 mb-6">
        <h2 class="font-bold text-base md:text-lg text-gray-800 mb-4">Pesanan Selesai - Belum Diulas</h2>
        <div class="space-y-3 md:space-y-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pendingReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
                    <div class="flex items-center gap-3 md:gap-4">
                        <div class="w-12 h-12 md:w-14 md:h-14 rounded-lg bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center text-xl flex-shrink-0 border border-pink-100/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>" class="w-full h-full object-cover rounded-lg">
                            <?php else: ?>
                                🍰
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="font-semibold md:font-medium text-gray-800 text-sm md:text-base truncate"><?php echo e($item->product->name); ?></p>
                            <p class="text-xs text-gray-500 mt-0.5"><?php echo e($order->order_number); ?> · <?php echo e($order->completed_at?->format('d M Y')); ?></p>
                        </div>
                    </div>
                    <button onclick="openReviewModal(<?php echo e($item->product->id); ?>, '<?php echo e(addslashes($item->product->name)); ?>', <?php echo e($order->id); ?>)" class="w-full sm:w-auto text-center px-4 py-2.5 sm:py-2 bg-amber-500 text-white text-sm rounded-lg font-medium hover:bg-amber-600 active:scale-[0.98] transition shadow-sm shadow-amber-500/20">
                        Beri Ulasan
                    </button>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="bg-white rounded-xl shadow-sm border border-pink-50 p-4 md:p-6">
        <h2 class="font-bold text-base md:text-lg text-gray-800 mb-4">Ulasan Saya</h2>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="p-4 border border-gray-100 rounded-xl mb-3 last:mb-0 bg-white hover:border-pink-100 transition-colors">
            <div class="flex flex-row items-start justify-between gap-2">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-50 to-rose-50 flex items-center justify-center text-lg border border-pink-100/50 flex-shrink-0">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $review->product->image)); ?>" alt="<?php echo e($review->product->name); ?>" class="w-full h-full object-cover rounded-lg">
                        <?php else: ?>
                            🍰
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div>
                        <p class="font-semibold md:font-medium text-gray-800 text-sm md:text-base"><?php echo e($review->product->name); ?></p>
                        <div class="flex items-center gap-0.5 mt-0.5">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <svg class="w-3.5 h-3.5 <?php echo e($i <= $review->rating ? 'text-amber-400 fill-current' : 'text-gray-200'); ?>" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                </svg>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    </div>
                </div>
                <span class="text-[11px] text-gray-400 whitespace-nowrap"><?php echo e($review->created_at->format('d M Y')); ?></span>
            </div>
            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->comment): ?>
            <p class="text-sm text-gray-600 mt-2.5 bg-gray-50/50 p-2.5 rounded-lg border border-gray-50"><?php echo e($review->comment); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <form action="<?php echo e(route('reviews.destroy', $review)); ?>" method="POST" class="mt-3 text-right sm:text-left" onsubmit="return confirm('Hapus ulasan ini?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-xs text-red-400 hover:text-red-500 font-medium p-1 -m-1 transition-colors">Hapus Ulasan</button>
            </form>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <div class="text-center py-10">
            <div class="text-4xl mb-3">⭐</div>
            <p class="text-gray-500 font-medium text-sm md:text-base">Belum ada ulasan</p>
            <p class="text-xs text-gray-400 mt-1">Ulas produk kuliner yang sudah Anda nikmati</p>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>


<div id="reviewModal" class="fixed inset-0 bg-black/60 hidden items-end sm:items-center justify-center z-50 p-0 sm:p-4 transition-opacity duration-300">
    <div class="bg-white rounded-t-2xl sm:rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto transform transition-all shadow-xl">
        <div class="flex justify-between items-start mb-2">
            <h3 class="text-lg font-bold text-gray-800">Beri Ulasan</h3>
            <button type="button" onclick="closeReviewModal()" class="text-gray-400 hover:text-gray-600 sm:hidden text-2xl p-1 -mt-2">&times;</button>
        </div>
        <p id="reviewProductName" class="text-sm font-medium text-pink-600 mb-5"></p>
        
        <form action="<?php echo e(route('reviews.store')); ?>" method="POST" id="reviewForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" id="reviewProductId">
            <input type="hidden" name="order_id" id="reviewOrderId">
            
            <div class="mb-5 bg-pink-50/30 p-4 rounded-xl border border-pink-100/50 text-center">
                <label class="block text-sm font-semibold text-gray-700 mb-3">Ketuk untuk memberi rating</label>
                <div class="flex items-center justify-center gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <label class="cursor-pointer group">
                        <input type="radio" name="rating" value="<?php echo e($i); ?>" class="hidden rating-input" <?php echo e($i == 5 ? 'checked' : ''); ?>>
                        <svg class="w-9 h-9 text-amber-400 fill-current transition transform active:scale-125 star-icon" data-value="<?php echo e($i); ?>" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                        </svg>
                    </label>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>

            <div class="mb-5">
                <label class="block text-sm font-semibold text-gray-700 mb-1.5">Komentar (opsional)</label>
                <textarea name="comment" rows="3" class="w-full px-3 py-2.5 text-sm rounded-xl border border-gray-200 focus:border-pink-400 focus:ring-4 focus:ring-pink-100 outline-none transition resize-none" placeholder="Bagaimana rasa dan kualitas produknya?"></textarea>
            </div>

            <div class="flex flex-col-reverse sm:flex-row items-center gap-2.5 pb-2 sm:pb-0">
                <button type="button" onclick="closeReviewModal()" class="w-full sm:flex-1 py-3 border border-gray-200 text-gray-600 rounded-xl font-medium text-sm hover:bg-gray-50 transition active:bg-gray-100">
                    Batal
                </button>
                <button type="submit" class="w-full sm:flex-1 py-3 bg-pink-500 text-white rounded-xl font-medium text-sm hover:bg-pink-600 transition shadow-sm shadow-pink-500/10 active:scale-[0.99]">
                    Kirim Ulasan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openReviewModal(productId, productName, orderId) {
    document.getElementById('reviewProductId').value = productId;
    document.getElementById('reviewOrderId').value = orderId;
    document.getElementById('reviewProductName').textContent = productName;
    
    const modal = document.getElementById('reviewModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    document.body.classList.add('overflow-hidden'); // Kunci scroll background di mobile
    
    resetStars(5); // Reset ke default bintang 5 saat modal dibuka
}

function closeReviewModal() {
    const modal = document.getElementById('reviewModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.classList.remove('overflow-hidden');
    document.getElementById('reviewForm').reset();
}

// Interaktivitas UI Bintang Terpilih di Modal
const starInputs = document.querySelectorAll('.rating-input');
const starIcons = document.querySelectorAll('.star-icon');

starInputs.forEach(input => {
    input.addEventListener('change', (e) => {
        resetStars(e.target.value);
    });
});

function resetStars(ratingValue) {
    starIcons.forEach(icon => {
        const iconValue = icon.getAttribute('data-value');
        if (parseInt(iconValue) <= parseInt(ratingValue)) {
            icon.classList.remove('text-gray-200');
            icon.classList.add('text-amber-400', 'fill-current');
        } else {
            icon.classList.remove('text-amber-400', 'fill-current');
            icon.classList.add('text-gray-200');
        }
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sazaliha-dessert\resources\views/reviews/index.blade.php ENDPATH**/ ?>