<?php

use App\Http\Controllers\CartController;
use App\Http\Controllers\CustomerDashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrderController;


use App\Http\Controllers\ProductController;
use App\Http\Controllers\AddressController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\IngredientController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\Admin\FeatureToggleController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\ReviewController as AdminReviewController;

Route::middleware(['auth'])->group(function () {
    // Route untuk Dashboard Customer
    Route::get('/customer/dashboard', [CustomerDashboardController::class, 'index'])->name('customer.dashboard');
});

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', function () {return view('about');})->name('about');

// Public Product Routes
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{slug}', [ProductController::class, 'show'])->name('products.show');

// Cart & Order Routes (require login)
Route::middleware('auth')->group(function () {
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
    Route::post('/cart/buy-now', [CartController::class, 'buyNow'])->name('cart.buy-now');
    Route::patch('/cart/update/{id}', [CartController::class, 'update'])->name('cart.update');
    Route::delete('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');
    Route::post('/cart/clear', [CartController::class, 'clear'])->name('cart.clear');

    Route::get('/order', [OrderController::class, 'create'])->name('order.create');
    Route::post('/order', [OrderController::class, 'store'])->name('order.store');
    Route::get('/order/success/{order}', [OrderController::class, 'success'])->name('order.success');

    // Customer Order Detail & Cancel
    Route::get('/orders/{order}', [OrderController::class, 'customerShow'])->name('orders.show');
    Route::patch('/orders/{order}/cancel', [OrderController::class, 'customerCancel'])->name('orders.cancel');
    Route::delete('/orders/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');

    // Payment Routes (disabled)
    // Route::get('/orders/{order}/pay', [PaymentController::class, 'getSnapToken'])->name('orders.pay.token');

    // Addresses
    Route::get('/addresses', [AddressController::class, 'index'])->name('addresses.index');
    Route::post('/addresses', [AddressController::class, 'store'])->name('addresses.store');
    Route::patch('/addresses/{address}', [AddressController::class, 'update'])->name('addresses.update');
    Route::delete('/addresses/{address}', [AddressController::class, 'destroy'])->name('addresses.destroy');

    // Reviews
    Route::get('/reviews', [ReviewController::class, 'index'])->name('reviews.index');
    Route::post('/reviews', [ReviewController::class, 'store'])->name('reviews.store');
    Route::delete('/reviews/{review}', [ReviewController::class, 'destroy'])->name('reviews.destroy');

    // Customer Orders List by Status
    Route::get('/my-orders', [OrderController::class, 'customerOrders'])->name('orders.list');
});

//Admin POS Routes
Route::middleware(['auth'])->prefix('admin/pos')->name('admin.pos.')->group(function () {
    Route::get('/', [App\Http\Controllers\Admin\PosController::class, 'index'])->name('index');
    Route::post('/store', [App\Http\Controllers\Admin\PosController::class, 'store'])->name('store');
});


// Auth Dashboard
Route::get('/dashboard', function () {
    if (auth()->user()->hasAdminAccess()) {
        return redirect()->route('admin.dashboard');
    }

    return app(CustomerDashboardController::class)->index();
})->middleware(['auth', 'verified'])->name('dashboard');


Route::middleware('auth')->group(function () {
    // Profil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Alamat
    Route::post('/addresses', [AddressController::class, 'store'])->name('addresses.store');
    Route::patch('/addresses/{address}', [AddressController::class, 'update'])->name('addresses.update');
    Route::delete('/addresses/{address}', [AddressController::class, 'destroy'])->name('addresses.destroy');
});

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [ReportController::class, 'dashboard'])->name('dashboard');
    Route::get('/feature-toggles', [FeatureToggleController::class, 'index'])
        ->middleware('permission:admin.feature-toggle.manage')
        ->name('feature-toggles.index');
    Route::post('/feature-toggles', [FeatureToggleController::class, 'update'])
        ->middleware('permission:admin.feature-toggle.manage')
        ->name('feature-toggles.update');

    // Users
    Route::get('/users', [\App\Http\Controllers\Admin\UserController::class, 'index'])
        ->middleware('role:super admin')
        ->name('users.index');
    Route::get('/users/{user}/edit', [\App\Http\Controllers\Admin\UserController::class, 'edit'])
        ->middleware('role:super admin')
        ->name('users.edit');
    Route::patch('/users/{user}', [\App\Http\Controllers\Admin\UserController::class, 'update'])
        ->middleware('role:super admin')
        ->name('users.update');

    // Ingredients (Bahan Baku)
    Route::get('/ingredients', [IngredientController::class, 'index'])
        ->middleware('permission:ingredients.read')
        ->name('ingredients.index');
    Route::get('/ingredients/create', [IngredientController::class, 'create'])
        ->middleware('permission:ingredients.create')
        ->name('ingredients.create');
    Route::post('/ingredients', [IngredientController::class, 'store'])
        ->middleware('permission:ingredients.create')
        ->name('ingredients.store');
    Route::get('/ingredients/{ingredient}/edit', [IngredientController::class, 'edit'])
        ->middleware('permission:ingredients.update')
        ->name('ingredients.edit');
    Route::put('/ingredients/{ingredient}', [IngredientController::class, 'update'])
        ->middleware('permission:ingredients.update')
        ->name('ingredients.update');
    Route::delete('/ingredients/{ingredient}', [IngredientController::class, 'destroy'])
        ->middleware('permission:ingredients.delete')
        ->name('ingredients.destroy');

    // Products (Menu)
    Route::get('/products', [ProductController::class, 'adminIndex'])
        ->middleware('permission:products.read')
        ->name('products.index');
    Route::get('/products/create', [ProductController::class, 'create'])
        ->middleware('permission:products.create')
        ->name('products.create');
    Route::post('/products', [ProductController::class, 'store'])
        ->middleware('permission:products.create')
        ->name('products.store');
    Route::get('/products/{product}/edit', [ProductController::class, 'edit'])
        ->middleware('permission:products.update')
        ->name('products.edit');
    Route::put('/products/{product}', [ProductController::class, 'update'])
        ->middleware('permission:products.update')
        ->name('products.update');
    Route::delete('/products/{product}', [ProductController::class, 'destroy'])
        ->middleware('permission:products.delete')
        ->name('products.destroy');

    // Orders
    Route::get('/orders', [OrderController::class, 'adminIndex'])
        ->middleware('permission:orders.read')
        ->name('orders.index');
    Route::get('/orders/{order}', [OrderController::class, 'adminShow'])
        ->middleware('permission:orders.read')
        ->name('orders.show');
    Route::patch('/orders/{order}/status', [OrderController::class, 'updateStatus'])
        ->middleware('permission:orders.update')
        ->name('orders.status');
    Route::delete('/orders/{order}', [OrderController::class, 'destroy'])
        ->middleware('permission:orders.delete')
        ->name('orders.destroy');

    // Reports
    Route::get('/reports', [ReportController::class, 'index'])
        ->middleware('permission:reports.read')
        ->name('reports.index');
    Route::get('/reports/pdf', [ReportController::class, 'exportPdf'])
        ->middleware('permission:reports.read')
        ->name('reports.pdf');
    Route::get('/reports/excel', [ReportController::class, 'exportExcel'])
        ->middleware('permission:reports.read')
        ->name('reports.excel');     
});

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    // ... rute lain ...
    
    // Management Ulasan Khusus Admin
    Route::get('/reviews', [AdminReviewController::class, 'index'])->name('reviews.index');
    Route::post('/reviews', [AdminReviewController::class, 'store'])->name('reviews.store');
    Route::delete('/reviews/{review}', [AdminReviewController::class, 'destroy'])->name('reviews.destroy');
});



require __DIR__.'/email-verification.php';

require __DIR__.'/auth.php';
