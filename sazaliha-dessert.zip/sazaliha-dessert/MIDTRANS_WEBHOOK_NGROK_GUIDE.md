# Panduan: Midtrans Webhook dengan Ngrok (Local Development)

## 1. Install Ngrok

### Via Chocolatey (Windows):
```powershell
choco install ngrok
```

### Via Download Langsung:
1. Download dari [https://ngrok.com/download](https://ngrok.com/download)
2. Extract `ngrok.exe` ke folder yang ada di PATH (misal: `C:\Windows\System32`)

## 2. Daftar & Autentikasi Ngrok

1. Buat akun di [https://dashboard.ngrok.com/signup](https://dashboard.ngrok.com/signup)
2. Copy **Authtoken** dari dashboard
3. Jalankan di terminal:
```powershell
ngrok config add-authtoken YOUR_AUTHTOKEN
```

## 3. Jalankan Ngrok untuk Project Laravel

### Temukan Port Laragon Anda:
Secara default Laragon menggunakan port **80**. Pastikan dengan membuka:
- `http://sazaliha-dessert.test` (jika pakai pretty URL)
- Atau `http://localhost`

### Jalankan Ngrok:
```powershell
# Untuk HTTP (port 80)
ngrok http http://localhost --host-header=rewrite

# Atau jika menggunakan domain lokal spesifik
grok http http://sazaliha-dessert.test --host-header=rewrite

# Untuk HTTPS (disarankan)
grok http https://localhost --host-header=rewrite
```

### Output yang Muncul:
```
Session Status                online
Account                       your-email@gmail.com
Version                       3.x.x
Region                        Asia Pacific (ap)
Latence                       xxms
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://abc123.ngrok-free.app -> http://localhost:80
```

**Catat URL Ngrok:** `https://abc123.ngrok-free.app`

---

## 4. Konfigurasi Webhook di Dashboard Midtrans

### A. Environment Sandbox (Testing):
1. Login ke [https://dashboard.sandbox.midtrans.com](https://dashboard.sandbox.midtrans.com)
2. Pilih project Anda → **Settings** → **Configuration**
3. Scroll ke bagian **Notification URL**
4. Masukkan URL:
   ```
   https://abc123.ngrok-free.app/midtrans/webhook
   ```
5. Klik **Update**

### B. Environment Production:
1. Login ke [https://dashboard.midtrans.com](https://dashboard.midtrans.com)
2. Lakukan langkah yang sama seperti di atas

---

## 5. Konfigurasi Laravel

### `.env` File:
```env
# Midtrans Configuration
MIDTRANS_SERVER_KEY=SB-Mid-server-xxxxxxxxxxxxx
MIDTRANS_CLIENT_KEY=SB-Mid-client-xxxxxxxxxxxxx
MIDTRANS_IS_PRODUCTION=false
MIDTRANS_IS_SANITIZED=true
MIDTRANS_IS_3DS=true

# Whatsapp
WHATSAPP_ADMIN_NUMBER=6281234567890
```

### Catatan Penting tentang CSRF:
Karena Midtrans mengirim POST request ke `/midtrans/webhook`, dan Laravel secara default memiliki **CSRF protection** untuk route web, Anda perlu mengecualikan route webhook dari CSRF verification.

### Update `bootstrap/app.php`:
```php
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => \App\Http\Middleware\AdminMiddleware::class,
        ]);
        
        // Exclude Midtrans webhook from CSRF verification
        $middleware->validateCsrfTokens(except: [
            '/midtrans/webhook',
            '/midtrans/webhook/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
```

---

## 6. Struktur Route Webhook

Route webhook sudah dibuat di `routes/web.php`:
```php
// Midtrans Webhook (no auth — called by Midtrans server)
Route::post('/midtrans/webhook', [MidtransWebhookController::class, 'handle'])->name('midtrans.webhook');
```

### Cara Kerja Webhook:
1. Customer melakukan pembayaran via Snap
2. Midtrans memproses transaksi
3. Midtrans mengirim POST request ke URL webhook Anda
4. Controller memverifikasi signature key
5. Status order diperbarui sesuai hasil pembayaran

---

## 7. Testing Webhook dengan Ngrok

### A. Simulasi Pembayaran (Midtrans Simulator):
1. Buka dashboard Midtrans Sandbox
2. Pilih **Transactions** → pilih order
3. Klik **Action** → **Simulator** → pilih status yang diinginkan
4. Webhook akan terkirim ke Ngrok URL Anda

### B. Monitor Request di Ngrok Dashboard:
1. Buka `http://127.0.0.1:4040`
2. Anda akan melihat semua request yang masuk
3. Klik request untuk melihat detail headers dan body

### C. Log Laravel:
```powershell
# Live log
tail -f storage/logs/laravel.log

# Atau di Windows PowerShell
Get-Content -Path storage/logs/laravel.log -Wait
```

---

## 8. Troubleshooting Umum

### Masalah 1: Ngrok URL Berubah Setiap Restart
**Solusi:**
- Gunakan Ngrok Static Domain (berbayar), atau
- Update Notification URL di Midtrans setiap kali restart Ngrok, atau
- Buat script otomatis untuk update (via API)

### Masalah 2: Midtrans Tidak Bisa Mengirim ke Ngrok (Free Tier)
**Error:** `502 Bad Gateway` atau `Tunnel not found`

**Solusi:**
1. Pastikan Ngrok masih berjalan
2. Pastikan URL di Midtrans sama persis dengan yang ditampilkan Ngrok
3. Jika domain free tier expired/blocked oleh Midtrans, ganti ke paid plan ($5/bulan)

### Masalah 3: Signature Verification Failed
**Solusi:**
1. Pastikan `MIDTRANS_SERVER_KEY` di `.env` benar (server key, bukan client key)
2. Untuk Sandbox, pastikan pakai key Sandbox (dimulai dengan `SB-Mid-server-`)
3. Periksa log di `MidtransWebhookController` untuk payload yang diterima

### Masalah 4: 419 Page Expired (CSRF)
**Solusi:**
Pastikan route webhook sudah di-exclude dari CSRF seperti pada langkah 5.

### Masalah 5: Webhook Tidak Diterima
**Checklist:**
- [ ] Ngrok masih berjalan?
- [ ] URL webhook di Midtrans benar (including `https://`)?
- [ ] Route `/midtrans/webhook` ada di `routes/web.php`?
- [ ] Controller tidak return error?
- [ ] Periksa `storage/logs/laravel.log`

---

## 9. Quick Start Command

```powershell
# Terminal 1: Jalankan Ngrok
ngrok http http://localhost --host-header=rewrite

# Terminal 2: Jalankan Laragon/Laravel
php artisan serve
# atau
php artisan serve --host=0.0.0.0

# Terminal 3: Monitor Log
Get-Content -Path storage/logs/laravel.log -Wait
```

Setelah Ngrok jalan, copy URL forwarding (`https://abc123.ngrok-free.app`), lalu update Notification URL di Midtrans Dashboard ke:
```
https://abc123.ngrok-free.app/midtrans/webhook
```

---

## 10. Testing Flow Lengkap

| Langkah | Action | Hasil Yang Diharapkan |
|---------|--------|----------------------|
| 1 | Customer membuat order | Order status: `pending`, payment_status: `null` |
| 2 | Customer klik "Bayar Sekarang" | Snap modal muncul, token generated |
| 3 | Customer bayar di Snap | Redirect ke halaman sukses/gagal |
| 4 | Midtrans kirim webhook | Request POST ke `/midtrans/webhook` |
| 5 | Signature verified | Order status berubah: `processing` |
| 6 | Refresh halaman order | Muncul "Pembayaran Berhasil" |

---

**Catatan Keamanan:**
- Jangan pernah expose file `.env`
- Jangan gunakan Server Key di frontend (hanya Client Key)
- Selalu verifikasi signature key di webhook
- Gunakan HTTPS untuk webhook URL di production

