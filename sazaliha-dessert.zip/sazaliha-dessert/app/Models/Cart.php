<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Cart extends Model
{
    protected $fillable = ['user_id'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(CartItem::class);
    }

    public function getTotalAttribute(): int
    {
        return $this->items->sum(fn ($item) => $item->product->price * $item->quantity);
    }

    public function getCountAttribute(): int
    {
        return $this->items->sum('quantity');
    }

    public static function getCartForUser($userId)
    {
        return static::firstOrCreate(['user_id' => $userId]);
    }
}