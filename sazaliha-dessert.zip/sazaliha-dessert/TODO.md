# TODO

## Email verification SMTP fix
- [x] Identify failure: Gmail SMTP host/port unreachable (smtp.gmail.com:2525)
- [ ] Update `.env` mail settings to valid Gmail SMTP port/encryption OR switch to `MAIL_MAILER=log` for local dev
- [ ] Run `php artisan config:clear` and `php artisan cache:clear` after `.env` change
- [ ] Retry `POST /email/verification-notification`

